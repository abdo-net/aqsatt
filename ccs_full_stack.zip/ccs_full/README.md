# Credit Commerce System (CCS)

Ledger-based, multi-tenant installment-credit platform. FastAPI + PostgreSQL +
SQLAlchemy + Alembic + JWT, with an Arabic/RTL vanilla-JS UI.

Tenant isolation is enforced by **PostgreSQL Row-Level Security**, not just app
WHERE clauses: the app connects as a non-superuser role and every request runs
under `app.tenant_id`. Money is integer IQD. Balances are **derived** from an
append-only ledger and payment allocations — never stored.

## Architecture (modules)
```
app/
  core/      config, security (JWT/bcrypt), deps (DB+RLS context, RBAC), errors
  db/        engine/session, tenant context, seed
  models/    all ORM models (+ RLS_TABLES list)
  services/  ledger, sale, payment (allocation+idempotency), sequence, event
  routers/   auth, customers, products, sales, installments, payments, dashboard
  events/    dispatcher (outbox + webhook delivery)
jobs/        overdue_job (late_days, notifications, overdue events)
alembic/     migrations (initial schema + RLS policies + grants)
static/      index.html + app.js (Arabic RTL UI)
```

### Module boundaries (logical, not microservices)
- **identity**: tenants, users, RBAC (roles/permissions/user_roles), memberships
- **catalog**: categories, products
- **customers**: customers
- **sales**: sales, sale_items, installment_plans, installments, plan_revisions
- **payments**: payments, payment_allocations
- **ledger**: accounts, ledger_entries (append-only)
- **events**: domain_events, webhooks; **collections**: notifications, templates
Cross-module access goes through services, not by reaching into another module's tables.

## Local / VPS setup (Ubuntu)
```bash
sudo apt install -y python3-venv postgresql
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt

# 1) database + non-superuser app role
sudo -u postgres psql -c "CREATE ROLE ccs_app LOGIN PASSWORD 'ccs_app_pass';"
sudo -u postgres psql -c "CREATE DATABASE ccs OWNER postgres;"

# 2) env
cp .env.example .env   # edit DATABASE_URL / ADMIN_DATABASE_URL / JWT_SECRET

# 3) schema (creates tables, RLS policies, grants) + seed
alembic upgrade head
python -m app.db.seed     # tenant 1, chart of accounts, RBAC, admin/admin123

# 4) run
gunicorn -c gunicorn_conf.py app.main:app     # production
# or: uvicorn app.main:app --reload            # development
```
Open `http://SERVER/` → login `admin` / `admin123` (change immediately).

### Why two database URLs
`ADMIN_DATABASE_URL` (schema owner) runs migrations and seed and bypasses RLS.
`DATABASE_URL` (`ccs_app`, non-superuser) is what the app uses at runtime, so RLS
is actually enforced. Superusers bypass RLS — never run the app as one.

## Background jobs (systemd)
See `deploy/systemd_units.txt`. The overdue job runs daily; the event dispatcher
runs every ~2 minutes. Both take a Postgres advisory lock so concurrent runs are
safe, and both are idempotent.

## API (v1)
```
POST /api/v1/auth/login
POST /api/v1/customers            GET /api/v1/customers   GET /api/v1/customers/{id}   PATCH /api/v1/customers/{id}
POST /api/v1/products             GET /api/v1/products    GET/PATCH/DELETE /api/v1/products/{id}
POST /api/v1/sales                GET /api/v1/sales       GET /api/v1/sales/{id}
GET  /api/v1/plans/{id}/schedule
POST /api/v1/payments
GET  /api/v1/dashboard/summary
```
Mutating endpoints (`/sales`, `/payments`) require an `idempotency_key`; replays
return the original result without re-executing.

## Guarantees
- **Tenant isolation**: Postgres RLS (`FORCE`) on all data tables; verified that a
  tenant cannot read another tenant's rows and cross-tenant writes are rejected.
- **No double payment**: per-tenant unique `idempotency_key` + generic
  `request_idempotency`; replays are no-ops.
- **Transactional safety**: state change + ledger entries + outbox event commit in
  one transaction; ledger debits=credits is asserted before commit.
- **Append-only finance**: `ledger_entries` / `payments` / `payment_allocations`
  have UPDATE/DELETE revoked from the app role; corrections are reversals.
- **Balances derived**: AR, paid, remaining, overdue all computed from the ledger
  and allocations — reversed payments self-correct.

## Tests
`python e2e_test.py` runs the full suite against a live DB as the RLS-restricted
role (28 assertions: auth, RBAC, sale+schedule, allocation, idempotency replay,
overpayment rejection, completion, dashboard, events, cross-tenant isolation).

## Frontend (SaaS admin UI)
A modular, dependency-free SPA lives in `static/` and is served at `/` by the
backend (no build step, no bundler — native ES modules):
```
static/
  index.html            shell + Tailwind CDN + fonts
  api.js                fetch client (JWT, error handling, ApiError)
  app.js                hash router + login + shell mount
  components/           icons, i18n (AR/EN + RTL/LTR), ui (toast/modal/badge/format),
                        charts (SVG donut+bars), layout (fixed sidebar + topbar)
  pages/                dashboard, customers, customerProfile, products, sales,
                        payments, notifications
```
Features: KPI dashboard with SVG charts and recent activity; searchable customer
table + full profile (purchases, schedules, derived debt, risk badges); product
card grid with stock indicators and create/edit; sale builder with cash/installment
toggle and live monthly/total preview; payment screen with unpaid-installment
timeline and FIFO allocation preview (mirrors backend); overdue alerts derived
from real schedules with a sidebar badge. RTL Arabic by default, one-click EN/RTL→LTR.
All data comes from `/api/v1/*` — nothing is mocked. Permission-gated nav/actions
use the permission list returned by login. To revert to the minimal test UI, the
backend still serves whatever `static/index.html` contains.

### Frontend update (audit + completion pass)
- **New read-only API** (no schema/logic change, RLS-enforced, permission-gated):
  `GET /api/v1/ledger`, `GET /api/v1/ledger/accounts`, `GET /api/v1/payments`,
  `GET /api/v1/notifications` — these expose existing data that previously had no
  endpoint, so the Ledger and Notifications modules are now real, not derived.
- **Backend correctness fix (no schema/logic change):** the RLS tenant context is
  now re-applied on every transaction via a SQLAlchemy `after_begin` listener keyed
  on `session.info`, fixing an intermittent 500 (`Could not refresh instance`) that
  occurred when a pooled connection served a post-commit `refresh()` without the
  transaction-local `app.tenant_id`.
- **New frontend modules:** `state/store.js` (cache layer), `components/timeline.js`
  (installment + payment timelines), `pages/ledger.js` (account balances +
  transaction-flow visualization). Customer profile now shows a financial summary,
  installment timeline, and payment history; payments screen shows a live FIFO
  allocation preview + payment history; notifications shows actionable overdue
  alerts plus the system notification feed.

### Product upgrade pass (owner/UX)
Researched against Shopify Admin (customer = identity + notes + tags + timeline),
POS UX (fast single-screen sale ending in an explicit review/confirm), and BNPL
payment clarity (always show the human, never an ID).

New, additive backend endpoints over EXISTING tables (no schema change):
- User management: `GET/POST /users`, `PATCH /users/{id}` (name/active/role),
  `POST /users/{id}/password`, `GET /roles`, `GET /permissions`.
- Account & settings: `GET/PATCH /me`, `POST /me/password`, `GET /tenant`,
  `GET /settings`, `PUT /settings/{key}`.
- Role change is done via UPDATE of the existing `user_roles` row (the app DB role
  has no DELETE by design — the system never hard-deletes).

New / upgraded frontend:
- Users page: create user, inline role change, activate/deactivate, reset password,
  roles+permissions reference panel. Permission-gated (users.manage).
- Settings page: profile name, self password change, business/tenant info,
  low-stock threshold (stored in tenant_settings).
- Customer profile: inline edit, internal notes (persisted to customers.notes),
  derived tags (VIP ≥ 3M purchased, late-payer, blocked/risky, risk class), and a
  unified purchase+payment timeline.
- Sales: single-screen builder with customer/product previews, live calculation,
  and a final review→confirm step.
- Payments: shows customer name, balance, and next-due installment (no raw IDs).
- Dashboard: late-customers and low-stock alert panels.
- API client normalizes FastAPI 422 detail arrays into readable messages.

### Catalog/variant upgrade pass (this session)
The product/variant/category/image system specified by the brief was already
implemented (models, migration `a1b2c3d4e5f6`, routers, image_service, frontend
products/productDetail pages with gallery, variant selector, tabs, discount
badges, category filter). Audit found one real gap: **the sale workflow did not
use variants** — `SaleItemIn` only had `product_id`, and `sale_service` deducted
stock/price from the product row only, so a multi-variant product's specific
variant (different price/stock per color/size) could not be sold correctly.

Changes (additive, backward compatible):
- New migration `b2c3d4e5f6a7`: adds nullable `sale_items.variant_id` FK ->
  `product_variants.id`. Existing rows stay NULL. Applied to the dev DB.
- `SaleItem.variant_id` added to the ORM model.
- `SaleItemIn.variant_id: int | None = None` — optional; old callers unaffected.
- `sale_service.create_sale`: if `variant_id` given, locks and deducts that
  variant's stock/price and re-syncs `Product.stock_quantity` = sum(variants).
  If omitted but the product HAS variants, falls back to the **default**
  variant (so stock/price stay variant-accurate even for legacy calls) rather
  than bypassing variants entirely. Products with no variant rows behave exactly
  as before.
- `static/pages/sales.js`: when the selected product has >1 variant, fetches
  `/products/{id}` and shows a variant picker (attributes or SKU + price + stock);
  the chosen `variant_id` is included in the review screen and the create-sale
  payload.

Verified end-to-end (19/19): minimal product (name+price only) auto-creates a
default variant; multi-variant discount_pct computation; image upload + gallery;
product cards (price/installment/discount/stock badges); product detail page
(gallery, variant selector, tabs); sales page variant selector; selling a
specific variant deducts ITS stock and re-syncs the aggregate; selling an
out-of-stock variant returns 409. Full regression: backend 28/28, prior two
frontend suites 16/16 each. Zero server 500s across all runs.

### Premium design-system pass (this session)
Applied the design-token system from the uploaded UI Blueprint spec (spacing
8px scale, semantic color tokens, typography scale, radius/elevation, motion
timing) across the existing SPA — no rebuild, same app, same API calls.

New: `static/components/theme.css` — full token system (light + dark), plus
component primitives: `.surface`, `.tag` (semantic badges, danger>warn>info>ok
priority), `.drawer-panel`/`.sheet-panel` (side drawer ≥4 fields, full-screen
on mobile per spec CMP-02), `.bottom-nav` (mobile primary nav + "more" sheet for
overflow, ≥44px touch targets), `.vtimeline` (installment schedule, Pattern A),
`.debt-bar` (segmented paid/remaining), `.dtable` (sticky header table),
`.empty-state` (360px centered anatomy per §05), skeletons, refetch progress bar,
flash/shake/fade motion primitives at spec timings (120/220/250ms).

Updated: `index.html` (Outfit + JetBrains Mono + Noto Sans Arabic fonts, dark-mode
bootstrap script, drawer/sheet/bottom-nav root containers), `ui.js` (drawer(),
sheet(), toggleTheme(), toast() with undo action support, badgeStack() with
priority ordering, emptyState()), `layout.js` (mobile bottom nav with overflow
"more" sheet, dark-mode toggle, sidebar hidden <lg), `timeline.js` (vertical
timeline with numbered/iconned status dots + debt bar), `customerProfile.js`
(§08 3-zone layout: header + KPI strip + timeline/sales), `dashboard.js` and
`products.js` (flat token-based cards, 3-case price display with savings line
per §07, mono/tabular-nums on all amounts).

Out of scope (flagged, not built): the spec's §06/§10 AI-native features (Merchant
Copilot, Debt Risk Radar heatmap, Cash-Flow Twin, Voice checkout, Trust Score) —
these require new backend ML/AI capabilities beyond a frontend design pass and
would need their own scoping.

Verified: 95/95 e2e assertions (4 frontend suites + backend), zero server 500s.
Mobile bottom nav, dark-mode toggle + persistence, drawer/sheet primitives,
and badge priority ordering directly tested via headless DOM against the live API.
