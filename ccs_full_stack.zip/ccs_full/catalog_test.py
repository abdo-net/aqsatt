import json, urllib.request, urllib.error, uuid, struct, zlib
B = "http://127.0.0.1:8130/api/v1"

def call(m, p, b=None, tok=None, raw=None, ct="application/json"):
    data = raw if raw is not None else (json.dumps(b).encode() if b is not None else None)
    req = urllib.request.Request(B + p, data=data, method=m)
    if (raw is not None) or (b is not None):
        req.add_header("Content-Type", ct)
    if tok:
        req.add_header("Authorization", "Bearer " + tok)
    try:
        r = urllib.request.urlopen(req, timeout=15)
        return r.status, json.loads(r.read() or "{}")
    except urllib.error.HTTPError as e:
        try: d = json.loads(e.read())
        except Exception: d = {}
        return e.code, d

tok = call("POST", "/auth/login", {"username": "admin", "password": "admin123"})[1]["access_token"]
def show(l, r): print(f"{r[0]:>3}  {l}")

st, old = call("POST", "/products", {"sku": "OLD" + uuid.uuid4().hex[:6], "name": "Legacy", "name_ar": "قديم", "base_price": 500000, "stock_quantity": 4}, tok)
show("OLD-STYLE create (compat)", (st, old))
print("   default variants:", len(old.get("variants", [])), "| stock", old.get("stock_quantity"))

st, cat = call("POST", "/categories", {"name": "Phones", "name_ar": "هواتف"}, tok); show("create category", (st, cat))

sku = "PH" + uuid.uuid4().hex[:6]
st, prod = call("POST", "/products", {"sku": sku, "name": "Galaxy", "name_ar": "غالاكسي", "category_id": cat["id"],
    "brand": "Samsung", "tags": "5g,new", "status": "active", "description": "وصف",
    "variants": [
        {"sku": sku + "-128", "price_cash": 750000, "compare_price": 900000, "stock_quantity": 5, "attributes": {"color": "أسود"}, "is_default": True},
        {"sku": sku + "-256", "price_cash": 850000, "stock_quantity": 3, "attributes": {"color": "أبيض"}}]}, tok)
show("RICH create (2 variants)", (st, prod))
print("   variants", len(prod.get("variants", [])), "| agg stock", prod.get("stock_quantity"), "| base", prod.get("base_price"), "| disc%", prod.get("discount_pct"))
pid = prod["id"]

def png(w, h, color=(200, 80, 80)):
    def chunk(t, d):
        c = t + d; return struct.pack(">I", len(d)) + c + struct.pack(">I", zlib.crc32(c) & 0xffffffff)
    raw = b''.join(b'\x00' + bytes(color) * w for _ in range(h))
    return b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)) + chunk(b'IDAT', zlib.compress(raw)) + chunk(b'IEND', b'')

boundary = "----t"; img = png(120, 300)
body = (f"--{boundary}\r\nContent-Disposition: form-data; name=\"files\"; filename=\"a.png\"\r\nContent-Type: image/png\r\n\r\n").encode() + img + f"\r\n--{boundary}--\r\n".encode()
st, imgs = call("POST", f"/products/{pid}/images", raw=body, tok=tok, ct=f"multipart/form-data; boundary={boundary}")
show("upload image (120x300 -> 1:1)", (st, imgs))
print("   images:", len(imgs) if isinstance(imgs, list) else imgs)

st, det = call("GET", f"/products/{pid}", tok=tok); show("GET detail", (st, det))
print("   primary thumb:", (det.get("primary_image") or {}).get("thumb_path"), "| category:", (det.get("category") or {}).get("name_ar"))

st, lst = call("GET", f"/products?category_id={cat['id']}", tok=tok); show("list filter by category", (st, lst))
print("   returned", len(lst))

cust = call("POST", "/customers", {"full_name": "مشتري", "phone": "079" + uuid.uuid4().hex[:7], "risk_class": "qi"}, tok)[1]
st, sale = call("POST", "/sales", {"idempotency_key": uuid.uuid4().hex, "customer_id": cust["id"], "sale_type": "cash", "items": [{"product_id": pid, "quantity": 2}]}, tok)
show("SELL 2 units (cash)", (st, sale))
st, after = call("GET", f"/products/{pid}", tok=tok)
print("   stock 8 -> after:", after.get("stock_quantity"), "(expect 6)")

st, fail = call("POST", "/sales", {"idempotency_key": uuid.uuid4().hex, "customer_id": cust["id"], "sale_type": "cash", "items": [{"product_id": pid, "quantity": 9999}]}, tok)
show("SELL beyond stock (expect 4xx)", (st, fail))
print("   detail:", str(fail.get("detail"))[:70])
