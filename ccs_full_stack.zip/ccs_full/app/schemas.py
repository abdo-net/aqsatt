from datetime import date, datetime
from pydantic import BaseModel, Field, field_validator


class LoginRequest(BaseModel):
    username: str
    password: str


class LoginResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    tenant_id: int
    user_id: int
    permissions: list[str]


class CustomerCreate(BaseModel):
    full_name: str
    phone: str
    alt_phone: str | None = None
    national_id: str | None = None
    address: str | None = None
    notes: str | None = None
    risk_class: str = "trusted"

    @field_validator("risk_class")
    @classmethod
    def _r(cls, v):
        if v not in ("trusted", "qi", "mixed"):
            raise ValueError("risk_class invalid")
        return v


class CustomerUpdate(BaseModel):
    full_name: str | None = None
    phone: str | None = None
    alt_phone: str | None = None
    national_id: str | None = None
    address: str | None = None
    notes: str | None = None
    risk_class: str | None = None
    status: str | None = None


class VariantIn(BaseModel):
    sku: str | None = None
    price_cash: int = Field(gt=0)
    price_installment: int | None = Field(default=None, gt=0)
    compare_price: int | None = Field(default=None, gt=0)
    cost_price: int | None = Field(default=None, ge=0)
    stock_quantity: int = Field(ge=0, default=0)
    attributes: dict | None = None
    is_default: bool = False


class ProductCreate(BaseModel):
    sku: str
    name: str
    name_ar: str | None = None
    category_id: int | None = None
    base_price: int | None = Field(default=None, gt=0)
    stock_quantity: int = Field(ge=0, default=0)
    description: str | None = None
    brand: str | None = None
    tags: str | None = None
    status: str = "active"
    variants: list[VariantIn] | None = None


class ProductUpdate(BaseModel):
    name: str | None = None
    name_ar: str | None = None
    category_id: int | None = None
    base_price: int | None = Field(default=None, gt=0)
    stock_quantity: int | None = Field(default=None, ge=0)
    description: str | None = None
    brand: str | None = None
    tags: str | None = None
    status: str | None = None
    is_active: bool | None = None


class VariantUpdate(BaseModel):
    sku: str | None = None
    price_cash: int | None = Field(default=None, gt=0)
    price_installment: int | None = Field(default=None, gt=0)
    compare_price: int | None = Field(default=None, gt=0)
    cost_price: int | None = Field(default=None, ge=0)
    stock_quantity: int | None = Field(default=None, ge=0)
    attributes: dict | None = None


class CategoryCreate(BaseModel):
    name: str
    name_ar: str | None = None


class SaleItemIn(BaseModel):
    product_id: int
    variant_id: int | None = None
    quantity: int = Field(gt=0)
    item_discount: int = Field(ge=0, default=0)


class SaleCreate(BaseModel):
    idempotency_key: str = Field(min_length=8, max_length=80)
    customer_id: int
    sale_type: str
    items: list[SaleItemIn] = Field(min_length=1)
    discount_amount: int = Field(ge=0, default=0)
    down_payment: int = Field(ge=0, default=0)
    months: int | None = Field(default=None, gt=0)
    frequency: str | None = "monthly"
    start_date: date | None = None
    sale_channel: str = "store"
    salesperson_id: int | None = None
    notes: str | None = None

    @field_validator("sale_type")
    @classmethod
    def _t(cls, v):
        if v not in ("cash", "installment"):
            raise ValueError("sale_type invalid")
        return v


class PaymentCreate(BaseModel):
    idempotency_key: str = Field(min_length=8, max_length=80)
    sale_id: int
    amount: int = Field(gt=0)
    payment_method: str
    reference_number: str | None = None
    source: str = "manual"

    @field_validator("payment_method")
    @classmethod
    def _m(cls, v):
        if v not in ("cash", "qi", "transfer", "zaincash", "visa"):
            raise ValueError("payment_method invalid")
        return v


class UserCreate(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    username: str = Field(min_length=3, max_length=50)
    password: str = Field(min_length=6, max_length=128)
    role_id: int


class UserUpdate(BaseModel):
    name: str | None = None
    is_active: bool | None = None
    role_id: int | None = None


class PasswordReset(BaseModel):
    new_password: str = Field(min_length=6, max_length=128)


class PasswordChange(BaseModel):
    old_password: str
    new_password: str = Field(min_length=6, max_length=128)


class ProfileUpdate(BaseModel):
    name: str = Field(min_length=2, max_length=100)


class SettingUpsert(BaseModel):
    value: dict
