from sqlalchemy.orm import Session

from app.models import DomainEvent


def emit(db: Session, *, tenant_id: int, event_type: str, entity_type: str,
         entity_id: int, payload: dict) -> None:
    """Insert a domain event in the SAME transaction as the state change
    (transactional outbox). Never committed here; caller owns the transaction."""
    db.add(DomainEvent(
        tenant_id=tenant_id, event_type=event_type, entity_type=entity_type,
        entity_id=entity_id, payload=payload, status="pending", attempts=0,
    ))
