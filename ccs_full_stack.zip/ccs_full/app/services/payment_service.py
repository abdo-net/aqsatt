import uuid
from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.errors import bad_request, conflict, not_found
from app.models import Installment, InstallmentPlan, Payment, PaymentAllocation, Sale
from app.services import event_service, ledger_service, sequence_service
from app.services.ledger_service import Line

# Manual providers only today; fee = 0. Swap for real providers later.
FEE_BY_METHOD = {"cash": 0, "qi": 0, "transfer": 0, "zaincash": 0, "visa": 0}


def _find_existing(db, tenant_id, key):
    return db.execute(
        select(Payment).where(Payment.tenant_id == tenant_id, Payment.idempotency_key == key)
    ).scalar_one_or_none()


def record_payment(db: Session, *, tenant_id: int, user_id: int, idempotency_key: str,
                   sale_id: int, amount: int, payment_method: str,
                   reference_number: str | None, source: str):
    existing = _find_existing(db, tenant_id, idempotency_key)
    if existing:
        return existing, _alloc_view(db, existing), _plan(db, sale_id), db.get(Sale, sale_id), True

    sale = db.execute(select(Sale).where(Sale.id == sale_id).with_for_update()).scalar_one_or_none()
    if not sale or sale.is_deleted:
        raise not_found("sale not found")
    if sale.status != "active":
        raise conflict(f"sale is {sale.status}; cannot accept payment")

    fee = FEE_BY_METHOD.get(payment_method, 0)
    if amount <= fee:
        raise bad_request("amount must exceed fee")

    receipt = sequence_service.format_number("R", sequence_service.next_number(db, tenant_id, "receipt"))
    group = uuid.uuid4()
    txn = Payment(
        tenant_id=tenant_id, receipt_number=receipt, idempotency_key=idempotency_key,
        customer_id=sale.customer_id, sale_id=sale.id, amount=amount, fee_amount=fee,
        payment_method=payment_method, status="confirmed", reference_number=reference_number,
        source=source, received_by=user_id, transaction_group_id=group, created_by=user_id,
    )
    db.add(txn)
    try:
        db.flush()
    except IntegrityError:
        db.rollback()
        ex = _find_existing(db, tenant_id, idempotency_key)
        if ex:
            return ex, _alloc_view(db, ex), _plan(db, sale_id), db.get(Sale, sale_id), True
        raise

    plan = db.execute(select(InstallmentPlan).where(
        InstallmentPlan.sale_id == sale.id, InstallmentPlan.status == "active").with_for_update()).scalar_one_or_none()
    if not plan:
        raise conflict("no active installment plan for sale")

    rows = db.execute(
        select(Installment).where(Installment.plan_id == plan.id, Installment.status == "scheduled")
        .order_by(Installment.installment_number).with_for_update()
    ).scalars().all()

    # derived outstanding per installment = amount - confirmed allocations
    outstanding_total = 0
    per_row = []
    for r in rows:
        paid = _paid_amount(db, r.id)
        out = r.amount - paid
        if out > 0:
            per_row.append((r, out))
            outstanding_total += out

    if amount > outstanding_total:
        raise conflict(f"overpayment rejected: {amount} > outstanding {outstanding_total}")

    remaining = amount
    allocs = []
    now = datetime.now(tz=timezone.utc)
    for r, out in per_row:
        if remaining <= 0:
            break
        apply = min(remaining, out)
        db.add(PaymentAllocation(tenant_id=tenant_id, payment_id=txn.id, installment_id=r.id, amount=apply))
        r.last_payment_at = now
        allocs.append({"installment_number": r.installment_number, "allocated_amount": apply})
        remaining -= apply
    assert remaining == 0

    if fee == 0:
        lines = [Line("1000", debit=amount, sale_id=sale.id, description="cash in"),
                 Line("1100", credit=amount, customer_id=sale.customer_id, sale_id=sale.id, description="AR payment")]
    else:
        lines = [Line("1000", debit=amount - fee, sale_id=sale.id, description="cash net fee"),
                 Line("5000", debit=fee, sale_id=sale.id, description="provider fee"),
                 Line("1100", credit=amount, customer_id=sale.customer_id, sale_id=sale.id, description="AR payment")]
    ledger_service.post(db, tenant_id=tenant_id, transaction_group_id=group, lines=lines,
                        reference_type="payment", reference_id=txn.id, user_id=user_id)

    # completion: every scheduled installment fully covered?
    db.flush()
    if _sale_outstanding(db, plan) == 0:
        plan.status = "completed"
        sale.status = "completed"

    event_service.emit(db, tenant_id=tenant_id, event_type="payment_received", entity_type="payment",
                       entity_id=txn.id, payload={"amount": amount, "sale_id": sale.id, "receipt": receipt})
    return txn, allocs, plan, sale, False


def _paid_amount(db, installment_id: int) -> int:
    from sqlalchemy import func
    return int(db.execute(
        select(func.coalesce(func.sum(PaymentAllocation.amount), 0))
        .join(Payment, Payment.id == PaymentAllocation.payment_id)
        .where(PaymentAllocation.installment_id == installment_id, Payment.status == "confirmed")
    ).scalar_one())


def _sale_outstanding(db, plan) -> int:
    rows = db.execute(select(Installment).where(Installment.plan_id == plan.id, Installment.status == "scheduled")).scalars().all()
    return sum(r.amount - _paid_amount(db, r.id) for r in rows)


def _alloc_view(db, txn):
    out = []
    for a in db.execute(select(PaymentAllocation).where(PaymentAllocation.payment_id == txn.id)).scalars().all():
        inst = db.get(Installment, a.installment_id)
        out.append({"installment_number": inst.installment_number, "allocated_amount": a.amount})
    return out


def _plan(db, sale_id):
    return db.execute(select(InstallmentPlan).where(
        InstallmentPlan.sale_id == sale_id, InstallmentPlan.status.in_(["active", "completed"]))
        .order_by(InstallmentPlan.revision.desc())).scalars().first()


def installment_state(db, inst: Installment):
    from datetime import date
    paid = _paid_amount(db, inst.id)
    remaining = inst.amount - paid
    if inst.status == "cancelled":
        status = "cancelled"
    elif remaining <= 0:
        status = "paid"
    elif inst.due_date < date.today():
        status = "late"
    elif paid > 0:
        status = "partially_paid"
    else:
        status = "pending"
    return {"installment_number": inst.installment_number, "due_date": str(inst.due_date),
            "amount": inst.amount, "paid": paid, "remaining": remaining,
            "status": status, "late_days": inst.late_days}
