import uuid
from dataclasses import dataclass

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.errors import LedgerImbalance
from app.models import Account, LedgerEntry


@dataclass
class Line:
    account_code: str
    debit: int = 0
    credit: int = 0
    customer_id: int | None = None
    sale_id: int | None = None
    description: str | None = None
    reversed_entry_id: int | None = None


def _account_id(db: Session, tenant_id: int, code: str) -> int:
    return db.execute(
        select(Account.id).where(Account.tenant_id == tenant_id, Account.code == code)
    ).scalar_one()


def post(db: Session, *, tenant_id: int, transaction_group_id: uuid.UUID, lines: list[Line],
         reference_type: str, reference_id: int, user_id: int) -> None:
    if not lines:
        raise LedgerImbalance("empty transaction")
    td = sum(l.debit for l in lines)
    tc = sum(l.credit for l in lines)
    if td != tc:
        raise LedgerImbalance(f"imbalance debit={td} credit={tc} {reference_type}:{reference_id}")
    if td == 0:
        raise LedgerImbalance("zero-value transaction")
    for l in lines:
        if (l.debit > 0 and l.credit > 0) or (l.debit == 0 and l.credit == 0):
            raise LedgerImbalance("each line is exactly one side")
        db.add(LedgerEntry(
            tenant_id=tenant_id, transaction_group_id=transaction_group_id,
            account_id=_account_id(db, tenant_id, l.account_code),
            customer_id=l.customer_id, sale_id=l.sale_id,
            debit_amount=l.debit, credit_amount=l.credit,
            reference_type=reference_type, reference_id=reference_id,
            description=l.description, reversed_entry_id=l.reversed_entry_id, created_by=user_id,
        ))


def account_balance(db: Session, tenant_id: int, code: str) -> int:
    acc = db.execute(select(Account).where(Account.tenant_id == tenant_id, Account.code == code)).scalar_one()
    d, c = db.execute(
        select(func.coalesce(func.sum(LedgerEntry.debit_amount), 0),
               func.coalesce(func.sum(LedgerEntry.credit_amount), 0))
        .where(LedgerEntry.account_id == acc.id)
    ).one()
    return int(d - c) if acc.normal_balance == "debit" else int(c - d)


def customer_receivable(db: Session, tenant_id: int, customer_id: int) -> int:
    ar = _account_id(db, tenant_id, "1100")
    d, c = db.execute(
        select(func.coalesce(func.sum(LedgerEntry.debit_amount), 0),
               func.coalesce(func.sum(LedgerEntry.credit_amount), 0))
        .where(LedgerEntry.account_id == ar, LedgerEntry.customer_id == customer_id)
    ).one()
    return int(d - c)
