from datetime import date

from sqlalchemy import text
from sqlalchemy.orm import Session


def next_number(db: Session, tenant_id: int, sequence_name: str) -> int:
    """Atomic increment via UPDATE ... RETURNING. Row is created on first use."""
    db.execute(
        text("""INSERT INTO tenant_sequences (tenant_id, sequence_name, current_value)
                VALUES (:t, :s, 0) ON CONFLICT DO NOTHING"""),
        {"t": tenant_id, "s": sequence_name},
    )
    val = db.execute(
        text("""UPDATE tenant_sequences SET current_value = current_value + 1
                WHERE tenant_id = :t AND sequence_name = :s RETURNING current_value"""),
        {"t": tenant_id, "s": sequence_name},
    ).scalar_one()
    return int(val)


def format_number(prefix: str, n: int) -> str:
    return f"{prefix}-{date.today().year}-{n:06d}"
