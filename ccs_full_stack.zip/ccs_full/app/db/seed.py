"""Idempotent seed. Run as the schema owner/admin (bypasses RLS).
Usage: python -m app.db.seed
"""
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

from app.core.config import settings
from app.core.security import hash_password
from app.models import (
    Account, NotificationTemplate, Permission, Role, RolePermission, Tenant,
    TenantMembership, User, UserRole,
)

# admin URL: owner/superuser, not RLS-restricted
engine = create_engine(settings.admin_database_url, future=True)
Session = sessionmaker(bind=engine, future=True)

ACCOUNTS = [
    ("1000", "Cash", "النقد", "asset", "debit"),
    ("1100", "Accounts Receivable", "الذمم المدينة", "asset", "debit"),
    ("4000", "Sales Revenue", "إيرادات المبيعات", "revenue", "credit"),
    ("5000", "Provider Fees Expense", "رسوم المزوّد", "expense", "debit"),
]

PERMISSIONS = [
    ("customers.read", "View customers"), ("customers.write", "Create/edit customers"),
    ("products.read", "View products"), ("products.write", "Create/edit products"),
    ("sales.read", "View sales"), ("sales.create", "Create sales"), ("sales.cancel", "Cancel sales"),
    ("plans.read", "View plans"), ("plans.reschedule", "Reschedule plans"),
    ("payments.read", "View payments"), ("payments.create", "Record payments"),
    ("payments.reverse", "Reverse payments"),
    ("ledger.read", "View ledger"), ("reports.read", "View reports/dashboard"),
    ("users.manage", "Manage users"), ("roles.manage", "Manage roles"),
    ("settings.manage", "Manage tenant settings"),
]

ROLE_PERMS = {
    "admin": [c for c, _ in PERMISSIONS],
    "staff": ["customers.read", "customers.write", "products.read", "sales.read",
              "sales.create", "plans.read", "payments.read", "payments.create", "reports.read"],
    "accountant": ["sales.read", "plans.read", "payments.read", "payments.reverse",
                   "ledger.read", "reports.read"],
}


def main():
    db = Session()
    try:
        tenant = db.execute(select(Tenant).where(Tenant.slug == settings.default_tenant_slug)).scalar_one_or_none()
        if not tenant:
            tenant = Tenant(name=settings.default_tenant_name, slug=settings.default_tenant_slug, type="store")
            db.add(tenant); db.flush()
        tid = tenant.id

        for code, name, name_ar, typ, nb in ACCOUNTS:
            if not db.execute(select(Account).where(Account.tenant_id == tid, Account.code == code)).scalar_one_or_none():
                db.add(Account(tenant_id=tid, code=code, name=name, name_ar=name_ar, type=typ, normal_balance=nb))

        perm_ids = {}
        for code, desc in PERMISSIONS:
            p = db.execute(select(Permission).where(Permission.code == code)).scalar_one_or_none()
            if not p:
                p = Permission(code=code, description=desc); db.add(p); db.flush()
            perm_ids[code] = p.id

        role_ids = {}
        for rname, codes in ROLE_PERMS.items():
            r = db.execute(select(Role).where(Role.tenant_id == tid, Role.name == rname)).scalar_one_or_none()
            if not r:
                r = Role(tenant_id=tid, name=rname, is_system=True, description=f"{rname} role")
                db.add(r); db.flush()
            role_ids[rname] = r.id
            for code in codes:
                exists = db.execute(select(RolePermission).where(
                    RolePermission.role_id == r.id, RolePermission.permission_id == perm_ids[code])).scalar_one_or_none()
                if not exists:
                    db.add(RolePermission(role_id=r.id, permission_id=perm_ids[code]))

        admin = db.execute(select(User).where(User.username == settings.default_admin_username)).scalar_one_or_none()
        if not admin:
            admin = User(home_tenant_id=tid, name="Administrator", username=settings.default_admin_username,
                         password_hash=hash_password(settings.default_admin_password), is_active=True)
            db.add(admin); db.flush()
        if not db.execute(select(TenantMembership).where(
                TenantMembership.user_id == admin.id, TenantMembership.tenant_id == tid)).scalar_one_or_none():
            db.add(TenantMembership(user_id=admin.id, tenant_id=tid, is_active=True))
        if not db.execute(select(UserRole).where(
                UserRole.user_id == admin.id, UserRole.tenant_id == tid, UserRole.role_id == role_ids["admin"])).scalar_one_or_none():
            db.add(UserRole(user_id=admin.id, tenant_id=tid, role_id=role_ids["admin"]))

        if not db.execute(select(NotificationTemplate).where(
                NotificationTemplate.tenant_id == tid, NotificationTemplate.key == "overdue",
                NotificationTemplate.channel == "whatsapp")).scalar_one_or_none():
            db.add(NotificationTemplate(tenant_id=tid, key="overdue", channel="whatsapp",
                                        body_ar="عزيزي {{name}}، لديك قسط متأخر بتاريخ {{due_date}}. المبلغ المتبقي {{amount}} دينار. يرجى المراجعة."))

        db.commit()
        print(f"seed: done (tenant_id={tid}, admin='{settings.default_admin_username}')")
    finally:
        db.close()


if __name__ == "__main__":
    main()
