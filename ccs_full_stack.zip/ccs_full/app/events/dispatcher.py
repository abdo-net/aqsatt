"""Domain-event dispatcher. Reads unprocessed events per tenant, runs handlers
(webhook delivery here), marks processed/failed. Run via systemd timer.

Usage: python -m app.events.dispatcher
"""
import sys
from datetime import datetime, timezone

import httpx
from sqlalchemy import select, text

from app.db.base import SessionLocal, set_tenant
from app.models import DomainEvent, Tenant, WebhookDelivery, WebhookEndpoint

LOCK = 510001


def _deliver_webhooks(db, ev: DomainEvent):
    eps = db.execute(select(WebhookEndpoint).where(
        WebhookEndpoint.is_active == True, WebhookEndpoint.is_deleted == False)).scalars().all()  # noqa: E712
    for ep in eps:
        if ev.event_type not in (ep.event_types or []):
            continue
        d = WebhookDelivery(tenant_id=ev.tenant_id, endpoint_id=ep.id, event_id=ev.id,
                            status="pending", attempts=1)
        try:
            r = httpx.post(ep.url, json={"event_type": ev.event_type, "entity_type": ev.entity_type,
                                         "entity_id": ev.entity_id, "payload": ev.payload}, timeout=10.0)
            d.status = "sent" if r.status_code < 300 else "failed"
            d.response_code = r.status_code
        except httpx.HTTPError:
            d.status = "failed"
        db.add(d)


def run() -> int:
    db = SessionLocal()
    try:
        if not db.execute(text("SELECT pg_try_advisory_lock(:k)"), {"k": LOCK}).scalar():
            print("dispatcher: locked; skip"); return 0
        try:
            tenants = db.execute(select(Tenant.id).where(Tenant.status == "active")).scalars().all()
            processed = 0
            for tid in tenants:
                set_tenant(db, tid)
                events = db.execute(select(DomainEvent).where(
                    DomainEvent.tenant_id == tid, DomainEvent.processed_at.is_(None))
                    .order_by(DomainEvent.created_at).limit(200)).scalars().all()
                for ev in events:
                    try:
                        _deliver_webhooks(db, ev)
                        ev.status = "processed"
                        ev.processed_at = datetime.now(tz=timezone.utc)
                    except Exception as e:  # noqa: BLE001
                        ev.status = "failed"
                        ev.attempts += 1
                        ev.last_error = str(e)[:500]
                    processed += 1
                db.commit()
            print(f"dispatcher: processed={processed}")
            return 0
        finally:
            db.execute(text("SELECT pg_advisory_unlock(:k)"), {"k": LOCK})
            db.commit()
    except Exception as e:  # noqa: BLE001
        db.rollback(); print(f"dispatcher: ERROR {e}", file=sys.stderr); return 1
    finally:
        db.close()


if __name__ == "__main__":
    raise SystemExit(run())
