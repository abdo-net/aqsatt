"""All ORM models. Kept in one module to avoid circular-import fragility.
tenant-scoped DATA tables carry tenant_id NOT NULL and are protected by RLS
(policies created in the Alembic migration). Auth/RBAC plumbing tables
(users, tenants, permissions, roles, role_permissions, user_roles,
tenant_memberships) are scoped at the application layer."""
import uuid

from sqlalchemy import (
    ARRAY, BigInteger, Boolean, CheckConstraint, Date, DateTime, ForeignKey,
    Integer, String, Text, UniqueConstraint, func, Index, CHAR, text,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base


def pk():
    return mapped_column(BigInteger, primary_key=True, autoincrement=True)


def ts_created():
    return mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)


# ----------------------------------------------------------------- platform
class Tenant(Base):
    __tablename__ = "tenants"
    id: Mapped[int] = pk()
    public_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, server_default=func.gen_random_uuid(), unique=True)
    parent_tenant_id: Mapped[int | None] = mapped_column(BigInteger, ForeignKey("tenants.id"), nullable=True)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    slug: Mapped[str] = mapped_column(String(60), nullable=False, unique=True)
    type: Mapped[str] = mapped_column(String(12), nullable=False, server_default="store")
    currency_code: Mapped[str] = mapped_column(CHAR(3), nullable=False, server_default="IQD")
    timezone: Mapped[str] = mapped_column(String(40), nullable=False, server_default="Asia/Baghdad")
    status: Mapped[str] = mapped_column(String(12), nullable=False, server_default="active")
    is_deleted: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="false")
    deleted_at = mapped_column(DateTime(timezone=True), nullable=True)
    created_at = ts_created()
    __table_args__ = (
        CheckConstraint("type IN ('store','reseller')", name="ck_tenant_type"),
        CheckConstraint("status IN ('active','suspended')", name="ck_tenant_status"),
    )


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = pk()
    public_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, server_default=func.gen_random_uuid(), unique=True)
    home_tenant_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("tenants.id"), nullable=False)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    username: Mapped[str] = mapped_column(String(50), nullable=False, unique=True)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="true")
    is_deleted: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="false")
    deleted_at = mapped_column(DateTime(timezone=True), nullable=True)
    created_at = ts_created()
    updated_at = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)


class Permission(Base):
    __tablename__ = "permissions"
    id: Mapped[int] = pk()
    code: Mapped[str] = mapped_column(String(40), nullable=False, unique=True)
    description: Mapped[str] = mapped_column(String(150), nullable=False)


class Role(Base):
    __tablename__ = "roles"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("tenants.id"), nullable=False)
    name: Mapped[str] = mapped_column(String(40), nullable=False)
    description: Mapped[str | None] = mapped_column(String(150), nullable=True)
    is_system: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="false")
    is_deleted: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="false")
    deleted_at = mapped_column(DateTime(timezone=True), nullable=True)
    __table_args__ = (UniqueConstraint("tenant_id", "name", name="uq_roles_tenant_name"),)


class RolePermission(Base):
    __tablename__ = "role_permissions"
    role_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("roles.id"), primary_key=True)
    permission_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("permissions.id"), primary_key=True)


class UserRole(Base):
    __tablename__ = "user_roles"
    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id"), primary_key=True)
    tenant_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("tenants.id"), primary_key=True)
    role_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("roles.id"), primary_key=True)


class TenantMembership(Base):
    __tablename__ = "tenant_memberships"
    id: Mapped[int] = pk()
    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id"), nullable=False)
    tenant_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("tenants.id"), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="true")
    is_deleted: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="false")
    deleted_at = mapped_column(DateTime(timezone=True), nullable=True)
    created_at = ts_created()
    __table_args__ = (UniqueConstraint("user_id", "tenant_id", name="uq_membership"),)


class TenantSetting(Base):
    __tablename__ = "tenant_settings"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("tenants.id"), nullable=False)
    key: Mapped[str] = mapped_column(String(60), nullable=False)
    value: Mapped[dict] = mapped_column(JSONB, nullable=False)
    updated_by: Mapped[int | None] = mapped_column(BigInteger, ForeignKey("users.id"), nullable=True)
    updated_at = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    __table_args__ = (UniqueConstraint("tenant_id", "key", name="uq_setting"),)


class TenantSequence(Base):
    __tablename__ = "tenant_sequences"
    tenant_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("tenants.id"), primary_key=True)
    sequence_name: Mapped[str] = mapped_column(String(40), primary_key=True)
    current_value: Mapped[int] = mapped_column(BigInteger, nullable=False, server_default="0")


class RequestIdempotency(Base):
    __tablename__ = "request_idempotency"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("tenants.id"), nullable=False)
    idempotency_key: Mapped[str] = mapped_column(String(80), nullable=False)
    endpoint: Mapped[str] = mapped_column(String(80), nullable=False)
    response_code: Mapped[int] = mapped_column(Integer, nullable=False)
    response_body: Mapped[dict] = mapped_column(JSONB, nullable=False)
    created_at = ts_created()
    __table_args__ = (UniqueConstraint("tenant_id", "idempotency_key", "endpoint", name="uq_req_idem"),)


# ----------------------------------------------------------------- customers / catalog
class Customer(Base):
    __tablename__ = "customers"
    id: Mapped[int] = pk()
    public_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, server_default=func.gen_random_uuid(), unique=True)
    tenant_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("tenants.id"), nullable=False)
    full_name: Mapped[str] = mapped_column(String(150), nullable=False)
    phone: Mapped[str] = mapped_column(String(20), nullable=False)
    alt_phone: Mapped[str | None] = mapped_column(String(20), nullable=True)
    national_id: Mapped[str | None] = mapped_column(String(30), nullable=True)
    address: Mapped[str | None] = mapped_column(Text, nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    risk_class: Mapped[str] = mapped_column(String(10), nullable=False, server_default="trusted")
    status: Mapped[str] = mapped_column(String(10), nullable=False, server_default="active")
    is_deleted: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="false")
    deleted_at = mapped_column(DateTime(timezone=True), nullable=True)
    created_by: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id"), nullable=False)
    created_at = ts_created()
    updated_at = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    __table_args__ = (
        CheckConstraint("risk_class IN ('trusted','qi','mixed')", name="ck_cust_risk"),
        CheckConstraint("status IN ('active','blocked')", name="ck_cust_status"),
        Index("uq_customers_phone", "tenant_id", "phone", unique=True, postgresql_where=text("is_deleted = false")),
    )


class Category(Base):
    __tablename__ = "categories"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("tenants.id"), nullable=False)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    name_ar: Mapped[str] = mapped_column(String(100), nullable=False)
    is_deleted: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="false")
    deleted_at = mapped_column(DateTime(timezone=True), nullable=True)


class Product(Base):
    __tablename__ = "products"
    id: Mapped[int] = pk()
    public_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, server_default=func.gen_random_uuid(), unique=True)
    tenant_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("tenants.id"), nullable=False)
    sku: Mapped[str] = mapped_column(String(50), nullable=False)
    name: Mapped[str] = mapped_column(String(150), nullable=False)
    name_ar: Mapped[str] = mapped_column(String(150), nullable=False)
    category_id: Mapped[int | None] = mapped_column(BigInteger, ForeignKey("categories.id"), nullable=True)
    base_price: Mapped[int] = mapped_column(BigInteger, nullable=False)
    stock_quantity: Mapped[int] = mapped_column(Integer, nullable=False, server_default="0")
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    brand: Mapped[str | None] = mapped_column(String(100), nullable=True)
    tags: Mapped[str | None] = mapped_column(String(300), nullable=True)
    status: Mapped[str] = mapped_column(String(20), nullable=False, server_default="active")
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="true")
    is_deleted: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="false")
    deleted_at = mapped_column(DateTime(timezone=True), nullable=True)
    created_at = ts_created()
    updated_at = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    __table_args__ = (
        CheckConstraint("base_price > 0", name="ck_prod_price"),
        CheckConstraint("stock_quantity >= 0", name="ck_prod_stock"),
        Index("uq_products_sku", "tenant_id", "sku", unique=True, postgresql_where=text("is_deleted = false")),
    )


class ProductVariant(Base):
    __tablename__ = "product_variants"
    id: Mapped[int] = pk()
    public_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, server_default=func.gen_random_uuid(), unique=True)
    tenant_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("tenants.id"), nullable=False)
    product_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("products.id"), nullable=False)
    sku: Mapped[str] = mapped_column(String(60), nullable=False)
    price_cash: Mapped[int] = mapped_column(BigInteger, nullable=False)
    price_installment: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    compare_price: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    cost_price: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    stock_quantity: Mapped[int] = mapped_column(Integer, nullable=False, server_default="0")
    attributes: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
    is_default: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="false")
    is_deleted: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="false")
    created_at = ts_created()
    updated_at = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    __table_args__ = (
        CheckConstraint("price_cash > 0", name="ck_var_price"),
        CheckConstraint("stock_quantity >= 0", name="ck_var_stock"),
        Index("uq_variant_sku", "tenant_id", "sku", unique=True, postgresql_where=text("is_deleted = false")),
    )


class ProductImage(Base):
    __tablename__ = "product_images"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("tenants.id"), nullable=False)
    product_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("products.id"), nullable=False)
    variant_id: Mapped[int | None] = mapped_column(BigInteger, ForeignKey("product_variants.id"), nullable=True)
    path: Mapped[str] = mapped_column(String(300), nullable=False)
    thumb_path: Mapped[str | None] = mapped_column(String(300), nullable=True)
    sort_order: Mapped[int] = mapped_column(Integer, nullable=False, server_default="0")
    is_deleted: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="false")
    created_at = ts_created()


# ----------------------------------------------------------------- sales
class Sale(Base):
    __tablename__ = "sales"
    id: Mapped[int] = pk()
    public_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, server_default=func.gen_random_uuid(), unique=True)
    tenant_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("tenants.id"), nullable=False)
    sale_number: Mapped[str] = mapped_column(String(20), nullable=False)
    customer_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("customers.id"), nullable=False)
    sale_type: Mapped[str] = mapped_column(String(12), nullable=False)
    sale_channel: Mapped[str] = mapped_column(String(10), nullable=False, server_default="store")
    salesperson_id: Mapped[int | None] = mapped_column(BigInteger, ForeignKey("users.id"), nullable=True)
    subtotal: Mapped[int] = mapped_column(BigInteger, nullable=False)
    discount_amount: Mapped[int] = mapped_column(BigInteger, nullable=False, server_default="0")
    total_price: Mapped[int] = mapped_column(BigInteger, nullable=False)
    down_payment: Mapped[int] = mapped_column(BigInteger, nullable=False, server_default="0")
    status: Mapped[str] = mapped_column(String(12), nullable=False, server_default="active")
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    is_deleted: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="false")
    deleted_at = mapped_column(DateTime(timezone=True), nullable=True)
    created_by: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id"), nullable=False)
    created_at = ts_created()
    updated_at = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    items: Mapped[list["SaleItem"]] = relationship(backref="sale")
    plan: Mapped["InstallmentPlan"] = relationship(backref="sale", uselist=False,
                                                    primaryjoin="and_(Sale.id==InstallmentPlan.sale_id, InstallmentPlan.status!='superseded')",
                                                    viewonly=True)
    __table_args__ = (
        CheckConstraint("sale_type IN ('cash','installment')", name="ck_sale_type"),
        CheckConstraint("sale_channel IN ('store','online','agent')", name="ck_sale_channel"),
        CheckConstraint("status IN ('active','completed','cancelled')", name="ck_sale_status"),
        CheckConstraint("total_price = subtotal - discount_amount", name="ck_sale_total"),
        CheckConstraint("down_payment < total_price", name="ck_sale_down"),
        Index("uq_sales_number", "tenant_id", "sale_number", unique=True, postgresql_where=text("is_deleted = false")),
    )


class SaleItem(Base):
    __tablename__ = "sale_items"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("tenants.id"), nullable=False)
    sale_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("sales.id"), nullable=False)
    product_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("products.id"), nullable=False)
    variant_id: Mapped[int | None] = mapped_column(BigInteger, ForeignKey("product_variants.id"), nullable=True)
    name_snapshot: Mapped[str] = mapped_column(String(150), nullable=False)
    name_ar_snapshot: Mapped[str] = mapped_column(String(150), nullable=False)
    quantity: Mapped[int] = mapped_column(Integer, nullable=False)
    unit_price: Mapped[int] = mapped_column(BigInteger, nullable=False)
    item_discount: Mapped[int] = mapped_column(BigInteger, nullable=False, server_default="0")
    line_total: Mapped[int] = mapped_column(BigInteger, nullable=False)
    __table_args__ = (
        CheckConstraint("quantity > 0", name="ck_item_qty"),
        CheckConstraint("line_total = unit_price * quantity - item_discount", name="ck_item_total"),
    )


# ----------------------------------------------------------------- installments
class InstallmentPlan(Base):
    __tablename__ = "installment_plans"
    id: Mapped[int] = pk()
    public_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, server_default=func.gen_random_uuid(), unique=True)
    tenant_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("tenants.id"), nullable=False)
    sale_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("sales.id"), nullable=False)
    revision: Mapped[int] = mapped_column(Integer, nullable=False, server_default="1")
    supersedes_plan_id: Mapped[int | None] = mapped_column(BigInteger, ForeignKey("installment_plans.id"), nullable=True)
    principal_amount: Mapped[int] = mapped_column(BigInteger, nullable=False)
    months: Mapped[int] = mapped_column(Integer, nullable=False)
    monthly_amount: Mapped[int] = mapped_column(BigInteger, nullable=False)
    frequency: Mapped[str] = mapped_column(String(10), nullable=False, server_default="monthly")
    start_date: Mapped[Date] = mapped_column(Date, nullable=False)
    end_date: Mapped[Date] = mapped_column(Date, nullable=False)
    status: Mapped[str] = mapped_column(String(12), nullable=False, server_default="active")
    is_deleted: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="false")
    deleted_at = mapped_column(DateTime(timezone=True), nullable=True)
    created_by: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id"), nullable=False)
    created_at = ts_created()
    installments: Mapped[list["Installment"]] = relationship(backref="plan")
    __table_args__ = (
        CheckConstraint("status IN ('active','completed','defaulted','cancelled','superseded')", name="ck_plan_status"),
        UniqueConstraint("sale_id", "revision", name="uq_plan_rev"),
    )


class Installment(Base):
    __tablename__ = "installments"
    id: Mapped[int] = pk()
    public_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, server_default=func.gen_random_uuid(), unique=True)
    tenant_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("tenants.id"), nullable=False)
    plan_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("installment_plans.id"), nullable=False)
    installment_number: Mapped[int] = mapped_column(Integer, nullable=False)
    due_date: Mapped[Date] = mapped_column(Date, nullable=False)
    amount: Mapped[int] = mapped_column(BigInteger, nullable=False)
    status: Mapped[str] = mapped_column(String(12), nullable=False, server_default="scheduled")
    late_days: Mapped[int] = mapped_column(Integer, nullable=False, server_default="0")
    last_payment_at = mapped_column(DateTime(timezone=True), nullable=True)
    created_at = ts_created()
    __table_args__ = (
        CheckConstraint("amount > 0", name="ck_inst_amount"),
        CheckConstraint("status IN ('scheduled','cancelled')", name="ck_inst_status"),
        UniqueConstraint("plan_id", "installment_number", name="uq_inst_num"),
        Index("idx_inst_due", "due_date", postgresql_where=text("status = 'scheduled'")),
    )


class PlanRevision(Base):
    __tablename__ = "plan_revisions"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("tenants.id"), nullable=False)
    plan_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("installment_plans.id"), nullable=False)
    new_plan_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("installment_plans.id"), nullable=False)
    old_months: Mapped[int] = mapped_column(Integer, nullable=False)
    new_months: Mapped[int] = mapped_column(Integer, nullable=False)
    reason: Mapped[str] = mapped_column(Text, nullable=False)
    created_by: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id"), nullable=False)
    created_at = ts_created()


# ----------------------------------------------------------------- payments / ledger
class Payment(Base):
    __tablename__ = "payments"
    id: Mapped[int] = pk()
    public_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, server_default=func.gen_random_uuid(), unique=True)
    tenant_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("tenants.id"), nullable=False)
    receipt_number: Mapped[str] = mapped_column(String(20), nullable=False)
    idempotency_key: Mapped[str] = mapped_column(String(80), nullable=False)
    customer_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("customers.id"), nullable=False)
    sale_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("sales.id"), nullable=False)
    amount: Mapped[int] = mapped_column(BigInteger, nullable=False)
    fee_amount: Mapped[int] = mapped_column(BigInteger, nullable=False, server_default="0")
    payment_method: Mapped[str] = mapped_column(String(15), nullable=False)
    status: Mapped[str] = mapped_column(String(12), nullable=False, server_default="confirmed")
    reference_number: Mapped[str | None] = mapped_column(String(100), nullable=True)
    source: Mapped[str] = mapped_column(String(10), nullable=False, server_default="manual")
    received_by: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id"), nullable=False)
    reversed_payment_id: Mapped[int | None] = mapped_column(BigInteger, ForeignKey("payments.id"), nullable=True)
    transaction_group_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False)
    paid_at = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    created_by: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id"), nullable=False)
    created_at = ts_created()
    __table_args__ = (
        CheckConstraint("amount > 0", name="ck_pay_amount"),
        CheckConstraint("fee_amount >= 0", name="ck_pay_fee"),
        CheckConstraint("payment_method IN ('cash','qi','transfer','zaincash','visa')", name="ck_pay_method"),
        CheckConstraint("status IN ('pending','confirmed','failed','reversed')", name="ck_pay_status"),
        CheckConstraint("source IN ('manual','api','external')", name="ck_pay_source"),
        UniqueConstraint("tenant_id", "idempotency_key", name="uq_pay_idem"),
        UniqueConstraint("tenant_id", "receipt_number", name="uq_pay_receipt"),
    )


class PaymentAllocation(Base):
    __tablename__ = "payment_allocations"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("tenants.id"), nullable=False)
    payment_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("payments.id"), nullable=False)
    installment_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("installments.id"), nullable=False)
    amount: Mapped[int] = mapped_column(BigInteger, nullable=False)
    __table_args__ = (
        CheckConstraint("amount > 0", name="ck_alloc_amount"),
        Index("idx_alloc_inst", "installment_id"),
        Index("idx_alloc_pay", "payment_id"),
    )


class Account(Base):
    __tablename__ = "accounts"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("tenants.id"), nullable=False)
    code: Mapped[str] = mapped_column(String(10), nullable=False)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    name_ar: Mapped[str] = mapped_column(String(100), nullable=False)
    type: Mapped[str] = mapped_column(String(10), nullable=False)
    normal_balance: Mapped[str] = mapped_column(String(6), nullable=False)
    __table_args__ = (
        CheckConstraint("type IN ('asset','liability','equity','revenue','expense')", name="ck_acc_type"),
        CheckConstraint("normal_balance IN ('debit','credit')", name="ck_acc_normal"),
        UniqueConstraint("tenant_id", "code", name="uq_acc_code"),
    )


class LedgerEntry(Base):
    __tablename__ = "ledger_entries"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("tenants.id"), nullable=False)
    transaction_group_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False)
    account_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("accounts.id"), nullable=False)
    customer_id: Mapped[int | None] = mapped_column(BigInteger, ForeignKey("customers.id"), nullable=True)
    sale_id: Mapped[int | None] = mapped_column(BigInteger, ForeignKey("sales.id"), nullable=True)
    debit_amount: Mapped[int] = mapped_column(BigInteger, nullable=False, server_default="0")
    credit_amount: Mapped[int] = mapped_column(BigInteger, nullable=False, server_default="0")
    reference_type: Mapped[str] = mapped_column(String(20), nullable=False)
    reference_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    description: Mapped[str | None] = mapped_column(String(255), nullable=True)
    reversed_entry_id: Mapped[int | None] = mapped_column(BigInteger, ForeignKey("ledger_entries.id"), nullable=True)
    created_by: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id"), nullable=False)
    created_at = ts_created()
    __table_args__ = (
        CheckConstraint("reference_type IN ('sale','payment','reversal','reschedule')", name="ck_led_ref"),
        CheckConstraint("(debit_amount > 0 AND credit_amount = 0) OR (credit_amount > 0 AND debit_amount = 0)", name="ck_led_side"),
        Index("idx_led_account", "account_id"),
        Index("idx_led_customer", "customer_id"),
        Index("idx_led_group", "transaction_group_id"),
    )


# ----------------------------------------------------------------- events / audit / attachments / webhooks / notifications
class DomainEvent(Base):
    __tablename__ = "domain_events"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("tenants.id"), nullable=False)
    event_type: Mapped[str] = mapped_column(String(40), nullable=False)
    entity_type: Mapped[str] = mapped_column(String(30), nullable=False)
    entity_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    payload: Mapped[dict] = mapped_column(JSONB, nullable=False)
    status: Mapped[str] = mapped_column(String(10), nullable=False, server_default="pending")
    attempts: Mapped[int] = mapped_column(Integer, nullable=False, server_default="0")
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    processed_at = mapped_column(DateTime(timezone=True), nullable=True)
    created_at = ts_created()
    __table_args__ = (
        CheckConstraint("status IN ('pending','processed','failed')", name="ck_event_status"),
        Index("idx_events_pending", "created_at", postgresql_where=text("processed_at IS NULL")),
    )


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("tenants.id"), nullable=False)
    entity_type: Mapped[str] = mapped_column(String(30), nullable=False)
    entity_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    action: Mapped[str] = mapped_column(String(20), nullable=False)
    old_data: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
    new_data: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
    changed_by: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id"), nullable=False)
    created_at = ts_created()
    __table_args__ = (
        CheckConstraint("action IN ('create','update','delete','reschedule')", name="ck_audit_action"),
        Index("idx_audit_entity", "entity_type", "entity_id"),
    )


class Attachment(Base):
    __tablename__ = "attachments"
    id: Mapped[int] = pk()
    public_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, server_default=func.gen_random_uuid(), unique=True)
    tenant_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("tenants.id"), nullable=False)
    entity_type: Mapped[str] = mapped_column(String(30), nullable=False)
    entity_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    file_url: Mapped[str] = mapped_column(Text, nullable=False)
    file_type: Mapped[str] = mapped_column(String(20), nullable=False)
    uploaded_by: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id"), nullable=False)
    is_deleted: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="false")
    deleted_at = mapped_column(DateTime(timezone=True), nullable=True)
    created_at = ts_created()
    __table_args__ = (Index("idx_attach_entity", "tenant_id", "entity_type", "entity_id"),)


class WebhookEndpoint(Base):
    __tablename__ = "webhook_endpoints"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("tenants.id"), nullable=False)
    url: Mapped[str] = mapped_column(Text, nullable=False)
    secret: Mapped[str] = mapped_column(String(80), nullable=False)
    event_types: Mapped[list[str]] = mapped_column(ARRAY(Text), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="true")
    is_deleted: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="false")
    deleted_at = mapped_column(DateTime(timezone=True), nullable=True)
    created_at = ts_created()


class WebhookDelivery(Base):
    __tablename__ = "webhook_deliveries"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("tenants.id"), nullable=False)
    endpoint_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("webhook_endpoints.id"), nullable=False)
    event_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("domain_events.id"), nullable=False)
    status: Mapped[str] = mapped_column(String(10), nullable=False, server_default="pending")
    response_code: Mapped[int | None] = mapped_column(Integer, nullable=True)
    attempts: Mapped[int] = mapped_column(Integer, nullable=False, server_default="0")
    created_at = ts_created()
    __table_args__ = (CheckConstraint("status IN ('pending','sent','failed')", name="ck_whd_status"),)


class NotificationTemplate(Base):
    __tablename__ = "notification_templates"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("tenants.id"), nullable=False)
    key: Mapped[str] = mapped_column(String(40), nullable=False)
    channel: Mapped[str] = mapped_column(String(10), nullable=False)
    body_ar: Mapped[str] = mapped_column(Text, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="true")
    __table_args__ = (
        CheckConstraint("channel IN ('sms','whatsapp')", name="ck_tmpl_channel"),
        UniqueConstraint("tenant_id", "key", "channel", name="uq_tmpl"),
    )


class Notification(Base):
    __tablename__ = "notifications"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("tenants.id"), nullable=False)
    customer_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("customers.id"), nullable=False)
    channel: Mapped[str] = mapped_column(String(10), nullable=False)
    message: Mapped[str] = mapped_column(Text, nullable=False)
    related_type: Mapped[str] = mapped_column(String(20), nullable=False)
    related_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    status: Mapped[str] = mapped_column(String(10), nullable=False, server_default="pending")
    sent_at = mapped_column(DateTime(timezone=True), nullable=True)
    created_at = ts_created()
    __table_args__ = (
        CheckConstraint("channel IN ('sms','whatsapp')", name="ck_notif_channel"),
        CheckConstraint("status IN ('pending','sent','failed')", name="ck_notif_status"),
    )


class CollectionLog(Base):
    __tablename__ = "collection_logs"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("tenants.id"), nullable=False)
    installment_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("installments.id"), nullable=False)
    action: Mapped[str] = mapped_column(String(30), nullable=False)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_by: Mapped[int | None] = mapped_column(BigInteger, ForeignKey("users.id"), nullable=True)
    created_at = ts_created()
    __table_args__ = (CheckConstraint("action IN ('marked_late','notification_sent','manual_note')", name="ck_coll_action"),)


# Tables that get RLS tenant-isolation policies (DATA tables).
RLS_TABLES = [
    "customers", "categories", "products", "product_variants", "product_images",
    "sales", "sale_items",
    "installment_plans", "installments", "plan_revisions",
    "payments", "payment_allocations", "accounts", "ledger_entries",
    "domain_events", "audit_logs", "attachments", "webhook_endpoints",
    "webhook_deliveries", "notification_templates", "notifications",
    "collection_logs", "tenant_settings", "tenant_sequences", "request_idempotency",
]
