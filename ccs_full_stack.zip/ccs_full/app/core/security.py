from datetime import datetime, timedelta, timezone

import jwt
from passlib.context import CryptContext

from app.core.config import settings

_pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(p: str) -> str:
    return _pwd.hash(p)


def verify_password(p: str, h: str) -> bool:
    return _pwd.verify(p, h)


def create_access_token(*, user_id: int, tenant_id: int, permissions: list[str]) -> str:
    payload = {
        "sub": str(user_id),
        "tid": tenant_id,
        "perms": permissions,
        "exp": datetime.now(tz=timezone.utc) + timedelta(hours=settings.jwt_exp_hours),
    }
    return jwt.encode(payload, settings.jwt_secret, algorithm="HS256")


def decode_token(token: str) -> dict:
    d = jwt.decode(token, settings.jwt_secret, algorithms=["HS256"])
    return {"user_id": int(d["sub"]), "tenant_id": int(d["tid"]), "permissions": d.get("perms", [])}
