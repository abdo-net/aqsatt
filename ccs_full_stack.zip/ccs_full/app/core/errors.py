from fastapi import HTTPException


def not_found(detail="Not found"): return HTTPException(404, detail)
def conflict(detail): return HTTPException(409, detail)
def bad_request(detail): return HTTPException(400, detail)
def forbidden(detail="Forbidden"): return HTTPException(403, detail)
def unauthorized(detail="Unauthorized"): return HTTPException(401, detail)


class LedgerImbalance(Exception):
    """Raised before commit if debits != credits. Forces rollback + 500."""
