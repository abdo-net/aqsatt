from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    database_url: str = "postgresql+psycopg2://ccs_app:ccs_app_pass@localhost:5432/ccs"
    admin_database_url: str = "postgresql+psycopg2://postgres@localhost:5432/ccs"

    jwt_secret: str = "dev-secret-change-me"
    jwt_exp_hours: int = 12

    default_tenant_name: str = "Default Store"
    default_tenant_slug: str = "default"
    default_admin_username: str = "admin"
    default_admin_password: str = "admin123"

    whatsapp_api_url: str = ""
    whatsapp_api_token: str = ""

    # Comma-separated list of origins allowed to call this API with credentials
    # (cookies). The Next.js dev server and its production domain both need to
    # be listed explicitly — CORS with allow_credentials=True does not permit
    # a wildcard "*" origin, by spec, so this must be an exact list.
    cors_origins: str = "http://localhost:3000,http://127.0.0.1:3000"

    @property
    def cors_origin_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]


settings = Settings()
