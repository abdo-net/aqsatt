"""Pagination envelope for list endpoints.

Every list endpoint in this API used to return a bare JSON array with no
total count. That worked for the old hash-routed SPA, which just rendered
whatever page_size it asked for. It does not work for a TanStack Table
server-side pagination UI, which needs total_count to render "Page 3 of 12"
and to disable/enable next-page controls correctly.

This module is intentionally the ONLY thing that changes about these
endpoints. Filtering, ordering, RLS, and the underlying query logic are
untouched — we just run one extra COUNT query and wrap the existing rows
in a consistent envelope:

    {"data": [...], "page": 1, "page_size": 50, "total_count": 137, "total_pages": 3}

Usage in a router:

    from app.core.pagination import paginate

    @router.get("")
    def list_x(page: int = Query(1, ge=1), page_size: int = Query(50, ge=1, le=200), ...):
        stmt = select(X).where(...)
        return paginate(db, stmt, page, page_size, serializer=_out)
"""
from __future__ import annotations

from typing import Callable, TypeVar

from sqlalchemy import func, select
from sqlalchemy.orm import Session
from sqlalchemy.sql import Select

T = TypeVar("T")


def paginate(
    db: Session,
    stmt: Select,
    page: int,
    page_size: int,
    serializer: Callable[[object], dict] | None = None,
    order_by=None,
) -> dict:
    """Run a COUNT against the unpaginated statement, then apply offset/limit
    and return the standard envelope. `stmt` must NOT already have
    .offset()/.limit() applied — this function owns that.

    `serializer` is called per-row if the row needs transformation beyond
    what the ORM gives you (e.g. _card_out(db, p) which itself issues
    additional queries for variants/images). If the rows are already
    plain dicts (some serializers pre-fetch and build dicts before this
    point), pass serializer=None and pre-serialize before calling paginate,
    or pass a no-op lambda.
    """
    total_count = db.execute(select(func.count()).select_from(stmt.subquery())).scalar_one()

    paged_stmt = stmt
    if order_by is not None:
        paged_stmt = paged_stmt.order_by(order_by)
    paged_stmt = paged_stmt.offset((page - 1) * page_size).limit(page_size)

    rows = db.execute(paged_stmt).scalars().all()
    data = [serializer(r) for r in rows] if serializer else list(rows)

    total_pages = (total_count + page_size - 1) // page_size if page_size else 0

    return {
        "data": data,
        "page": page,
        "page_size": page_size,
        "total_count": total_count,
        "total_pages": max(total_pages, 1) if total_count else 0,
    }
