import jwt
from fastapi import Depends, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from app.core.security import decode_token
from app.core.errors import forbidden, unauthorized
from app.db.base import SessionLocal, set_tenant, clear_tenant

bearer = HTTPBearer(auto_error=False)


def get_current_user(creds: HTTPAuthorizationCredentials | None = Depends(bearer)) -> dict:
    if creds is None:
        raise unauthorized("Missing bearer token")
    try:
        return decode_token(creds.credentials)
    except jwt.ExpiredSignatureError:
        raise unauthorized("Token expired")
    except jwt.PyJWTError:
        raise unauthorized("Invalid token")


def get_db(user: dict = Depends(get_current_user)):
    """Authenticated DB session with RLS tenant context bound to the JWT tenant.
    The context is re-applied on every transaction begin, so it is robust across
    commit/refresh and pooled-connection recycling."""
    db = SessionLocal()
    try:
        set_tenant(db, user["tenant_id"])
        yield db
    finally:
        clear_tenant(db)
        db.close()


def require_permission(*needed: str):
    def checker(user: dict = Depends(get_current_user)):
        perms = set(user.get("permissions", []))
        if not set(needed).issubset(perms):
            raise forbidden(f"Requires permission(s): {', '.join(needed)}")
        return user
    return checker
