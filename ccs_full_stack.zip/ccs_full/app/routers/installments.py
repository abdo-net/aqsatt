from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.deps import get_db, require_permission
from app.core.errors import not_found
from app.models import Installment, InstallmentPlan
from app.services import payment_service

router = APIRouter(prefix="/api/v1/plans", tags=["installments"])


@router.get("/{plan_id}/schedule")
def schedule(plan_id: int, db: Session = Depends(get_db),
             user=Depends(require_permission("plans.read"))):
    plan = db.get(InstallmentPlan, plan_id)
    if not plan:
        raise not_found("plan not found")
    insts = db.execute(select(Installment).where(Installment.plan_id == plan_id)
                       .order_by(Installment.installment_number)).scalars().all()
    return {"plan_id": plan_id, "status": plan.status,
            "schedule": [payment_service.installment_state(db, i) for i in insts]}
