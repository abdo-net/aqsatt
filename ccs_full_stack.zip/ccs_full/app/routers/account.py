"""Self-service account (profile, own password) + tenant settings.
Additive over existing tables (users, tenant_settings, tenants). No schema change."""
from datetime import datetime, timezone

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.deps import get_current_user, get_db, require_permission
from app.core.errors import bad_request, unauthorized
from app.core.security import hash_password, verify_password
from app.models import Tenant, TenantSetting, User
from app.routers.auth import resolve_permissions
from app.schemas import PasswordChange, ProfileUpdate, SettingUpsert

router = APIRouter(prefix="/api/v1", tags=["account"])


@router.get("/me")
def me(db: Session = Depends(get_db), user=Depends(get_current_user)):
    u = db.get(User, user["user_id"])
    return {"id": u.id, "name": u.name, "username": u.username, "tenant_id": user["tenant_id"],
            "permissions": resolve_permissions(db, u.id, user["tenant_id"])}


@router.patch("/me")
def update_me(body: ProfileUpdate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    u = db.get(User, user["user_id"])
    u.name = body.name
    db.commit()
    return {"id": u.id, "name": u.name, "username": u.username}


@router.post("/me/password")
def change_my_password(body: PasswordChange, db: Session = Depends(get_db), user=Depends(get_current_user)):
    u = db.get(User, user["user_id"])
    if not verify_password(body.old_password, u.password_hash):
        raise unauthorized("current password is incorrect")
    if body.old_password == body.new_password:
        raise bad_request("new password must differ")
    u.password_hash = hash_password(body.new_password)
    u.updated_at = datetime.now(tz=timezone.utc)
    db.commit()
    return {"status": "password_changed"}


@router.get("/tenant")
def tenant_info(db: Session = Depends(get_db), user=Depends(get_current_user)):
    tnt = db.get(Tenant, user["tenant_id"])
    return {"id": tnt.id, "name": tnt.name, "slug": tnt.slug, "type": tnt.type,
            "currency_code": tnt.currency_code, "timezone": tnt.timezone, "status": tnt.status}


@router.get("/settings")
def get_settings(db: Session = Depends(get_db), user=Depends(require_permission("settings.manage"))):
    rows = db.execute(select(TenantSetting).where(TenantSetting.tenant_id == user["tenant_id"])).scalars().all()
    return {r.key: r.value for r in rows}


@router.put("/settings/{key}")
def upsert_setting(key: str, body: SettingUpsert, db: Session = Depends(get_db),
                   user=Depends(require_permission("settings.manage"))):
    tid = user["tenant_id"]
    row = db.execute(select(TenantSetting).where(
        TenantSetting.tenant_id == tid, TenantSetting.key == key)).scalar_one_or_none()
    if row:
        row.value = body.value
        row.updated_by = user["user_id"]
        row.updated_at = datetime.now(tz=timezone.utc)
    else:
        db.add(TenantSetting(tenant_id=tid, key=key, value=body.value, updated_by=user["user_id"]))
    db.commit()
    return {"key": key, "value": body.value}
