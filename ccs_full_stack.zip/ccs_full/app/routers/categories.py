"""Category catalog (table already existed). Read/write gated by product perms."""
from datetime import datetime, timezone

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.deps import get_db, require_permission
from app.core.errors import not_found
from app.models import Category, Product
from app.schemas import CategoryCreate

router = APIRouter(prefix="/api/v1/categories", tags=["categories"])


@router.get("")
def list_categories(db: Session = Depends(get_db), user=Depends(require_permission("products.read"))):
    cats = db.execute(select(Category).where(Category.is_deleted == False)  # noqa: E712
                      .order_by(Category.id)).scalars().all()
    out = []
    for c in cats:
        n = db.execute(select(Product.id).where(Product.category_id == c.id, Product.is_deleted == False)).all()  # noqa: E712
        out.append({"id": c.id, "name": c.name, "name_ar": c.name_ar, "product_count": len(n)})
    return out


@router.post("", status_code=201)
def create_category(body: CategoryCreate, db: Session = Depends(get_db),
                    user=Depends(require_permission("products.write"))):
    c = Category(tenant_id=user["tenant_id"], name=body.name, name_ar=body.name_ar or body.name)
    db.add(c)
    db.commit()
    db.refresh(c)
    return {"id": c.id, "name": c.name, "name_ar": c.name_ar, "product_count": 0}


@router.delete("/{category_id}", status_code=200)
def delete_category(category_id: int, db: Session = Depends(get_db),
                    user=Depends(require_permission("products.write"))):
    c = db.get(Category, category_id)
    if not c or c.is_deleted:
        raise not_found("category not found")
    c.is_deleted = True
    c.deleted_at = datetime.now(tz=timezone.utc)
    db.commit()
    return {"id": category_id, "is_deleted": True}
