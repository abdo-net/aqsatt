"""Products + variants + images. Extends the original product API additively:
- backward compatible: {sku,name,name_ar,base_price,stock_quantity} still works
- variants: if none supplied, a default variant mirroring the product is created
- product.stock_quantity stays authoritative for the (untouched) sales flow; when
  variants are supplied it is kept as the SUM of variant stock, and base_price as
  the default variant's cash price.
"""
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, Query, UploadFile, File
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.deps import get_db, require_permission
from app.core.errors import bad_request, conflict, not_found
from app.core.pagination import paginate
from app.models import Category, Product, ProductImage, ProductVariant
from app.schemas import ProductCreate, ProductUpdate, VariantIn, VariantUpdate
from app.services import image_service

router = APIRouter(prefix="/api/v1/products", tags=["products"])
MAX_IMAGES = 8


# ---------------------------------------------------------------- serializers
def _variant_out(v: ProductVariant) -> dict:
    inst = v.price_installment or v.price_cash
    disc = None
    if v.compare_price and v.compare_price > v.price_cash:
        disc = round((v.compare_price - v.price_cash) / v.compare_price * 100)
    return {"id": v.id, "sku": v.sku, "price_cash": v.price_cash, "price_installment": inst,
            "compare_price": v.compare_price, "cost_price": v.cost_price,
            "stock_quantity": v.stock_quantity, "attributes": v.attributes or {},
            "is_default": v.is_default, "discount_pct": disc}


def _images(db, product_id) -> list[dict]:
    rows = db.execute(select(ProductImage).where(
        ProductImage.product_id == product_id, ProductImage.is_deleted == False)  # noqa: E712
        .order_by(ProductImage.sort_order, ProductImage.id)).scalars().all()
    return [{"id": i.id, "path": i.path, "thumb_path": i.thumb_path,
             "variant_id": i.variant_id, "sort_order": i.sort_order} for i in rows]


def _variants(db, product_id) -> list[ProductVariant]:
    return db.execute(select(ProductVariant).where(
        ProductVariant.product_id == product_id, ProductVariant.is_deleted == False)  # noqa: E712
        .order_by(ProductVariant.is_default.desc(), ProductVariant.id)).scalars().all()


def _card_out(db, p: Product) -> dict:
    vs = _variants(db, p.id)
    default = next((v for v in vs if v.is_default), vs[0] if vs else None)
    imgs = _images(db, p.id)
    out = {"id": p.id, "public_id": str(p.public_id), "sku": p.sku, "name": p.name,
           "name_ar": p.name_ar, "category_id": p.category_id, "base_price": p.base_price,
           "stock_quantity": p.stock_quantity, "is_active": p.is_active, "status": p.status,
           "brand": p.brand, "tags": p.tags, "variant_count": len(vs),
           "primary_image": imgs[0] if imgs else None}
    if default:
        out["price_cash"] = default.price_cash
        out["price_installment"] = default.price_installment or default.price_cash
        out["compare_price"] = default.compare_price
        out["discount_pct"] = _variant_out(default)["discount_pct"]
    else:
        out["price_cash"] = p.base_price
        out["price_installment"] = p.base_price
        out["compare_price"] = None
        out["discount_pct"] = None
    return out


def _detail_out(db, p: Product) -> dict:
    out = _card_out(db, p)
    out["description"] = p.description
    out["variants"] = [_variant_out(v) for v in _variants(db, p.id)]
    out["images"] = _images(db, p.id)
    if p.category_id:
        c = db.get(Category, p.category_id)
        out["category"] = {"id": c.id, "name": c.name, "name_ar": c.name_ar} if c and not c.is_deleted else None
    else:
        out["category"] = None
    return out


def _sync_aggregate(p: Product, variants: list[ProductVariant]):
    """Keep product.stock_quantity = sum(variant stock) and base_price = default
    variant cash price, so the unchanged sales flow sees correct totals."""
    live = [v for v in variants if not v.is_deleted]
    if not live:
        return
    p.stock_quantity = sum(v.stock_quantity for v in live)
    default = next((v for v in live if v.is_default), live[0])
    p.base_price = default.price_cash


# ---------------------------------------------------------------- create
@router.post("", status_code=201)
def create(body: ProductCreate, db: Session = Depends(get_db),
           user=Depends(require_permission("products.write"))):
    tid = user["tenant_id"]
    name_ar = body.name_ar or body.name
    variants_in = body.variants or []
    if not variants_in and body.base_price is None:
        raise bad_request("base_price required when no variants are provided")

    # base price for the product row = explicit base_price OR default variant cash price
    if variants_in:
        default_idx = next((i for i, v in enumerate(variants_in) if v.is_default), 0)
        base_price = variants_in[default_idx].price_cash
        stock = sum(v.stock_quantity for v in variants_in)
    else:
        base_price, stock, default_idx = body.base_price, body.stock_quantity, None

    p = Product(tenant_id=tid, sku=body.sku, name=body.name, name_ar=name_ar,
                category_id=body.category_id, base_price=base_price, stock_quantity=stock,
                description=body.description, brand=body.brand, tags=body.tags,
                status=body.status if body.status in ("draft", "active") else "active")
    db.add(p)
    try:
        db.flush()
    except IntegrityError:
        db.rollback()
        raise conflict("sku already exists")

    # variants (explicit or one auto default mirroring the product)
    if variants_in:
        for i, v in enumerate(variants_in):
            db.add(ProductVariant(
                tenant_id=tid, product_id=p.id, sku=v.sku or f"{body.sku}-{i+1}",
                price_cash=v.price_cash, price_installment=v.price_installment,
                compare_price=v.compare_price, cost_price=v.cost_price,
                stock_quantity=v.stock_quantity, attributes=v.attributes,
                is_default=(i == default_idx)))
    else:
        db.add(ProductVariant(tenant_id=tid, product_id=p.id, sku=body.sku,
                              price_cash=base_price, price_installment=base_price,
                              stock_quantity=stock, is_default=True))
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise conflict("duplicate variant sku")
    db.refresh(p)
    return _detail_out(db, p)


@router.get("")
def list_products(page: int = Query(1, ge=1), page_size: int = Query(100, ge=1, le=200),
                  category_id: int | None = None, q: str | None = None, status: str | None = None,
                  db: Session = Depends(get_db), user=Depends(require_permission("products.read"))):
    stmt = select(Product).where(Product.is_deleted == False)  # noqa: E712
    if category_id:
        stmt = stmt.where(Product.category_id == category_id)
    if status:
        stmt = stmt.where(Product.status == status)
    if q:
        like = f"%{q}%"
        stmt = stmt.where((Product.name.ilike(like)) | (Product.name_ar.ilike(like)) | (Product.sku.ilike(like)))
    return paginate(db, stmt, page, page_size, serializer=lambda p: _card_out(db, p), order_by=Product.id.desc())


@router.get("/{product_id}")
def get(product_id: int, db: Session = Depends(get_db),
        user=Depends(require_permission("products.read"))):
    p = db.get(Product, product_id)
    if not p or p.is_deleted:
        raise not_found("product not found")
    return _detail_out(db, p)


@router.patch("/{product_id}")
def update(product_id: int, body: ProductUpdate, db: Session = Depends(get_db),
           user=Depends(require_permission("products.write"))):
    p = db.get(Product, product_id)
    if not p or p.is_deleted:
        raise not_found("product not found")
    data = body.model_dump(exclude_unset=True)
    if "status" in data and data["status"] not in ("draft", "active"):
        data.pop("status")
    # if base_price/stock changed directly and product has a single default variant, mirror it
    for k, v in data.items():
        setattr(p, k, v)
    vs = _variants(db, p.id)
    if len(vs) == 1 and vs[0].is_default:
        if "base_price" in data:
            vs[0].price_cash = data["base_price"]
            vs[0].price_installment = vs[0].price_installment or data["base_price"]
        if "stock_quantity" in data:
            vs[0].stock_quantity = data["stock_quantity"]
    db.commit()
    db.refresh(p)
    return _detail_out(db, p)


@router.delete("/{product_id}", status_code=200)
def soft_delete(product_id: int, db: Session = Depends(get_db),
                user=Depends(require_permission("products.write"))):
    p = db.get(Product, product_id)
    if not p or p.is_deleted:
        raise not_found("product not found")
    p.is_deleted = True
    p.deleted_at = datetime.now(tz=timezone.utc)
    db.commit()
    return {"id": product_id, "is_deleted": True}


# ---------------------------------------------------------------- variants
@router.post("/{product_id}/variants", status_code=201)
def add_variant(product_id: int, body: VariantIn, db: Session = Depends(get_db),
                user=Depends(require_permission("products.write"))):
    p = db.get(Product, product_id)
    if not p or p.is_deleted:
        raise not_found("product not found")
    vs = _variants(db, product_id)
    v = ProductVariant(tenant_id=user["tenant_id"], product_id=product_id,
                       sku=body.sku or f"{p.sku}-{len(vs)+1}", price_cash=body.price_cash,
                       price_installment=body.price_installment, compare_price=body.compare_price,
                       cost_price=body.cost_price, stock_quantity=body.stock_quantity,
                       attributes=body.attributes, is_default=(len(vs) == 0))
    db.add(v)
    try:
        db.flush()
    except IntegrityError:
        db.rollback()
        raise conflict("duplicate variant sku")
    _sync_aggregate(p, _variants(db, product_id) + [v])
    db.commit()
    db.refresh(p)
    return _detail_out(db, p)


@router.patch("/{product_id}/variants/{variant_id}")
def update_variant(product_id: int, variant_id: int, body: VariantUpdate,
                   db: Session = Depends(get_db), user=Depends(require_permission("products.write"))):
    v = db.get(ProductVariant, variant_id)
    if not v or v.is_deleted or v.product_id != product_id:
        raise not_found("variant not found")
    for k, val in body.model_dump(exclude_unset=True).items():
        setattr(v, k, val)
    p = db.get(Product, product_id)
    _sync_aggregate(p, _variants(db, product_id))
    db.commit()
    db.refresh(p)
    return _detail_out(db, p)


# ---------------------------------------------------------------- images
@router.get("/{product_id}/images")
def list_images(product_id: int, db: Session = Depends(get_db),
                user=Depends(require_permission("products.read"))):
    return _images(db, product_id)


@router.post("/{product_id}/images", status_code=201)
async def upload_images(product_id: int, files: list[UploadFile] = File(...),
                        db: Session = Depends(get_db), user=Depends(require_permission("products.write"))):
    p = db.get(Product, product_id)
    if not p or p.is_deleted:
        raise not_found("product not found")
    existing = _images(db, product_id)
    if len(existing) + len(files) > MAX_IMAGES:
        raise bad_request(f"max {MAX_IMAGES} images per product")
    order = (max((i["sort_order"] for i in existing), default=-1)) + 1
    for f in files:
        raw = await f.read()
        try:
            path, thumb = image_service.save_square_image(raw, user["tenant_id"], product_id)
        except ValueError as e:
            raise bad_request(str(e))
        db.add(ProductImage(tenant_id=user["tenant_id"], product_id=product_id,
                            path=path, thumb_path=thumb, sort_order=order))
        order += 1
    db.commit()
    return _images(db, product_id)


@router.delete("/{product_id}/images/{image_id}", status_code=200)
def delete_image(product_id: int, image_id: int, db: Session = Depends(get_db),
                 user=Depends(require_permission("products.write"))):
    img = db.get(ProductImage, image_id)
    if not img or img.is_deleted or img.product_id != product_id:
        raise not_found("image not found")
    img.is_deleted = True
    db.commit()
    return {"id": image_id, "is_deleted": True}
