from fastapi import APIRouter, Depends, Query
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.deps import get_db, require_permission
from app.models import Installment, Payment, PaymentAllocation
from app.schemas import PaymentCreate
from app.services import payment_service

router = APIRouter(prefix="/api/v1/payments", tags=["payments"])


@router.get("")
def list_payments(sale_id: int | None = None, customer_id: int | None = None,
                  limit: int = Query(100, ge=1, le=300),
                  db: Session = Depends(get_db), user=Depends(require_permission("payments.read"))):
    stmt = select(Payment).order_by(Payment.id.desc()).limit(limit)
    if sale_id:
        stmt = select(Payment).where(Payment.sale_id == sale_id).order_by(Payment.id.desc()).limit(limit)
    elif customer_id:
        stmt = select(Payment).where(Payment.customer_id == customer_id).order_by(Payment.id.desc()).limit(limit)
    out = []
    for p in db.execute(stmt).scalars().all():
        allocs = []
        for a in db.execute(select(PaymentAllocation).where(PaymentAllocation.payment_id == p.id)).scalars().all():
            inst = db.get(Installment, a.installment_id)
            allocs.append({"installment_number": inst.installment_number if inst else None, "amount": a.amount})
        out.append({"id": p.id, "receipt_number": p.receipt_number, "sale_id": p.sale_id,
                    "customer_id": p.customer_id, "amount": p.amount, "fee_amount": p.fee_amount,
                    "payment_method": p.payment_method, "status": p.status,
                    "paid_at": p.paid_at.isoformat() if p.paid_at else None, "allocations": allocs})
    return out


@router.post("")
def create_payment(body: PaymentCreate, db: Session = Depends(get_db),
                   user=Depends(require_permission("payments.create"))):
    try:
        txn, allocs, plan, sale, replay = payment_service.record_payment(
            db, tenant_id=user["tenant_id"], user_id=user["user_id"],
            idempotency_key=body.idempotency_key, sale_id=body.sale_id, amount=body.amount,
            payment_method=body.payment_method, reference_number=body.reference_number, source=body.source,
        )
        if not replay:
            db.commit()
        db.refresh(txn)
    except Exception:
        db.rollback()
        raise
    return {
        "id": txn.id, "public_id": str(txn.public_id), "receipt_number": txn.receipt_number,
        "sale_id": txn.sale_id, "customer_id": txn.customer_id, "amount": txn.amount,
        "fee_amount": txn.fee_amount, "payment_method": txn.payment_method, "status": txn.status,
        "allocations": allocs, "plan_status": plan.status if plan else None,
        "sale_status": sale.status, "replayed": replay,
    }
