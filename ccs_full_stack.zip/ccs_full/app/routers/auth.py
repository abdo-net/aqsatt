from fastapi import APIRouter
from sqlalchemy import select

from app.core.errors import unauthorized
from app.core.security import create_access_token, verify_password
from app.db.base import SessionLocal
from app.models import Permission, Role, RolePermission, TenantMembership, User, UserRole
from app.schemas import LoginRequest, LoginResponse

router = APIRouter(prefix="/api/v1/auth", tags=["auth"])


def resolve_permissions(db, user_id: int, tenant_id: int) -> list[str]:
    rows = db.execute(
        select(Permission.code)
        .join(RolePermission, RolePermission.permission_id == Permission.id)
        .join(Role, Role.id == RolePermission.role_id)
        .join(UserRole, UserRole.role_id == Role.id)
        .where(UserRole.user_id == user_id, UserRole.tenant_id == tenant_id)
    ).scalars().all()
    return sorted(set(rows))


@router.post("/login", response_model=LoginResponse)
def login(body: LoginRequest):
    # Auth runs without tenant context (users table is not RLS-scoped).
    db = SessionLocal()
    try:
        user = db.execute(select(User).where(User.username == body.username)).scalar_one_or_none()
        if not user or user.is_deleted or not user.is_active or not verify_password(body.password, user.password_hash):
            raise unauthorized("invalid credentials")
        membership = db.execute(
            select(TenantMembership).where(
                TenantMembership.user_id == user.id, TenantMembership.is_active == True,  # noqa: E712
                TenantMembership.is_deleted == False)  # noqa: E712
        ).scalars().first()
        if not membership:
            raise unauthorized("no active tenant membership")
        tenant_id = membership.tenant_id
        perms = resolve_permissions(db, user.id, tenant_id)
        token = create_access_token(user_id=user.id, tenant_id=tenant_id, permissions=perms)
        return LoginResponse(access_token=token, tenant_id=tenant_id, user_id=user.id, permissions=perms)
    finally:
        db.close()
