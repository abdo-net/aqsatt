# CCS Web — Next.js Frontend

Decoupled frontend for the Credit Commerce System (CCS), built with Next.js
16 (App Router), Tailwind CSS v4, shadcn/ui (Radix primitives), TanStack
Query, and TanStack Table. Talks to the FastAPI backend in the sibling
`ccs_full/` directory exclusively through this app's own `/api/*` Route
Handlers — the browser never holds a bearer token or talks to FastAPI
directly.

## Architecture summary

- **Auth**: `POST /api/auth/login` proxies to FastAPI, then sets the JWT as
  an httpOnly, sameSite=lax cookie (`ccs_token`). The browser's JS never
  sees the token.
- **Data fetching**: every API call goes through `GET/POST/PATCH/DELETE
  /api/proxy/[...path]`, which reads the cookie server-side and attaches
  `Authorization: Bearer <token>` before forwarding to FastAPI.
- **Route protection**: `src/proxy.ts` (Next.js 16's renamed
  `middleware.ts` convention) redirects unauthenticated page requests to
  `/login`. API routes under `/api/*` are never redirected — they return
  their own JSON error responses.
- **Images**: product/category images are public static files served
  directly by FastAPI (`/static/uploads/...`) and loaded by the browser
  from `NEXT_PUBLIC_ASSET_BASE_URL` (or `API_BASE_URL` if unset) — see
  `src/lib/asset-url.ts`.

## Required environment variables

Copy `.env.example` to `.env.local` (or `.env.production` on the server)
and fill in the real values:

```
API_BASE_URL=http://127.0.0.1:8000
# NEXT_PUBLIC_ASSET_BASE_URL=https://api.yourdomain.com   # only if different from API_BASE_URL
```

The FastAPI backend also needs `CORS_ORIGINS` updated to include this
frontend's real production URL — see `ccs_full/.env.example`.

## VPS deployment (manual, no Vercel)

These steps assume Ubuntu/Debian with Node.js 20+ already available
(matching what FastAPI's own deployment notes assume) and that the FastAPI
backend (`ccs_full/`) is already running per its own README/`.env`.

1. **Copy this directory to the server** alongside `ccs_full/` (they can
   live as sibling directories, e.g. `/opt/ccs/ccs_full` and
   `/opt/ccs/ccs-web`).

2. **Install dependencies** (this is why `node_modules/` is excluded from
   the zip — installing fresh avoids shipping platform-specific native
   binaries that may not match the server's architecture):
   ```bash
   cd ccs-web
   npm install
   ```

3. **Create the production env file:**
   ```bash
   cp .env.example .env.production
   # edit .env.production: set API_BASE_URL to wherever FastAPI is
   # actually reachable from this process (often http://127.0.0.1:8000
   # if both run on the same VPS).
   ```

4. **Update the backend's CORS allow-list** so it accepts requests from
   this frontend's real domain (edit `ccs_full/.env`):
   ```
   CORS_ORIGINS=https://your-frontend-domain.com
   ```
   Restart the FastAPI process after changing this.

5. **Build for production:**
   ```bash
   npm run build
   ```

6. **Run it.** Either directly:
   ```bash
   npm run start -- --port 3000
   ```
   or under a process manager (recommended for a real deployment) such as
   `pm2`:
   ```bash
   npm install -g pm2
   pm2 start npm --name ccs-web -- run start
   pm2 save
   ```

7. **Put a reverse proxy in front of it** (nginx, Caddy, etc.) to terminate
   TLS and forward to `localhost:3000`. A minimal nginx server block:
   ```nginx
   server {
       listen 443 ssl;
       server_name your-frontend-domain.com;
       location / {
           proxy_pass http://127.0.0.1:3000;
           proxy_set_header Host $host;
           proxy_set_header X-Forwarded-Proto $scheme;
       }
   }
   ```

8. **Verify the full flow** before considering the deploy done:
   - Visit the site, confirm `/login` renders with no console errors.
   - Log in with a real account; confirm you land on `/dashboard` with
     real numbers (not placeholders).
   - Open browser devtools → Application → Cookies, confirm `ccs_token`
     is present and marked `HttpOnly`.
   - Create a test customer, product, and sale; confirm they appear
     immediately (TanStack Query cache invalidation working) and that
     amounts render as plain integers with Latin digits (e.g. `500,000
     IQD`, never `٥٠٠٬٠٠٠` or `500,000.0`).

## Local development

```bash
npm install
cp .env.example .env.local   # point API_BASE_URL at your local FastAPI (e.g. :8000)
npm run dev
```

Requires the FastAPI backend running separately (see `ccs_full/README.md`),
with `CORS_ORIGINS` in its `.env` including `http://localhost:3000`.

## Verification commands

```bash
npm run build   # production build + type-check; must be clean before deploying
npm run lint    # ESLint, including React Compiler's hook-correctness rules
```

Both must report zero errors before any deploy.
