export interface DashboardSummary {
  total_outstanding: number;
  total_cash_collected: number;
  today_payments: number;
  overdue_count: number;
  customers_count: number;
  active_sales_count: number;
}
