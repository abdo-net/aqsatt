export interface PaymentAllocationRow {
  installment_number: number | null;
  amount: number;
}

export interface Payment {
  id: number;
  receipt_number: string;
  sale_id: number;
  customer_id: number;
  amount: number;
  fee_amount: number;
  payment_method: string;
  status: string;
  paid_at: string | null;
  allocations: PaymentAllocationRow[];
}

export interface PaymentCreateInput {
  idempotency_key: string;
  sale_id: number;
  amount: number;
  payment_method: string;
  reference_number?: string;
  source?: string;
}

export interface PaymentCreateResult {
  id: number;
  public_id: string;
  receipt_number: string;
  sale_id: number;
  customer_id: number;
  amount: number;
  fee_amount: number;
  payment_method: string;
  status: string;
  allocations: PaymentAllocationRow[];
  plan_status: string | null;
  sale_status: string;
  replayed: boolean;
}

export interface LedgerLine {
  account_code: string;
  account_name: string;
  account_name_ar: string;
  debit: number;
  credit: number;
  description: string | null;
  customer_id: number | null;
  sale_id: number | null;
}

export interface LedgerTransactionGroup {
  transaction_group_id: string;
  reference_type: string;
  reference_id: number;
  created_at: string;
  lines: LedgerLine[];
  total: number;
}

export interface LedgerAccount {
  code: string;
  name: string;
  name_ar: string;
  type: string;
  normal_balance: "debit" | "credit";
  balance: number;
}
