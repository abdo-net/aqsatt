export type SaleType = "cash" | "installment";
export type SaleStatus = "active" | "completed" | "cancelled";
export type InstallmentStatus =
  | "pending"
  | "partially_paid"
  | "paid"
  | "late"
  | "cancelled";

export interface SaleItem {
  product_id: number;
  variant_id: number | null;
  name: string;
  name_ar: string | null;
  quantity: number;
  unit_price: number;
  item_discount: number;
  line_total: number;
}

export interface InstallmentScheduleRow {
  installment_number: number;
  due_date: string;
  amount: number;
  paid: number;
  remaining: number;
  status: InstallmentStatus;
  late_days: number;
}

export interface InstallmentPlan {
  id: number;
  principal_amount: number;
  months: number;
  monthly_amount: number;
  frequency: string;
  start_date: string;
  end_date: string;
  status: string;
  schedule: InstallmentScheduleRow[];
}

export interface Sale {
  id: number;
  public_id: string;
  sale_number: string;
  customer_id: number;
  sale_type: SaleType;
  sale_channel: string;
  subtotal: number;
  discount_amount: number;
  total_price: number;
  down_payment: number;
  status: SaleStatus;
  notes: string | null;
  created_at: string;
  items: SaleItem[];
  plan: InstallmentPlan | null;
}

export interface SaleItemInput {
  product_id: number;
  variant_id?: number | null;
  quantity: number;
  item_discount?: number;
}

export interface SaleCreateInput {
  idempotency_key: string;
  customer_id: number;
  sale_type: SaleType;
  items: SaleItemInput[];
  discount_amount?: number;
  down_payment?: number;
  months?: number;
  frequency?: string;
  start_date?: string;
  sale_channel?: string;
  salesperson_id?: number | null;
  notes?: string;
}
