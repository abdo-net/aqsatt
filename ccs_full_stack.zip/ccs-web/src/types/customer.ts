export interface PaginatedResponse<T> {
  data: T[];
  page: number;
  page_size: number;
  total_count: number;
  total_pages: number;
}

export type RiskClass = "trusted" | "qi" | "mixed";
export type CustomerStatus = "active" | "blocked";

export interface Customer {
  id: number;
  public_id: string;
  full_name: string;
  phone: string;
  alt_phone: string | null;
  national_id: string | null;
  address: string | null;
  notes: string | null;
  risk_class: RiskClass;
  status: CustomerStatus;
  created_at: string;
  receivable_balance: number;
  next_due: string | null;
  is_overdue: boolean;
}

export interface CustomerCreateInput {
  full_name: string;
  phone: string;
  alt_phone?: string | null;
  national_id?: string | null;
  address?: string | null;
  notes?: string | null;
  risk_class?: RiskClass;
}

export interface CustomerProfileSale {
  id: number;
  sale_number: string;
  type: "cash" | "installment";
  total_price: number;
  status: "active" | "completed" | "cancelled";
  schedule: import("./sale").InstallmentScheduleRow[];
}

/** GET /customers/{id} — distinct from the list shape: no next_due/is_overdue,
 * adds sales[] with embedded installment schedules. */
export interface CustomerProfile {
  id: number;
  public_id: string;
  full_name: string;
  phone: string;
  alt_phone: string | null;
  national_id: string | null;
  address: string | null;
  notes: string | null;
  risk_class: RiskClass;
  status: CustomerStatus;
  created_at: string;
  receivable_balance: number;
  sales: CustomerProfileSale[];
}
export interface CustomerUpdateInput {
  full_name?: string;
  phone?: string;
  alt_phone?: string | null;
  national_id?: string | null;
  address?: string | null;
  notes?: string | null;
  risk_class?: RiskClass;
  status?: CustomerStatus;
}
