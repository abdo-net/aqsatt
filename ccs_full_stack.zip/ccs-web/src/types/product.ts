export type ProductStatus = "active" | "draft";

export interface Category {
  id: number;
  name: string;
  name_ar: string | null;
  product_count: number;
}

export interface ProductImage {
  id: number;
  path: string;
  thumb_path: string;
  variant_id: number | null;
  sort_order: number;
}

export interface ProductVariant {
  id: number;
  sku: string;
  price_cash: number;
  price_installment: number | null;
  compare_price: number | null;
  cost_price: number | null;
  stock_quantity: number;
  attributes: Record<string, string>;
  is_default: boolean;
  discount_pct: number | null;
}

/** Shape returned by list endpoints (_card_out) — no variants[]/images[] array. */
export interface ProductCard {
  id: number;
  public_id: string;
  sku: string;
  name: string;
  name_ar: string | null;
  category_id: number | null;
  base_price: number | null;
  stock_quantity: number;
  is_active: boolean;
  status: ProductStatus;
  brand: string | null;
  tags: string | null;
  variant_count: number;
  primary_image: ProductImage | null;
  price_cash: number;
  price_installment: number;
  compare_price: number | null;
  discount_pct: number | null;
}

/** Shape returned by GET /products/{id} (_detail_out) — adds variants/images/category. */
export interface ProductDetail extends ProductCard {
  description: string | null;
  variants: ProductVariant[];
  images: ProductImage[];
  category: { id: number; name: string; name_ar: string | null } | null;
}

export interface VariantInput {
  sku?: string;
  price_cash: number;
  price_installment?: number;
  compare_price?: number;
  cost_price?: number;
  stock_quantity?: number;
  attributes?: Record<string, string>;
  is_default?: boolean;
}

export interface ProductCreateInput {
  sku: string;
  name: string;
  name_ar?: string;
  category_id?: number | null;
  base_price?: number;
  stock_quantity?: number;
  description?: string;
  brand?: string;
  tags?: string;
  status?: ProductStatus;
  variants?: VariantInput[];
}

export interface ProductUpdateInput {
  name?: string;
  name_ar?: string;
  category_id?: number | null;
  base_price?: number;
  stock_quantity?: number;
  description?: string;
  brand?: string;
  tags?: string;
  status?: ProductStatus;
  is_active?: boolean;
}

export interface VariantUpdateInput {
  sku?: string;
  price_cash?: number;
  price_installment?: number;
  compare_price?: number;
  cost_price?: number;
  stock_quantity?: number;
  attributes?: Record<string, string>;
}
