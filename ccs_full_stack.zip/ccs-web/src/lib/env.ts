/**
 * The FastAPI backend base URL. Read server-side only (Route Handlers,
 * middleware) — never exposed to the browser. The browser talks exclusively
 * to Next.js's own /api/* routes, which proxy to this URL and attach the
 * Authorization header from the httpOnly cookie.
 */
export const API_BASE_URL = process.env.API_BASE_URL ?? "http://127.0.0.1:8000";

/**
 * Public, browser-visible base URL for static assets only (product/category
 * images served by FastAPI's StaticFiles mount at /static/uploads/...).
 * These files require no authentication to view — they are plain public
 * image files — so unlike every other backend interaction, the browser is
 * allowed to fetch them directly without going through the Next.js proxy.
 * Defaults to API_BASE_URL's value for local dev where both run on
 * localhost; set explicitly in production if the public-facing API domain
 * differs from the value Next.js's server process uses internally (e.g.
 * behind a reverse proxy where Next.js talks to FastAPI over a private
 * Docker network address that isn't reachable from the public internet).
 */
export const PUBLIC_ASSET_BASE_URL =
  process.env.NEXT_PUBLIC_ASSET_BASE_URL ?? API_BASE_URL;

export const AUTH_COOKIE_NAME = "ccs_token";
