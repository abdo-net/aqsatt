/** Always Latin digits, always integer — never ar-IQ, never a fraction. */
export function formatMoney(value: number | null | undefined): string {
  const n = Math.floor(Number(value) || 0);
  return `${n.toLocaleString("en-US")} IQD`;
}

export function formatNumber(value: number | null | undefined): string {
  const n = Math.floor(Number(value) || 0);
  return n.toLocaleString("en-US");
}

export function formatDate(value: string | null | undefined): string {
  if (!value) return "—";
  return new Date(value).toLocaleDateString("en-GB", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}
