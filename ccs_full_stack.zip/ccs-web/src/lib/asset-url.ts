import { PUBLIC_ASSET_BASE_URL } from "@/lib/env";

/** Resolves a backend-relative path like "/static/uploads/1/78/x.jpg" into
 * an absolute URL the browser can fetch directly. Already-absolute URLs
 * (http://, https://) pass through unchanged. */
export function assetUrl(path: string | null | undefined): string {
  if (!path) return "";
  if (path.startsWith("http://") || path.startsWith("https://")) return path;
  return `${PUBLIC_ASSET_BASE_URL}${path}`;
}
