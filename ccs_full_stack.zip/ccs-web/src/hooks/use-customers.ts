"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { apiFetch } from "@/lib/api-client";
import type {
  Customer,
  CustomerCreateInput,
  CustomerProfile,
  CustomerUpdateInput,
  PaginatedResponse,
} from "@/types/customer";

interface UseCustomersParams {
  page: number;
  pageSize: number;
  search?: string;
}

export function useCustomers({ page, pageSize, search }: UseCustomersParams) {
  const params = new URLSearchParams({
    page: String(page),
    page_size: String(pageSize),
  });
  if (search) params.set("name", search);

  return useQuery({
    queryKey: ["customers", { page, pageSize, search }],
    queryFn: () =>
      apiFetch<PaginatedResponse<Customer>>(`customers?${params.toString()}`),
    placeholderData: (prev) => prev, // keep showing old page while fetching the next (no flash to skeleton on page change)
  });
}

export function useCustomer(id: number | null) {
  return useQuery({
    queryKey: ["customers", id],
    queryFn: () => apiFetch<CustomerProfile>(`customers/${id}`),
    enabled: id !== null,
  });
}

export function useCreateCustomer() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: CustomerCreateInput) =>
      apiFetch<Customer>("customers", {
        method: "POST",
        body: JSON.stringify(body),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["customers"] });
    },
  });
}

export function useUpdateCustomer() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, body }: { id: number; body: CustomerUpdateInput }) =>
      apiFetch<Customer>(`customers/${id}`, {
        method: "PATCH",
        body: JSON.stringify(body),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["customers"] });
    },
  });
}
