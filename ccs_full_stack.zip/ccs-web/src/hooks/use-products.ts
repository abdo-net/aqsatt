"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { apiFetch } from "@/lib/api-client";
import type { PaginatedResponse } from "@/types/customer";
import type {
  Category,
  ProductCard,
  ProductCreateInput,
  ProductDetail,
  ProductUpdateInput,
  VariantInput,
  VariantUpdateInput,
} from "@/types/product";

interface UseProductsParams {
  page: number;
  pageSize: number;
  search?: string;
  categoryId?: number;
  status?: string;
}

export function useProducts({ page, pageSize, search, categoryId, status }: UseProductsParams) {
  const params = new URLSearchParams({ page: String(page), page_size: String(pageSize) });
  if (search) params.set("q", search);
  if (categoryId) params.set("category_id", String(categoryId));
  if (status) params.set("status", status);

  return useQuery({
    queryKey: ["products", { page, pageSize, search, categoryId, status }],
    queryFn: () => apiFetch<PaginatedResponse<ProductCard>>(`products?${params.toString()}`),
    placeholderData: (prev) => prev,
  });
}

export function useProduct(id: number | null) {
  return useQuery({
    queryKey: ["products", id],
    queryFn: () => apiFetch<ProductDetail>(`products/${id}`),
    enabled: id !== null,
  });
}

export function useCategories() {
  return useQuery({
    queryKey: ["categories"],
    queryFn: () => apiFetch<Category[]>("categories"),
    staleTime: 60_000,
  });
}

export function useCreateCategory() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: { name: string; name_ar?: string }) =>
      apiFetch<Category>("categories", { method: "POST", body: JSON.stringify(body) }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["categories"] }),
  });
}

export function useCreateProduct() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: ProductCreateInput) =>
      apiFetch<ProductDetail>("products", { method: "POST", body: JSON.stringify(body) }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["products"] }),
  });
}

export function useUpdateProduct() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, body }: { id: number; body: ProductUpdateInput }) =>
      apiFetch<ProductDetail>(`products/${id}`, { method: "PATCH", body: JSON.stringify(body) }),
    onSuccess: (_data, vars) => {
      queryClient.invalidateQueries({ queryKey: ["products"] });
      queryClient.invalidateQueries({ queryKey: ["products", vars.id] });
    },
  });
}

export function useDeleteProduct() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => apiFetch<{ id: number }>(`products/${id}`, { method: "DELETE" }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["products"] }),
  });
}

export function useAddVariant() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ productId, body }: { productId: number; body: VariantInput }) =>
      apiFetch<ProductDetail>(`products/${productId}/variants`, {
        method: "POST",
        body: JSON.stringify(body),
      }),
    onSuccess: (_data, vars) => {
      queryClient.invalidateQueries({ queryKey: ["products"] });
      queryClient.invalidateQueries({ queryKey: ["products", vars.productId] });
    },
  });
}

export function useUpdateVariant() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({
      productId,
      variantId,
      body,
    }: {
      productId: number;
      variantId: number;
      body: VariantUpdateInput;
    }) =>
      apiFetch<ProductDetail>(`products/${productId}/variants/${variantId}`, {
        method: "PATCH",
        body: JSON.stringify(body),
      }),
    onSuccess: (_data, vars) => {
      queryClient.invalidateQueries({ queryKey: ["products"] });
      queryClient.invalidateQueries({ queryKey: ["products", vars.productId] });
    },
  });
}

export function useUploadProductImages() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ productId, files }: { productId: number; files: File[] }) => {
      const formData = new FormData();
      files.forEach((f) => formData.append("files", f));
      return apiFetch<unknown>(`products/${productId}/images`, {
        method: "POST",
        body: formData,
      });
    },
    onSuccess: (_data, vars) => {
      queryClient.invalidateQueries({ queryKey: ["products"] });
      queryClient.invalidateQueries({ queryKey: ["products", vars.productId] });
    },
  });
}

export function useDeleteProductImage() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ productId, imageId }: { productId: number; imageId: number }) =>
      apiFetch<{ id: number }>(`products/${productId}/images/${imageId}`, { method: "DELETE" }),
    onSuccess: (_data, vars) => {
      queryClient.invalidateQueries({ queryKey: ["products"] });
      queryClient.invalidateQueries({ queryKey: ["products", vars.productId] });
    },
  });
}
