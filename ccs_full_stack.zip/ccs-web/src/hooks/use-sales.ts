"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { apiFetch } from "@/lib/api-client";
import type { PaginatedResponse } from "@/types/customer";
import type { Sale, SaleCreateInput } from "@/types/sale";

interface UseSalesParams {
  page: number;
  pageSize: number;
  customerId?: number;
  status?: string;
}

export function useSales({ page, pageSize, customerId, status }: UseSalesParams) {
  const params = new URLSearchParams({ page: String(page), page_size: String(pageSize) });
  if (customerId) params.set("customer_id", String(customerId));
  if (status) params.set("status", status);

  return useQuery({
    queryKey: ["sales", { page, pageSize, customerId, status }],
    queryFn: () => apiFetch<PaginatedResponse<Sale>>(`sales?${params.toString()}`),
    placeholderData: (prev) => prev,
  });
}

export function useSale(id: number | null) {
  return useQuery({
    queryKey: ["sales", id],
    queryFn: () => apiFetch<Sale>(`sales/${id}`),
    enabled: id !== null,
  });
}

/** Generates a fresh idempotency key per call — crypto.randomUUID() is
 * available in all modern browsers and avoids pulling in a uuid package
 * for a single call site. */
function newIdempotencyKey(): string {
  return crypto.randomUUID();
}

export function useCreateSale() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: Omit<SaleCreateInput, "idempotency_key">) =>
      apiFetch<Sale>("sales", {
        method: "POST",
        body: JSON.stringify({ ...body, idempotency_key: newIdempotencyKey() }),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["sales"] });
      queryClient.invalidateQueries({ queryKey: ["products"] }); // stock changed
      queryClient.invalidateQueries({ queryKey: ["customers"] }); // balance changed
      queryClient.invalidateQueries({ queryKey: ["dashboard"] });
    },
  });
}
