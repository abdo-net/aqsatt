"use client";

import { useQuery } from "@tanstack/react-query";

import { apiFetch } from "@/lib/api-client";
import type { LedgerAccount, LedgerTransactionGroup } from "@/types/ledger";

export function useLedgerEntries(customerId?: number, limit = 120) {
  const params = new URLSearchParams({ limit: String(limit) });
  if (customerId) params.set("customer_id", String(customerId));

  return useQuery({
    queryKey: ["ledger", "entries", { customerId, limit }],
    queryFn: () => apiFetch<LedgerTransactionGroup[]>(`ledger?${params.toString()}`),
  });
}

export function useLedgerAccounts() {
  return useQuery({
    queryKey: ["ledger", "accounts"],
    queryFn: () => apiFetch<LedgerAccount[]>("ledger/accounts"),
  });
}
