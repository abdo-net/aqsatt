"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { apiFetch } from "@/lib/api-client";
import type { Payment, PaymentCreateInput, PaymentCreateResult } from "@/types/ledger";

interface UsePaymentsParams {
  saleId?: number;
  customerId?: number;
  limit?: number;
}

export function usePayments({ saleId, customerId, limit = 100 }: UsePaymentsParams) {
  const params = new URLSearchParams({ limit: String(limit) });
  if (saleId) params.set("sale_id", String(saleId));
  if (customerId) params.set("customer_id", String(customerId));

  return useQuery({
    queryKey: ["payments", { saleId, customerId, limit }],
    queryFn: () => apiFetch<Payment[]>(`payments?${params.toString()}`),
  });
}

function newIdempotencyKey(): string {
  return crypto.randomUUID();
}

export function useCreatePayment() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: Omit<PaymentCreateInput, "idempotency_key">) =>
      apiFetch<PaymentCreateResult>("payments", {
        method: "POST",
        body: JSON.stringify({ ...body, idempotency_key: newIdempotencyKey() }),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["payments"] });
      queryClient.invalidateQueries({ queryKey: ["sales"] });
      queryClient.invalidateQueries({ queryKey: ["customers"] });
      queryClient.invalidateQueries({ queryKey: ["ledger"] });
      queryClient.invalidateQueries({ queryKey: ["dashboard"] });
    },
  });
}
