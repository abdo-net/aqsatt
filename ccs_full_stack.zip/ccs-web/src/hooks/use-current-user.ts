"use client";

import { useQuery } from "@tanstack/react-query";

import { apiFetch } from "@/lib/api-client";

export interface CurrentUser {
  id: number;
  name: string;
  username: string;
  tenant_id: number;
  permissions: string[];
}

export function useCurrentUser() {
  return useQuery({
    queryKey: ["me"],
    queryFn: () => apiFetch<CurrentUser>("me"),
    staleTime: 5 * 60_000,
    retry: false,
  });
}
