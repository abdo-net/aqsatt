import { NextRequest, NextResponse } from "next/server";

import { AUTH_COOKIE_NAME } from "@/lib/env";

const PUBLIC_PATHS = ["/login"];

export function proxy(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // Never redirect API routes — a redirect on a fetch() call is followed
  // transparently by the client, silently turning an expected 401 JSON
  // response into a 200 with login-page HTML. Each /api/* Route Handler
  // owns its own auth check and returns a proper JSON error.
  if (pathname.startsWith("/api/")) {
    return NextResponse.next();
  }

  if (
    PUBLIC_PATHS.some((p) => pathname === p || pathname.startsWith(p + "/"))
  ) {
    return NextResponse.next();
  }

  const token = req.cookies.get(AUTH_COOKIE_NAME)?.value;
  if (!token) {
    const loginUrl = new URL("/login", req.url);
    loginUrl.searchParams.set("next", pathname);
    return NextResponse.redirect(loginUrl);
  }

  return NextResponse.next();
}

export const config = {
  // Run on every path except static assets, images, and the login API route.
  matcher: ["/((?!_next/static|_next/image|favicon.ico|api/auth/login).*)"],
};
