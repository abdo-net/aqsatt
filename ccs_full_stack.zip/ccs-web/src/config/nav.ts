import type { LucideIcon } from "lucide-react";
import {
  LayoutDashboard,
  Users,
  Package,
  ShoppingCart,
  Receipt,
  Wallet,
  Bell,
  UserCog,
  Settings,
} from "lucide-react";

export interface NavItem {
  key: string;
  label: { ar: string; en: string };
  href: string;
  icon: LucideIcon;
  /** Permission string required to see this item, or null if always visible. */
  permission: string | null;
}

export const NAV_ITEMS: NavItem[] = [
  { key: "dashboard", label: { ar: "لوحة التحكم", en: "Dashboard" }, href: "/dashboard", icon: LayoutDashboard, permission: "reports.read" },
  { key: "customers", label: { ar: "الزبائن", en: "Customers" }, href: "/customers", icon: Users, permission: "customers.read" },
  { key: "products", label: { ar: "المنتجات", en: "Products" }, href: "/products", icon: Package, permission: "products.read" },
  { key: "sales", label: { ar: "المبيعات", en: "Sales" }, href: "/sales", icon: ShoppingCart, permission: "sales.read" },
  { key: "sale-history", label: { ar: "سجل المبيعات", en: "Sale History" }, href: "/sales/history", icon: Receipt, permission: "sales.read" },
  { key: "payments", label: { ar: "المدفوعات", en: "Payments" }, href: "/payments", icon: Wallet, permission: "payments.create" },
  { key: "ledger", label: { ar: "دفتر الأستاذ", en: "Ledger" }, href: "/ledger", icon: Wallet, permission: "ledger.read" },
  { key: "notifications", label: { ar: "التنبيهات", en: "Notifications" }, href: "/notifications", icon: Bell, permission: "reports.read" },
  { key: "users", label: { ar: "المستخدمون", en: "Users" }, href: "/users", icon: UserCog, permission: "users.manage" },
  { key: "settings", label: { ar: "الإعدادات", en: "Settings" }, href: "/settings", icon: Settings, permission: null },
];
