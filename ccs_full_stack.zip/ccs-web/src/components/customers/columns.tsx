"use client";

import type { ColumnDef } from "@tanstack/react-table";
import Link from "next/link";

import type { Customer } from "@/types/customer";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatDate, formatMoney } from "@/lib/format";
import { Pencil } from "lucide-react";

const RISK_LABEL: Record<Customer["risk_class"], { ar: string; en: string }> = {
  qi: { ar: "ممتاز (QI)", en: "Excellent (QI)" },
  trusted: { ar: "موثوق", en: "Trusted" },
  mixed: { ar: "مختلط", en: "Mixed" },
};

export function buildCustomerColumns(
  locale: "ar" | "en",
  onEdit: (customer: Customer) => void
): ColumnDef<Customer>[] {
  return [
    {
      accessorKey: "full_name",
      header: locale === "ar" ? "الزبون" : "Customer",
      cell: ({ row }) => {
        const c = row.original;
        return (
          <Link
            href={`/customers/${c.id}`}
            className="group flex items-center gap-3"
          >
            <div className="bg-accent text-accent-foreground flex size-9 shrink-0 items-center justify-center rounded-full text-sm font-bold">
              {(c.full_name || "?")[0]}
            </div>
            <div className="min-w-0">
              <div className="group-hover:text-primary truncate text-sm font-semibold transition-colors">
                {c.full_name}
              </div>
              <div className="text-muted-foreground truncate text-xs">
                {RISK_LABEL[c.risk_class]?.[locale] ?? c.risk_class}
              </div>
            </div>
          </Link>
        );
      },
    },
    {
      accessorKey: "phone",
      header: locale === "ar" ? "الهاتف" : "Phone",
      cell: ({ row }) => (
        <span className="font-mono text-sm tabular-nums">
          {row.original.phone}
        </span>
      ),
    },
    {
      accessorKey: "receivable_balance",
      header: locale === "ar" ? "الرصيد المستحق" : "Balance",
      cell: ({ row }) => {
        const balance = row.original.receivable_balance;
        return (
          <span
            className={
              balance > 0
                ? "text-destructive font-semibold tabular-nums"
                : "text-success font-semibold tabular-nums"
            }
          >
            {balance > 0 ? formatMoney(balance) : "—"}
          </span>
        );
      },
    },
    {
      accessorKey: "next_due",
      header: locale === "ar" ? "القسط القادم" : "Next due",
      cell: ({ row }) => {
        const c = row.original;
        if (!c.next_due) {
          return <span className="text-muted-foreground text-xs">—</span>;
        }
        const daysUntil = Math.round(
          (new Date(c.next_due).getTime() - Date.now()) / 86_400_000
        );
        return (
          <div className="flex items-center gap-2">
            <span className="text-sm tabular-nums">{formatDate(c.next_due)}</span>
            {c.is_overdue ? (
              <Badge variant="destructive">
                {locale === "ar" ? "متأخر" : "Overdue"}
              </Badge>
            ) : daysUntil <= 3 ? (
              <Badge variant="warning">
                {daysUntil <= 0
                  ? locale === "ar" ? "اليوم" : "Today"
                  : `${daysUntil}d`}
              </Badge>
            ) : null}
          </div>
        );
      },
    },
    {
      id: "actions",
      header: "",
      cell: ({ row }) => (
        <div className="flex justify-end">
          <Button
            variant="ghost"
            size="icon"
            className="size-8"
            onClick={(e) => {
              e.stopPropagation();
              onEdit(row.original);
            }}
            aria-label={locale === "ar" ? "تعديل" : "Edit"}
          >
            <Pencil className="size-4" />
          </Button>
        </div>
      ),
    },
  ];
}
