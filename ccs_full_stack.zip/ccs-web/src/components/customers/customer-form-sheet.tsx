"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetFooter,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useCreateCustomer, useUpdateCustomer } from "@/hooks/use-customers";
import type { Customer } from "@/types/customer";
import { ApiError } from "@/lib/api-client";

const customerSchema = z.object({
  full_name: z.string().min(1, "الاسم مطلوب"),
  phone: z.string().min(1, "الهاتف مطلوب"),
  national_id: z.string().optional(),
  address: z.string().optional(),
  risk_class: z.enum(["trusted", "qi", "mixed"]),
  status: z.enum(["active", "blocked"]).optional(),
  notes: z.string().optional(),
});

type CustomerFormValues = z.infer<typeof customerSchema>;

interface CustomerFormSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  customer: Customer | null; // null = create mode
  locale: "ar" | "en";
}

export function CustomerFormSheet({
  open,
  onOpenChange,
  customer,
  locale,
}: CustomerFormSheetProps) {
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="flex flex-col gap-0 sm:max-w-md">
        {/* Keyed remount instead of useEffect+reset: switching the edit
            target (or going from create -> edit) fully reinitializes this
            subtree's state from the current `customer` prop on its first
            render, with no extra render pass and no risk of the form
            briefly showing stale data from the previous target. */}
        <CustomerFormInner
          key={customer?.id ?? "new"}
          customer={customer}
          locale={locale}
          onDone={() => onOpenChange(false)}
        />
      </SheetContent>
    </Sheet>
  );
}

interface CustomerFormInnerProps {
  customer: Customer | null;
  locale: "ar" | "en";
  onDone: () => void;
}

function CustomerFormInner({ customer, locale, onDone }: CustomerFormInnerProps) {
  const isEditing = !!customer;
  const createMutation = useCreateCustomer();
  const updateMutation = useUpdateCustomer();
  const mutation = isEditing ? updateMutation : createMutation;

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<CustomerFormValues>({
    resolver: zodResolver(customerSchema),
    defaultValues: customer
      ? {
          full_name: customer.full_name,
          phone: customer.phone,
          national_id: customer.national_id ?? "",
          address: customer.address ?? "",
          risk_class: customer.risk_class,
          status: customer.status,
          notes: customer.notes ?? "",
        }
      : { risk_class: "trusted", status: "active" },
  });

  async function onSubmit(values: CustomerFormValues) {
    try {
      if (isEditing && customer) {
        await updateMutation.mutateAsync({ id: customer.id, body: values });
      } else {
        await createMutation.mutateAsync(values);
      }
      onDone();
    } catch {
      // error surfaced below via mutation.error
    }
  }

  const t = (ar: string, en: string) => (locale === "ar" ? ar : en);

  return (
    <>
      <SheetHeader>
        <SheetTitle>
          {isEditing ? t("تعديل الزبون", "Edit customer") : t("زبون جديد", "New customer")}
        </SheetTitle>
      </SheetHeader>

      <form
        onSubmit={handleSubmit(onSubmit)}
        className="flex flex-1 flex-col overflow-y-auto"
        noValidate
      >
        <div className="flex-1 space-y-4 px-4 py-2">
          <div className="space-y-1.5">
            <Label htmlFor="full_name">{t("الاسم الكامل", "Full name")} *</Label>
            <Input id="full_name" {...register("full_name")} aria-invalid={!!errors.full_name} />
            {errors.full_name && (
              <p className="text-destructive text-xs">{errors.full_name.message}</p>
            )}
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="phone">{t("الهاتف", "Phone")} *</Label>
            <Input id="phone" type="tel" {...register("phone")} aria-invalid={!!errors.phone} />
            {errors.phone && <p className="text-destructive text-xs">{errors.phone.message}</p>}
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="national_id">{t("رقم الهوية", "National ID")}</Label>
            <Input id="national_id" {...register("national_id")} />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="address">{t("العنوان", "Address")}</Label>
            <Input id="address" {...register("address")} />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="risk_class">{t("التصنيف", "Risk class")}</Label>
              <select
                id="risk_class"
                {...register("risk_class")}
                className="border-input bg-card h-9 w-full rounded-md border px-3 text-sm shadow-xs outline-none"
              >
                <option value="trusted">{t("موثوق", "Trusted")}</option>
                <option value="qi">{t("ممتاز (QI)", "Excellent (QI)")}</option>
                <option value="mixed">{t("مختلط", "Mixed")}</option>
              </select>
            </div>

            {isEditing && (
              <div className="space-y-1.5">
                <Label htmlFor="status">{t("الحالة", "Status")}</Label>
                <select
                  id="status"
                  {...register("status")}
                  className="border-input bg-card h-9 w-full rounded-md border px-3 text-sm shadow-xs outline-none"
                >
                  <option value="active">{t("نشط", "Active")}</option>
                  <option value="blocked">{t("محظور", "Blocked")}</option>
                </select>
              </div>
            )}
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="notes">{t("ملاحظات", "Notes")}</Label>
            <textarea
              id="notes"
              {...register("notes")}
              rows={3}
              className="border-input bg-card w-full resize-none rounded-md border px-3 py-2 text-sm shadow-xs outline-none"
            />
          </div>

          {mutation.isError && (
            <p className="text-destructive text-sm">
              {mutation.error instanceof ApiError
                ? mutation.error.message
                : t("حدث خطأ", "Something went wrong")}
            </p>
          )}
        </div>

        <SheetFooter className="flex-row justify-end gap-2 border-t">
          <Button type="button" variant="outline" onClick={onDone}>
            {t("إلغاء", "Cancel")}
          </Button>
          <Button type="submit" disabled={mutation.isPending}>
            {mutation.isPending
              ? t("جارٍ الحفظ…", "Saving…")
              : isEditing
                ? t("حفظ التغييرات", "Save changes")
                : t("حفظ", "Save")}
          </Button>
        </SheetFooter>
      </form>
    </>
  );
}
