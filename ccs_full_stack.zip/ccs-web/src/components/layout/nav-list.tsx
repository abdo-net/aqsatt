"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

import { NAV_ITEMS } from "@/config/nav";
import { cn } from "@/lib/utils";

interface NavListProps {
  permissions: string[];
  locale: "ar" | "en";
  onNavigate?: () => void;
}

export function NavList({ permissions, locale, onNavigate }: NavListProps) {
  const pathname = usePathname();
  const permSet = new Set(permissions);
  const visible = NAV_ITEMS.filter(
    (item) => item.permission === null || permSet.has(item.permission)
  );

  return (
    <nav className="flex flex-col gap-0.5 p-2">
      {visible.map((item) => {
        const active =
          pathname === item.href || pathname.startsWith(item.href + "/");
        const Icon = item.icon;
        return (
          <Link
            key={item.key}
            href={item.href}
            onClick={onNavigate}
            className={cn(
              "group relative flex h-9 items-center gap-2.5 rounded-md px-3 text-[13.5px] font-medium transition-colors",
              active
                ? "bg-sidebar-accent text-sidebar-accent-foreground"
                : "text-sidebar-foreground hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground"
            )}
          >
            {/* Active accent bar — logical "start" position so it sits on
                the correct edge in both RTL and LTR without a separate rule.
                Verified: Tailwind v4's `start-0` compiles to
                `inset-inline-start: 0`, not the invented `inset-inline-start-0`. */}
            <span
              className={cn(
                "absolute inset-y-1.5 start-0 w-0.5 rounded-full bg-sidebar-primary transition-opacity",
                active ? "opacity-100" : "opacity-0"
              )}
            />
            <Icon className="size-[17px] shrink-0 opacity-80" />
            <span className="truncate">{item.label[locale]}</span>
          </Link>
        );
      })}
    </nav>
  );
}
