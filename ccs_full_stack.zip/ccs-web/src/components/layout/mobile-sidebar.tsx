"use client";

import { useState } from "react";
import { LogOut, Menu, Moon, Sun } from "lucide-react";

import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { NavList } from "@/components/layout/nav-list";
import { useTheme } from "@/components/providers/theme-provider";
import { useLocale } from "@/components/providers/locale-provider";

interface MobileSidebarProps {
  permissions: string[];
  onLogout: () => void;
}

export function MobileSidebar({ permissions, onLogout }: MobileSidebarProps) {
  const [open, setOpen] = useState(false);
  const { theme, toggleTheme } = useTheme();
  const { locale } = useLocale();
  const isDark = theme === "dark";

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="lg:hidden" aria-label="Menu">
          <Menu className="size-5" />
        </Button>
      </SheetTrigger>
      <SheetContent
        side="left"
        className="bg-sidebar border-sidebar-border w-72 gap-0 p-0 [&_[data-slot=sheet-close]]:text-white"
      >
        <SheetHeader className="border-sidebar-border border-b p-4">
          <SheetTitle className="flex items-center gap-2.5 text-white">
            <div className="bg-sidebar-primary flex size-7 shrink-0 items-center justify-center rounded-md text-sm font-extrabold text-white">
              C
            </div>
            CCS
          </SheetTitle>
        </SheetHeader>

        <div className="flex-1 overflow-y-auto">
          <NavList
            permissions={permissions}
            locale={locale}
            onNavigate={() => setOpen(false)}
          />
        </div>

        <div className="border-sidebar-border space-y-0.5 border-t p-2">
          <button
            onClick={toggleTheme}
            className="text-sidebar-foreground hover:bg-sidebar-accent/60 flex h-10 w-full items-center gap-2.5 rounded-md px-3 text-sm font-medium transition-colors"
          >
            {isDark ? <Sun className="size-[18px]" /> : <Moon className="size-[18px]" />}
            <span>
              {isDark
                ? locale === "ar" ? "الوضع الفاتح" : "Light mode"
                : locale === "ar" ? "الوضع الداكن" : "Dark mode"}
            </span>
          </button>
          <button
            onClick={onLogout}
            className="text-sidebar-foreground hover:bg-sidebar-accent/60 flex h-10 w-full items-center gap-2.5 rounded-md px-3 text-sm font-medium transition-colors"
          >
            <LogOut className="size-[18px]" />
            <span>{locale === "ar" ? "خروج" : "Logout"}</span>
          </button>
        </div>
      </SheetContent>
    </Sheet>
  );
}
