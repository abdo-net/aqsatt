"use client";

import Link from "next/link";
import { Globe, LogOut, Settings } from "lucide-react";

import { MobileSidebar } from "@/components/layout/mobile-sidebar";
import { useLocale } from "@/components/providers/locale-provider";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface TopbarProps {
  title: string;
  permissions: string[];
  username: string;
  tenantId: number | string;
  onLogout: () => void;
}

export function Topbar({
  title,
  permissions,
  username,
  tenantId,
  onLogout,
}: TopbarProps) {
  const { locale, toggleLocale } = useLocale();

  return (
    <header className="bg-background/90 sticky top-0 z-20 flex h-15 shrink-0 items-center justify-between gap-3 border-b px-4 backdrop-blur-sm lg:px-6">
      <div className="flex items-center gap-2">
        <MobileSidebar permissions={permissions} onLogout={onLogout} />
        <h1 className="text-base font-bold tracking-tight lg:text-[17px]">
          {title}
        </h1>
      </div>

      <div className="flex items-center gap-1">
        <button
          onClick={toggleLocale}
          className="hover:bg-muted text-muted-foreground flex h-9 items-center gap-1.5 rounded-md px-2.5 text-sm transition-colors"
        >
          <Globe className="size-4" />
          <span className="hidden sm:inline">{locale === "ar" ? "EN" : "عربي"}</span>
        </button>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="hover:bg-muted flex items-center gap-2 rounded-md p-1 ps-1.5 transition-colors">
              <div className="bg-accent text-accent-foreground flex size-8 shrink-0 items-center justify-center rounded-full text-sm font-bold">
                {(username || "?")[0]?.toUpperCase()}
              </div>
              <div className="hidden text-start leading-tight md:block">
                <div className="text-[13px] font-semibold">{username || "—"}</div>
                <div className="text-muted-foreground text-[11px]">
                  {locale === "ar" ? "المستأجر" : "Tenant"} #{tenantId}
                </div>
              </div>
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent>
            <DropdownMenuLabel>{username}</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem asChild>
              <Link href="/settings">
                <Settings />
                {locale === "ar" ? "الإعدادات" : "Settings"}
              </Link>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem variant="destructive" onClick={onLogout}>
              <LogOut />
              {locale === "ar" ? "خروج" : "Logout"}
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
