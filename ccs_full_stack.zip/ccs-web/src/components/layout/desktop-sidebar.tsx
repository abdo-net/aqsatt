"use client";

import { LogOut, Moon, Sun } from "lucide-react";

import { NavList } from "@/components/layout/nav-list";
import { useTheme } from "@/components/providers/theme-provider";
import { useLocale } from "@/components/providers/locale-provider";

interface DesktopSidebarProps {
  permissions: string[];
  onLogout: () => void;
}

export function DesktopSidebar({ permissions, onLogout }: DesktopSidebarProps) {
  const { theme, toggleTheme } = useTheme();
  const { locale } = useLocale();
  const isDark = theme === "dark";

  return (
    <aside className="bg-sidebar border-sidebar-border fixed inset-y-0 start-0 z-30 hidden w-64 flex-col border-e lg:flex">
      <div className="border-sidebar-border flex h-15 items-center gap-2.5 border-b px-4">
        <div className="bg-sidebar-primary flex size-7.5 shrink-0 items-center justify-center rounded-md text-sm font-extrabold text-white">
          C
        </div>
        <div className="min-w-0 leading-tight">
          <div className="truncate text-[13.5px] font-bold text-white">CCS</div>
          <div className="text-sidebar-foreground/60 truncate text-[10.5px]">
            {locale === "ar" ? "نظام التقسيط" : "Installments"}
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        <NavList permissions={permissions} locale={locale} />
      </div>

      <div className="border-sidebar-border space-y-0.5 border-t p-2">
        <button
          onClick={toggleTheme}
          className="text-sidebar-foreground hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground flex h-9 w-full items-center gap-2.5 rounded-md px-3 text-[13.5px] font-medium transition-colors"
        >
          {isDark ? (
            <Sun className="size-[17px] opacity-80" />
          ) : (
            <Moon className="size-[17px] opacity-80" />
          )}
          <span>
            {isDark
              ? locale === "ar"
                ? "الوضع الفاتح"
                : "Light mode"
              : locale === "ar"
                ? "الوضع الداكن"
                : "Dark mode"}
          </span>
        </button>
        <button
          onClick={onLogout}
          className="text-sidebar-foreground hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground flex h-9 w-full items-center gap-2.5 rounded-md px-3 text-[13.5px] font-medium transition-colors"
        >
          <LogOut className="size-[17px] opacity-80" />
          <span>{locale === "ar" ? "خروج" : "Logout"}</span>
        </button>
      </div>
    </aside>
  );
}
