"use client";

import { useEffect, useRef, useState } from "react";

import { useCustomers } from "@/hooks/use-customers";
import { formatMoney } from "@/lib/format";
import type { Customer } from "@/types/customer";

interface CustomerSearchProps {
  selected: Customer | null;
  onSelect: (customer: Customer) => void;
  locale: "ar" | "en";
}

export function CustomerSearch({ selected, onSelect, locale }: CustomerSearchProps) {
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const { data } = useCustomers({ page: 1, pageSize: 8, search: query });
  const results = data?.data ?? [];

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div ref={containerRef} className="relative">
      <input
        value={selected ? selected.full_name : query}
        onChange={(e) => {
          setQuery(e.target.value);
          setOpen(true);
        }}
        onFocus={() => setOpen(true)}
        placeholder={locale === "ar" ? "ابحث عن زبون…" : "Search customer…"}
        className="border-input bg-card h-9 w-full rounded-md border px-3 text-sm shadow-xs outline-none"
      />
      {open && query.length > 0 && results.length > 0 && (
        <div className="bg-popover absolute z-20 mt-1 w-full max-h-56 overflow-y-auto rounded-md border shadow-md">
          {results.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => {
                onSelect(c);
                setQuery("");
                setOpen(false);
              }}
              className="hover:bg-muted flex w-full items-center gap-2 px-3 py-2 text-start"
            >
              <div className="bg-accent text-accent-foreground flex size-7 shrink-0 items-center justify-center rounded-full text-xs font-bold">
                {(c.full_name || "?")[0]}
              </div>
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm font-medium">{c.full_name}</div>
                <div className="text-muted-foreground text-xs">{c.phone}</div>
              </div>
              {c.receivable_balance > 0 && (
                <span className="text-destructive shrink-0 text-xs font-semibold tabular-nums">
                  {formatMoney(c.receivable_balance)}
                </span>
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
