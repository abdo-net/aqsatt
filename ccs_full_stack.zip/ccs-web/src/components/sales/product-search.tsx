"use client";

import { useEffect, useRef, useState } from "react";
import { Package } from "lucide-react";

import { useProducts } from "@/hooks/use-products";
import { formatMoney } from "@/lib/format";
import { assetUrl } from "@/lib/asset-url";
import type { ProductCard } from "@/types/product";

interface ProductSearchProps {
  onSelect: (product: ProductCard) => void;
  locale: "ar" | "en";
}

export function ProductSearch({ onSelect, locale }: ProductSearchProps) {
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const { data } = useProducts({ page: 1, pageSize: 8, search: query });
  const results = data?.data ?? [];

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div ref={containerRef} className="relative">
      <input
        value={query}
        onChange={(e) => {
          setQuery(e.target.value);
          setOpen(true);
        }}
        onFocus={() => setOpen(true)}
        placeholder={locale === "ar" ? "ابحث عن منتج…" : "Search product…"}
        className="border-input bg-card h-9 w-full rounded-md border px-3 text-sm shadow-xs outline-none"
      />
      {open && query.length > 0 && results.length > 0 && (
        <div className="bg-popover absolute z-20 mt-1 w-full max-h-64 overflow-y-auto rounded-md border shadow-md">
          {results.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => {
                onSelect(p);
                setQuery("");
                setOpen(false);
              }}
              className="hover:bg-muted flex w-full items-center gap-2 px-3 py-2 text-start"
            >
              {p.primary_image ? (
                // Tiny 28px thumbnail inside a dropdown list — next/image's
                // optimization pipeline overhead isn't worth it here.
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={assetUrl(p.primary_image.thumb_path)}
                  alt=""
                  className="size-7 shrink-0 rounded object-cover"
                />
              ) : (
                <div className="bg-muted text-muted-foreground flex size-7 shrink-0 items-center justify-center rounded">
                  <Package className="size-3.5" />
                </div>
              )}
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm font-medium">
                  {locale === "ar" ? p.name_ar || p.name : p.name}
                </div>
                <div className="text-muted-foreground text-xs">
                  {formatMoney(p.price_cash)} ·{" "}
                  {locale === "ar" ? "مخزون" : "stock"} {p.stock_quantity}
                </div>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
