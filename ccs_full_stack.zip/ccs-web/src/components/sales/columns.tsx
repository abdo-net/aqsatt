"use client";

import type { ColumnDef } from "@tanstack/react-table";
import Link from "next/link";

import type { Sale } from "@/types/sale";
import { Badge } from "@/components/ui/badge";
import { formatDate, formatMoney } from "@/lib/format";

export function buildSaleColumns(locale: "ar" | "en"): ColumnDef<Sale>[] {
  return [
    {
      accessorKey: "sale_number",
      header: locale === "ar" ? "رقم الفاتورة" : "Invoice",
      cell: ({ row }) => (
        <Link
          href={`/customers/${row.original.customer_id}`}
          className="text-primary font-mono text-xs font-semibold hover:underline"
        >
          {row.original.sale_number}
        </Link>
      ),
    },
    {
      accessorKey: "sale_type",
      header: locale === "ar" ? "النوع" : "Type",
      cell: ({ row }) => (
        <Badge variant={row.original.sale_type === "cash" ? "secondary" : "info"}>
          {row.original.sale_type === "cash"
            ? locale === "ar" ? "نقدي" : "Cash"
            : locale === "ar" ? "تقسيط" : "Installment"}
        </Badge>
      ),
    },
    {
      accessorKey: "total_price",
      header: locale === "ar" ? "الإجمالي" : "Total",
      cell: ({ row }) => (
        <span className="font-semibold tabular-nums">
          {formatMoney(row.original.total_price)}
        </span>
      ),
    },
    {
      id: "remaining",
      header: locale === "ar" ? "المتبقي" : "Remaining",
      cell: ({ row }) => {
        const schedule = row.original.plan?.schedule ?? [];
        const remaining = schedule.reduce((sum, r) => sum + r.remaining, 0);
        return remaining > 0 ? (
          <span className="text-destructive font-medium tabular-nums">
            {formatMoney(remaining)}
          </span>
        ) : (
          <span className="text-success">✓</span>
        );
      },
    },
    {
      accessorKey: "status",
      header: locale === "ar" ? "الحالة" : "Status",
      cell: ({ row }) => {
        const status = row.original.status;
        return (
          <Badge
            variant={
              status === "completed"
                ? "success"
                : status === "cancelled"
                  ? "destructive"
                  : "info"
            }
          >
            {status}
          </Badge>
        );
      },
    },
    {
      accessorKey: "created_at",
      header: locale === "ar" ? "التاريخ" : "Date",
      cell: ({ row }) => (
        <span className="text-muted-foreground text-xs">
          {formatDate(row.original.created_at)}
        </span>
      ),
    },
  ];
}
