"use client";

import { createContext, useContext, useSyncExternalStore } from "react";

type Theme = "light" | "dark";

interface ThemeContextValue {
  theme: Theme;
  toggleTheme: () => void;
}

const ThemeContext = createContext<ThemeContextValue | null>(null);

function subscribe(callback: () => void) {
  const observer = new MutationObserver(callback);
  observer.observe(document.documentElement, { attributes: true, attributeFilter: ["class"] });
  return () => observer.disconnect();
}

function getSnapshot(): Theme {
  return document.documentElement.classList.contains("dark") ? "dark" : "light";
}

function getServerSnapshot(): Theme {
  // No DOM during SSR. The inline <head> script in layout.tsx already
  // applies the dark class before React hydrates, so by the time this
  // component's effect/subscription runs client-side, getSnapshot() will
  // read the correct value — useSyncExternalStore's hydration handling
  // takes care of reconciling "light" (server guess) -> actual (client)
  // without the manual flash/warning a useEffect+setState pair produces.
  return "light";
}

/**
 * Reads the .dark class already applied by the inline no-flash script in
 * layout.tsx <head>. useSyncExternalStore (not useState+useEffect) is used
 * specifically because it has first-class support for the SSR/client
 * snapshot mismatch this pattern inherently has — React's concurrent
 * rendering handles the reconciliation correctly instead of producing the
 * hydration-mismatch warning a plain useState guess would.
 */
export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const theme = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);

  function toggleTheme() {
    const next: Theme = theme === "dark" ? "light" : "dark";
    document.documentElement.classList.toggle("dark", next === "dark");
    localStorage.setItem("ccs-theme", next);
  }

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error("useTheme must be used within ThemeProvider");
  return ctx;
}
