"use client";

import { createContext, useContext, useSyncExternalStore } from "react";

type Locale = "ar" | "en";

interface LocaleContextValue {
  locale: Locale;
  dir: "rtl" | "ltr";
  toggleLocale: () => void;
}

const LocaleContext = createContext<LocaleContextValue | null>(null);

const STORAGE_KEY = "ccs-locale";

function subscribe(callback: () => void) {
  const observer = new MutationObserver(callback);
  observer.observe(document.documentElement, { attributes: true, attributeFilter: ["lang"] });
  return () => observer.disconnect();
}

function getSnapshot(): Locale {
  return document.documentElement.lang === "en" ? "en" : "ar";
}

function getServerSnapshot(): Locale {
  // Matches the default lang="ar" set on <html> in layout.tsx before the
  // inline <head> script (if any) flips it to "en" for a returning user.
  return "ar";
}

/**
 * Same pattern as ThemeProvider: <html lang/dir> is set synchronously in
 * layout.tsx (server-rendered, defaults to ar/rtl), and the inline <head>
 * script flips it to en/ltr before hydration if the user previously chose
 * English. useSyncExternalStore reads document.documentElement.lang as the
 * single source of truth — every Radix primitive (Sheet slide direction,
 * Dropdown alignment, etc.) reacts to the dir attribute on <html>
 * automatically via :dir(), so this provider only needs to mirror lang,
 * not separately track dir as state.
 */
export function LocaleProvider({ children }: { children: React.ReactNode }) {
  const locale = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);

  function toggleLocale() {
    const next: Locale = locale === "ar" ? "en" : "ar";
    document.documentElement.lang = next;
    document.documentElement.dir = next === "ar" ? "rtl" : "ltr";
    localStorage.setItem(STORAGE_KEY, next);
  }

  const dir = locale === "ar" ? "rtl" : "ltr";

  return (
    <LocaleContext.Provider value={{ locale, dir, toggleLocale }}>
      {children}
    </LocaleContext.Provider>
  );
}

export function useLocale() {
  const ctx = useContext(LocaleContext);
  if (!ctx) throw new Error("useLocale must be used within LocaleProvider");
  return ctx;
}
