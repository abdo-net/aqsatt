"use client";

import Image from "next/image";
import Link from "next/link";
import { Package, Pencil } from "lucide-react";

import type { ProductCard as ProductCardType } from "@/types/product";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatMoney } from "@/lib/format";
import { assetUrl } from "@/lib/asset-url";

const DISPLAY_MONTHS = 12;

interface ProductCardProps {
  product: ProductCardType;
  locale: "ar" | "en";
  onEdit: (product: ProductCardType) => void;
}

export function ProductCard({ product, locale, onEdit }: ProductCardProps) {
  const name = locale === "ar" ? product.name_ar || product.name : product.name;
  const hasDiscount = !!(product.discount_pct && product.compare_price);
  const monthly = Math.floor(
    (product.price_installment || product.price_cash || 0) / DISPLAY_MONTHS
  );

  return (
    <div className="bg-card group overflow-hidden rounded-lg border">
      <Link href={`/products/${product.id}`} className="block">
        <div className="bg-muted relative aspect-square overflow-hidden">
          {product.primary_image ? (
            <Image
              src={assetUrl(product.primary_image.thumb_path)}
              alt={name}
              fill
              unoptimized
              className="object-cover transition-transform duration-200 group-hover:scale-105"
            />
          ) : (
            <div className="text-muted-foreground flex h-full items-center justify-center">
              <Package className="size-10" />
            </div>
          )}
          <div className="absolute top-2 start-2 flex flex-col gap-1">
            {hasDiscount && (
              <Badge variant="destructive">-{product.discount_pct}%</Badge>
            )}
            {product.stock_quantity <= 0 ? (
              <Badge variant="destructive">{locale === "ar" ? "نفد" : "Out"}</Badge>
            ) : product.stock_quantity <= 5 ? (
              <Badge variant="warning">{product.stock_quantity}</Badge>
            ) : null}
            {product.status === "draft" && (
              <Badge variant="secondary">{locale === "ar" ? "مسودة" : "Draft"}</Badge>
            )}
          </div>
        </div>
        <div className="p-3">
          <div className="text-muted-foreground truncate text-[11px]">
            {product.brand || product.sku}
          </div>
          <div className="line-clamp-2 text-sm font-semibold leading-snug">{name}</div>
          <div className="mt-2 flex items-baseline gap-1.5">
            {hasDiscount && (
              <span className="text-muted-foreground text-xs line-through">
                {formatMoney(product.compare_price)}
              </span>
            )}
            <span className="text-[15px] font-extrabold tabular-nums">
              {formatMoney(product.price_cash)}
            </span>
          </div>
          <div className="text-success mt-0.5 text-[11px] font-medium tabular-nums">
            {locale === "ar" ? "أو" : "or"} {formatMoney(monthly)} {locale === "ar" ? "شهرياً" : "/mo"}
          </div>
          {product.variant_count > 1 && (
            <div className="text-muted-foreground mt-1 text-[10px]">
              {product.variant_count} {locale === "ar" ? "خيارات" : "variants"}
            </div>
          )}
        </div>
      </Link>
      <div className="flex border-t">
        <Link
          href={`/products/${product.id}`}
          className="text-muted-foreground hover:text-foreground flex-1 py-2 text-center text-xs font-medium transition-colors"
        >
          {locale === "ar" ? "عرض" : "View"}
        </Link>
        <Button
          variant="ghost"
          className="text-primary flex-1 rounded-none border-s py-2 text-xs font-medium"
          onClick={() => onEdit(product)}
        >
          <Pencil className="size-3.5" />
          {locale === "ar" ? "تعديل" : "Edit"}
        </Button>
      </div>
    </div>
  );
}
