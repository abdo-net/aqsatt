"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Plus, Trash2 } from "lucide-react";

import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetFooter,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  useCategories,
  useCreateCategory,
  useCreateProduct,
  useUpdateProduct,
} from "@/hooks/use-products";
import type { ProductCard, ProductDetail, VariantInput } from "@/types/product";
import { ApiError } from "@/lib/api-client";

const productSchema = z.object({
  sku: z.string().min(1, "SKU مطلوب"),
  name: z.string().min(1, "الاسم مطلوب"),
  name_ar: z.string().optional(),
  brand: z.string().optional(),
  category_id: z.string().optional(),
  status: z.enum(["active", "draft"]),
  description: z.string().optional(),
});

type ProductFormValues = z.infer<typeof productSchema>;

interface VariantRow {
  sku: string;
  price_cash: string;
  compare_price: string;
  stock_quantity: string;
}

const blankVariant = (): VariantRow => ({
  sku: "",
  price_cash: "",
  compare_price: "",
  stock_quantity: "0",
});

/** Math.floor on every numeric field before it ever reaches the API —
 * the Iraqi dinar never carries fractional amounts, enforced at the one
 * boundary every variant row passes through regardless of which input
 * the user typed in. */
function toInt(value: string): number {
  return Math.floor(Number(value) || 0);
}

interface ProductFormSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  product: ProductCard | ProductDetail | null;
  locale: "ar" | "en";
}

export function ProductFormSheet({
  open,
  onOpenChange,
  product,
  locale,
}: ProductFormSheetProps) {
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="flex flex-col gap-0 sm:max-w-lg">
        {/* Keying on the target's identity forces React to fully remount
            this subtree whenever the user switches between "create" and
            "edit X", or between two different products to edit. That
            remount resets every useState/useForm call inside to its fresh
            initial value derived from the (now-current) `product` prop —
            no useEffect+setState sync needed, which is the official fix
            for the set-state-in-effect lint (see react.dev's "you might
            not need an effect" guide: "to reset a particular bit of state
            in response to a prop change... pass a different key"). */}
        <ProductFormInner
          key={product?.id ?? "new"}
          product={product}
          locale={locale}
          onDone={() => onOpenChange(false)}
        />
      </SheetContent>
    </Sheet>
  );
}

interface ProductFormInnerProps {
  product: ProductCard | ProductDetail | null;
  locale: "ar" | "en";
  onDone: () => void;
}

function ProductFormInner({ product, locale, onDone }: ProductFormInnerProps) {
  const isEditing = !!product;
  const { data: categories } = useCategories();
  const createCategory = useCreateCategory();
  const createProduct = useCreateProduct();
  const updateProduct = useUpdateProduct();
  const mutation = isEditing ? updateProduct : createProduct;

  const initialVariants: VariantRow[] =
    product && "variants" in product && product.variants.length
      ? product.variants.map((v) => ({
          sku: v.sku,
          price_cash: String(v.price_cash),
          compare_price: v.compare_price ? String(v.compare_price) : "",
          stock_quantity: String(v.stock_quantity),
        }))
      : [blankVariant()];

  const [variants, setVariants] = useState<VariantRow[]>(initialVariants);
  const [newCategoryName, setNewCategoryName] = useState("");

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ProductFormValues>({
    resolver: zodResolver(productSchema),
    defaultValues: product
      ? {
          sku: product.sku,
          name: product.name,
          name_ar: product.name_ar ?? "",
          brand: product.brand ?? "",
          category_id: product.category_id ? String(product.category_id) : "",
          status: product.status,
          description: "description" in product ? product.description ?? "" : "",
        }
      : { status: "active" },
  });

  async function onSubmit(values: ProductFormValues) {
    try {
      if (isEditing && product) {
        await updateProduct.mutateAsync({
          id: product.id,
          body: {
            name: values.name,
            name_ar: values.name_ar || undefined,
            brand: values.brand || undefined,
            category_id: values.category_id ? Number(values.category_id) : null,
            status: values.status,
            description: values.description || undefined,
          },
        });
      } else {
        const variantInputs: VariantInput[] = variants
          .filter((v) => toInt(v.price_cash) > 0)
          .map((v, i) => ({
            sku: v.sku || undefined,
            price_cash: toInt(v.price_cash),
            compare_price: toInt(v.compare_price) || undefined,
            stock_quantity: toInt(v.stock_quantity),
            is_default: i === 0,
          }));
        if (!variantInputs.length) return;
        await createProduct.mutateAsync({
          sku: values.sku,
          name: values.name,
          name_ar: values.name_ar || undefined,
          brand: values.brand || undefined,
          category_id: values.category_id ? Number(values.category_id) : undefined,
          status: values.status,
          description: values.description || undefined,
          variants: variantInputs,
        });
      }
      onDone();
    } catch {
      // surfaced via mutation.error below
    }
  }

  async function handleAddCategory() {
    const name = newCategoryName.trim();
    if (!name) return;
    await createCategory.mutateAsync({ name, name_ar: name });
    setNewCategoryName("");
  }

  function updateVariant(index: number, field: keyof VariantRow, value: string) {
    setVariants((prev) =>
      prev.map((v, i) => (i === index ? { ...v, [field]: value } : v))
    );
  }

  const t = (ar: string, en: string) => (locale === "ar" ? ar : en);

  return (
    <>
      <SheetHeader>
        <SheetTitle>
          {isEditing ? t("تعديل المنتج", "Edit product") : t("منتج جديد", "New product")}
        </SheetTitle>
      </SheetHeader>

      <form
        onSubmit={handleSubmit(onSubmit)}
        className="flex flex-1 flex-col overflow-y-auto"
        noValidate
      >
        <div className="flex-1 space-y-4 px-4 py-2">
          <div className="grid grid-cols-2 gap-3">
            {!isEditing && (
              <div className="space-y-1.5">
                <Label htmlFor="sku">SKU *</Label>
                <Input id="sku" {...register("sku")} aria-invalid={!!errors.sku} />
                {errors.sku && <p className="text-destructive text-xs">{errors.sku.message}</p>}
              </div>
            )}
            <div className={isEditing ? "col-span-2 space-y-1.5" : "space-y-1.5"}>
              <Label htmlFor="category_id">{t("التصنيف", "Category")}</Label>
              <select
                id="category_id"
                {...register("category_id")}
                className="border-input bg-card h-9 w-full rounded-md border px-3 text-sm shadow-xs outline-none"
              >
                  <option value="">—</option>
                  {categories?.map((c) => (
                    <option key={c.id} value={c.id}>
                      {locale === "ar" ? c.name_ar : c.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex gap-2">
              <Input
                value={newCategoryName}
                onChange={(e) => setNewCategoryName(e.target.value)}
                placeholder={t("تصنيف جديد…", "New category…")}
                className="text-xs"
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={handleAddCategory}
                disabled={createCategory.isPending}
              >
                <Plus className="size-4" />
              </Button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="name">{t("اسم المنتج", "Product name")} *</Label>
                <Input id="name" {...register("name")} aria-invalid={!!errors.name} />
                {errors.name && <p className="text-destructive text-xs">{errors.name.message}</p>}
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="name_ar">{t("الاسم بالعربي", "Arabic name")}</Label>
                <Input id="name_ar" dir="rtl" {...register("name_ar")} />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="brand">{t("العلامة التجارية", "Brand")}</Label>
                <Input id="brand" {...register("brand")} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="status">{t("الحالة", "Status")}</Label>
                <select
                  id="status"
                  {...register("status")}
                  className="border-input bg-card h-9 w-full rounded-md border px-3 text-sm shadow-xs outline-none"
                >
                  <option value="active">{t("نشط", "Active")}</option>
                  <option value="draft">{t("مسودة", "Draft")}</option>
                </select>
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="description">{t("الوصف", "Description")}</Label>
              <textarea
                id="description"
                {...register("description")}
                rows={2}
                className="border-input bg-card w-full resize-none rounded-md border px-3 py-2 text-sm shadow-xs outline-none"
              />
            </div>

            {!isEditing && (
              <div>
                <div className="mb-2 flex items-center justify-between">
                  <Label>{t("الأسعار والمخزون", "Pricing & Stock")}</Label>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => setVariants((prev) => [...prev, blankVariant()])}
                  >
                    <Plus className="size-3.5" />
                    {t("إضافة خيار", "Add variant")}
                  </Button>
                </div>
                <div className="space-y-2">
                  {variants.map((v, i) => (
                    <div key={i} className="grid grid-cols-12 gap-1.5">
                      <Input
                        placeholder="SKU"
                        value={v.sku}
                        onChange={(e) => updateVariant(i, "sku", e.target.value)}
                        className="col-span-3 h-8 text-xs"
                      />
                      <Input
                        type="number"
                        placeholder={t("سعر *", "Price *")}
                        value={v.price_cash}
                        onChange={(e) => updateVariant(i, "price_cash", e.target.value)}
                        className="col-span-3 h-8 text-xs"
                      />
                      <Input
                        type="number"
                        placeholder={t("مقارنة", "Compare")}
                        value={v.compare_price}
                        onChange={(e) => updateVariant(i, "compare_price", e.target.value)}
                        className="col-span-3 h-8 text-xs"
                      />
                      <Input
                        type="number"
                        placeholder={t("مخزون", "Stock")}
                        value={v.stock_quantity}
                        onChange={(e) => updateVariant(i, "stock_quantity", e.target.value)}
                        className="col-span-2 h-8 text-xs"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="col-span-1 size-8"
                        disabled={variants.length === 1}
                        onClick={() =>
                          setVariants((prev) => prev.filter((_, idx) => idx !== i))
                        }
                      >
                        <Trash2 className="text-destructive size-3.5" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {mutation.isError && (
              <p className="text-destructive text-sm">
                {mutation.error instanceof ApiError
                  ? mutation.error.message
                  : t("حدث خطأ", "Something went wrong")}
              </p>
            )}
          </div>

          <SheetFooter className="flex-row justify-end gap-2 border-t">
            <Button type="button" variant="outline" onClick={onDone}>
              {t("إلغاء", "Cancel")}
            </Button>
            <Button type="submit" disabled={mutation.isPending}>
              {mutation.isPending
                ? t("جارٍ الحفظ…", "Saving…")
                : isEditing
                  ? t("حفظ التغييرات", "Save changes")
                  : t("حفظ", "Save")}
            </Button>
          </SheetFooter>
        </form>
    </>
  );
}
