import { NextRequest, NextResponse } from "next/server";

import { API_BASE_URL, AUTH_COOKIE_NAME } from "@/lib/env";

export async function POST(req: NextRequest) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ detail: "Invalid request body" }, { status: 400 });
  }

  let upstream: Response;
  try {
    upstream = await fetch(`${API_BASE_URL}/api/v1/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
  } catch {
    return NextResponse.json(
      { detail: "Cannot reach the API server" },
      { status: 502 }
    );
  }

  const data = await upstream.json().catch(() => ({}));

  if (!upstream.ok) {
    return NextResponse.json(data, { status: upstream.status });
  }

  const { access_token, tenant_id, user_id, permissions } = data as {
    access_token: string;
    tenant_id: number;
    user_id: number;
    permissions: string[];
  };

  const res = NextResponse.json({ tenant_id, user_id, permissions });

  res.cookies.set(AUTH_COOKIE_NAME, access_token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    // Mirrors the backend's JWT_EXP_HOURS default (12h) — kept as a constant
    // here rather than parsed from the JWT, since the cookie's own maxAge is
    // just a browser-side cleanup hint; the actual expiry is enforced by the
    // backend decoding the token on every request regardless of this value.
    maxAge: 60 * 60 * 12,
  });

  return res;
}
