import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";

import { API_BASE_URL, AUTH_COOKIE_NAME } from "@/lib/env";

async function proxy(
  req: NextRequest,
  { params }: { params: Promise<{ path: string[] }> }
) {
  const { path } = await params;
  const cookieStore = await cookies();
  const token = cookieStore.get(AUTH_COOKIE_NAME)?.value;

  if (!token) {
    return NextResponse.json({ detail: "Not authenticated" }, { status: 401 });
  }

  const search = req.nextUrl.search; // includes leading "?" or is ""
  const upstreamUrl = `${API_BASE_URL}/api/v1/${path.join("/")}${search}`;

  const init: RequestInit = {
    method: req.method,
    headers: {
      Authorization: `Bearer ${token}`,
      ...(req.headers.get("content-type")
        ? { "Content-Type": req.headers.get("content-type")! }
        : {}),
    },
  };

  if (req.method !== "GET" && req.method !== "HEAD") {
    // Pass the body through as-is. For multipart/form-data (image uploads),
    // req.body is a ReadableStream and fetch() forwards it directly without
    // buffering — this matters for the product-image upload endpoints.
    init.body = req.body;
    // @ts-expect-error -- duplex is required by undici for streaming bodies
    // but is missing from the TS DOM lib's RequestInit type as of this
    // Next.js/TypeScript version.
    init.duplex = "half";
  }

  let upstream: Response;
  try {
    upstream = await fetch(upstreamUrl, init);
  } catch {
    return NextResponse.json(
      { detail: "Cannot reach the API server" },
      { status: 502 }
    );
  }

  const contentType = upstream.headers.get("content-type") ?? "";
  const status = upstream.status;

  if (contentType.includes("application/json")) {
    const data = await upstream.json().catch(() => null);
    return NextResponse.json(data, { status });
  }

  // Non-JSON responses (e.g. file downloads) pass through as a stream.
  return new NextResponse(upstream.body, {
    status,
    headers: { "content-type": contentType },
  });
}

export {
  proxy as GET,
  proxy as POST,
  proxy as PATCH,
  proxy as PUT,
  proxy as DELETE,
};
