"use client";

import { useRouter, usePathname } from "next/navigation";
import { useQueryClient } from "@tanstack/react-query";

import { DesktopSidebar } from "@/components/layout/desktop-sidebar";
import { Topbar } from "@/components/layout/topbar";
import { useCurrentUser } from "@/hooks/use-current-user";
import { useLocale } from "@/components/providers/locale-provider";
import { Skeleton } from "@/components/ui/skeleton";
import { NAV_ITEMS } from "@/config/nav";

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const { data: user, isLoading, isError, error } = useCurrentUser();
  const { locale } = useLocale();
  const router = useRouter();
  const pathname = usePathname();
  const queryClient = useQueryClient();

  async function handleLogout() {
    await fetch("/api/auth/logout", { method: "POST" });
    queryClient.clear();
    router.push("/login");
  }

  // Loading: skeleton shell, not a blank screen or a centered spinner that
  // hides the whole page — the sidebar/topbar shape stays visible so the
  // layout doesn't jump once data arrives.
  if (isLoading) {
    return (
      <div className="flex min-h-screen">
        <aside className="bg-sidebar fixed inset-y-0 start-0 hidden w-64 lg:flex" />
        <div className="ms-0 flex flex-1 flex-col lg:ms-64">
          <div className="flex h-15 items-center justify-between border-b px-4 lg:px-6">
            <Skeleton className="h-5 w-32" />
            <Skeleton className="size-8 rounded-full" />
          </div>
          <div className="flex-1 p-4 lg:p-6">
            <Skeleton className="h-40 w-full rounded-lg" />
          </div>
        </div>
      </div>
    );
  }

  // 401 from /me means the cookie is missing/expired despite passing the
  // proxy's presence check (e.g. token expired server-side) — send to login
  // rather than rendering a shell with no user data.
  if (isError || !user) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-3 p-6 text-center">
        <p className="text-destructive text-sm font-medium">
          {locale === "ar"
            ? "تعذّر تحميل بيانات المستخدم"
            : "Could not load user data"}
        </p>
        <p className="text-muted-foreground text-xs">
          {error instanceof Error ? error.message : ""}
        </p>
        <button
          onClick={() => router.push("/login")}
          className="bg-primary text-primary-foreground mt-2 rounded-md px-4 py-2 text-sm font-medium"
        >
          {locale === "ar" ? "إعادة تسجيل الدخول" : "Back to login"}
        </button>
      </div>
    );
  }

  const activeItem = NAV_ITEMS.find(
    (item) => pathname === item.href || pathname.startsWith(item.href + "/")
  );
  const pageTitle = activeItem ? activeItem.label[locale] : "CCS";

  return (
    <div className="flex min-h-screen">
      <DesktopSidebar permissions={user.permissions} onLogout={handleLogout} />
      <div className="flex flex-1 flex-col lg:ms-64">
        <Topbar
          title={pageTitle}
          permissions={user.permissions}
          username={user.username}
          tenantId={user.tenant_id}
          onLogout={handleLogout}
        />
        <main className="mx-auto w-full max-w-[1400px] flex-1 p-4 lg:p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
