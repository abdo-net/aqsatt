"use client";

import { useState } from "react";
import { Plus, Search } from "lucide-react";

import { useCategories, useProducts } from "@/hooks/use-products";
import { useLocale } from "@/components/providers/locale-provider";
import { ProductCard } from "@/components/products/product-card";
import { ProductFormSheet } from "@/components/products/product-form-sheet";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import type { ProductCard as ProductCardType } from "@/types/product";

const PAGE_SIZE = 20;

export default function ProductsPage() {
  const { locale } = useLocale();
  const [page, setPage] = useState(1);
  const [searchInput, setSearchInput] = useState("");
  const [search, setSearch] = useState("");
  const [categoryId, setCategoryId] = useState<number | undefined>(undefined);
  const [sheetOpen, setSheetOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<ProductCardType | null>(null);

  const { data: categories } = useCategories();
  const { data, isLoading } = useProducts({
    page,
    pageSize: PAGE_SIZE,
    search,
    categoryId,
  });

  function handleSearchSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSearch(searchInput.trim());
    setPage(1);
  }

  function openCreate() {
    setEditingProduct(null);
    setSheetOpen(true);
  }

  function openEdit(product: ProductCardType) {
    setEditingProduct(product);
    setSheetOpen(true);
  }

  const products = data?.data ?? [];

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <form onSubmit={handleSearchSubmit} className="relative min-w-0 flex-1">
          <Search className="text-muted-foreground absolute inset-y-0 start-3 my-auto size-4" />
          <Input
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            placeholder={locale === "ar" ? "ابحث عن منتج…" : "Search products…"}
            className="ps-9"
          />
        </form>
        <select
          value={categoryId ?? ""}
          onChange={(e) => {
            setCategoryId(e.target.value ? Number(e.target.value) : undefined);
            setPage(1);
          }}
          className="border-input bg-card h-9 rounded-md border px-3 text-sm shadow-xs outline-none"
        >
          <option value="">{locale === "ar" ? "كل التصنيفات" : "All categories"}</option>
          {categories?.map((c) => (
            <option key={c.id} value={c.id}>
              {locale === "ar" ? c.name_ar : c.name} ({c.product_count})
            </option>
          ))}
        </select>
        <Button onClick={openCreate} className="shrink-0">
          <Plus className="size-4" />
          {locale === "ar" ? "منتج جديد" : "New product"}
        </Button>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
          {Array.from({ length: 10 }).map((_, i) => (
            <Skeleton key={i} className="aspect-[3/4] w-full rounded-lg" />
          ))}
        </div>
      ) : products.length === 0 ? (
        <div className="bg-card text-muted-foreground rounded-lg border p-12 text-center text-sm">
          {locale === "ar" ? "لا توجد منتجات" : "No products"}
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
          {products.map((p) => (
            <ProductCard key={p.id} product={p} locale={locale} onEdit={openEdit} />
          ))}
        </div>
      )}

      {data && data.total_pages > 1 && (
        <div className="flex items-center justify-center gap-2">
          <Button
            variant="outline"
            size="sm"
            disabled={page <= 1}
            onClick={() => setPage((p) => p - 1)}
          >
            {locale === "ar" ? "السابق" : "Previous"}
          </Button>
          <span className="text-muted-foreground text-xs tabular-nums">
            {data.page} / {data.total_pages}
          </span>
          <Button
            variant="outline"
            size="sm"
            disabled={page >= data.total_pages}
            onClick={() => setPage((p) => p + 1)}
          >
            {locale === "ar" ? "التالي" : "Next"}
          </Button>
        </div>
      )}

      <ProductFormSheet
        open={sheetOpen}
        onOpenChange={setSheetOpen}
        product={editingProduct}
        locale={locale}
      />
    </div>
  );
}
