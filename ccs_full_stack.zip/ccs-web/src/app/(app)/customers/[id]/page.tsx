"use client";

import { useParams, useRouter } from "next/navigation";
import { ArrowLeft, Phone, ShoppingCart } from "lucide-react";

import { useLocale } from "@/components/providers/locale-provider";
import { useCustomer } from "@/hooks/use-customers";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDate, formatMoney } from "@/lib/format";
import type { InstallmentStatus } from "@/types/sale";

const RISK_LABEL: Record<string, { ar: string; en: string }> = {
  qi: { ar: "ممتاز (QI)", en: "Excellent (QI)" },
  trusted: { ar: "موثوق", en: "Trusted" },
  mixed: { ar: "مختلط", en: "Mixed" },
};

const INSTALLMENT_BADGE: Record<InstallmentStatus, "success" | "destructive" | "warning" | "secondary"> = {
  paid: "success",
  late: "destructive",
  partially_paid: "warning",
  pending: "secondary",
  cancelled: "secondary",
};

export default function CustomerProfilePage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const { locale } = useLocale();
  const customerId = Number(params.id);
  const { data: customer, isLoading, isError } = useCustomer(
    Number.isFinite(customerId) ? customerId : null
  );

  const t = (ar: string, en: string) => (locale === "ar" ? ar : en);

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-24 w-full rounded-lg" />
        <Skeleton className="h-64 w-full rounded-lg" />
      </div>
    );
  }

  if (isError || !customer) {
    return (
      <div className="bg-card text-muted-foreground rounded-lg border p-12 text-center text-sm">
        {t("الزبون غير موجود", "Customer not found")}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <button
        onClick={() => router.push("/customers")}
        className="text-muted-foreground hover:text-foreground flex items-center gap-1.5 text-sm transition-colors"
      >
        <ArrowLeft className="size-4 rtl:rotate-180" />
        {t("الزبائن", "Customers")}
      </button>

      <div className="bg-card rounded-lg border p-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="bg-accent text-accent-foreground flex size-14 shrink-0 items-center justify-center rounded-full text-xl font-bold">
              {(customer.full_name || "?")[0]}
            </div>
            <div>
              <h1 className="text-xl font-bold">{customer.full_name}</h1>
              <div className="text-muted-foreground mt-0.5 flex items-center gap-1.5 text-sm">
                <Phone className="size-3.5" />
                {customer.phone}
              </div>
              <div className="mt-1.5 flex gap-1.5">
                <Badge variant="secondary">
                  {RISK_LABEL[customer.risk_class]?.[locale] ?? customer.risk_class}
                </Badge>
                {customer.status === "blocked" && (
                  <Badge variant="destructive">{t("محظور", "Blocked")}</Badge>
                )}
              </div>
            </div>
          </div>
          <div className="text-end">
            <div className="text-muted-foreground text-xs">
              {t("الرصيد المستحق", "Outstanding balance")}
            </div>
            <div
              className={
                customer.receivable_balance > 0
                  ? "text-destructive text-2xl font-extrabold tabular-nums"
                  : "text-success text-2xl font-extrabold tabular-nums"
              }
            >
              {formatMoney(customer.receivable_balance)}
            </div>
          </div>
        </div>

        {(customer.address || customer.notes) && (
          <div className="mt-4 grid gap-3 border-t pt-4 sm:grid-cols-2">
            {customer.address && (
              <div>
                <div className="text-muted-foreground text-xs">{t("العنوان", "Address")}</div>
                <div className="text-sm">{customer.address}</div>
              </div>
            )}
            {customer.notes && (
              <div>
                <div className="text-muted-foreground text-xs">{t("ملاحظات", "Notes")}</div>
                <div className="text-sm">{customer.notes}</div>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="space-y-3">
        <h2 className="text-sm font-semibold">{t("المشتريات", "Purchases")}</h2>
        {customer.sales.length === 0 ? (
          <div className="bg-card text-muted-foreground flex flex-col items-center gap-2 rounded-lg border p-12 text-sm">
            <ShoppingCart className="size-8 opacity-40" />
            {t("لا توجد مشتريات", "No purchases")}
          </div>
        ) : (
          customer.sales.map((sale) => (
            <div key={sale.id} className="bg-card rounded-lg border p-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-sm font-semibold">{sale.sale_number}</span>
                  <Badge variant={sale.type === "cash" ? "secondary" : "info"}>
                    {sale.type === "cash"
                      ? t("نقدي", "Cash")
                      : t("تقسيط", "Installment")}
                  </Badge>
                  <Badge
                    variant={
                      sale.status === "completed"
                        ? "success"
                        : sale.status === "cancelled"
                          ? "destructive"
                          : "info"
                    }
                  >
                    {sale.status}
                  </Badge>
                </div>
                <span className="font-semibold tabular-nums">{formatMoney(sale.total_price)}</span>
              </div>

              {sale.schedule.length > 0 && (
                <div className="mt-3 space-y-1.5 border-t pt-3">
                  {sale.schedule.map((row) => (
                    <div
                      key={row.installment_number}
                      className="flex items-center justify-between text-sm"
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-muted-foreground w-6 text-xs tabular-nums">
                          #{row.installment_number}
                        </span>
                        <span className="text-muted-foreground text-xs">
                          {formatDate(row.due_date)}
                        </span>
                        <Badge variant={INSTALLMENT_BADGE[row.status]}>{row.status}</Badge>
                      </div>
                      <span className="tabular-nums">
                        {row.remaining > 0 ? (
                          formatMoney(row.remaining)
                        ) : (
                          <span className="text-success">✓ {formatMoney(row.amount)}</span>
                        )}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
