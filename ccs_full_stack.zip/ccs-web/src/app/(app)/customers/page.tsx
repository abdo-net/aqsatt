"use client";

import { useState } from "react";
import { Plus, Search } from "lucide-react";

import { useCustomers } from "@/hooks/use-customers";
import { useLocale } from "@/components/providers/locale-provider";
import { DataTable } from "@/components/data-table";
import { buildCustomerColumns } from "@/components/customers/columns";
import { CustomerFormSheet } from "@/components/customers/customer-form-sheet";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import type { Customer } from "@/types/customer";

const PAGE_SIZE = 20;

export default function CustomersPage() {
  const { locale } = useLocale();
  const [page, setPage] = useState(1);
  const [searchInput, setSearchInput] = useState("");
  const [search, setSearch] = useState("");
  const [sheetOpen, setSheetOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);

  const { data, isLoading, isFetching } = useCustomers({
    page,
    pageSize: PAGE_SIZE,
    search,
  });

  function handleSearchSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSearch(searchInput.trim());
    setPage(1);
  }

  function openCreate() {
    setEditingCustomer(null);
    setSheetOpen(true);
  }

  function openEdit(customer: Customer) {
    setEditingCustomer(customer);
    setSheetOpen(true);
  }

  const columns = buildCustomerColumns(locale, openEdit);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <form onSubmit={handleSearchSubmit} className="relative min-w-0 flex-1">
          <Search className="text-muted-foreground absolute inset-y-0 start-3 my-auto size-4" />
          <Input
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            placeholder={locale === "ar" ? "ابحث عن زبون…" : "Search customers…"}
            className="ps-9"
          />
        </form>
        <Button onClick={openCreate} className="shrink-0">
          <Plus className="size-4" />
          {locale === "ar" ? "زبون جديد" : "New customer"}
        </Button>
      </div>

      <DataTable
        columns={columns}
        data={data?.data ?? []}
        isLoading={isLoading}
        isFetching={isFetching}
        page={data?.page ?? page}
        totalPages={data?.total_pages ?? 0}
        totalCount={data?.total_count ?? 0}
        onPageChange={setPage}
        emptyMessage={locale === "ar" ? "لا توجد بيانات" : "No data"}
      />

      <CustomerFormSheet
        open={sheetOpen}
        onOpenChange={setSheetOpen}
        customer={editingCustomer}
        locale={locale}
      />
    </div>
  );
}
