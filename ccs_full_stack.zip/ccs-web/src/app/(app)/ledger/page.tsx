"use client";

import { Wallet } from "lucide-react";

import { useLocale } from "@/components/providers/locale-provider";
import { useLedgerAccounts, useLedgerEntries } from "@/hooks/use-ledger";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDate, formatMoney } from "@/lib/format";

export default function LedgerPage() {
  const { locale } = useLocale();
  const { data: accounts, isLoading: accountsLoading } = useLedgerAccounts();
  const { data: entries, isLoading: entriesLoading } = useLedgerEntries(undefined, 60);

  const t = (ar: string, en: string) => (locale === "ar" ? ar : en);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {accountsLoading
          ? Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-24 rounded-lg" />
            ))
          : accounts?.map((a) => (
              <div key={a.code} className="bg-card rounded-lg border p-4">
                <div className="text-muted-foreground text-xs font-medium">
                  {locale === "ar" ? a.name_ar : a.name}
                </div>
                <div className="mt-1.5 text-xl font-extrabold tabular-nums">
                  {formatMoney(a.balance)}
                </div>
                <div className="text-muted-foreground mt-0.5 text-[11px] uppercase">
                  {a.type}
                </div>
              </div>
            ))}
      </div>

      <div className="bg-card overflow-hidden rounded-lg border">
        <div className="border-b px-4 py-3 text-sm font-semibold">
          {t("حركة القيود", "Transaction flow")}
        </div>
        <div className="divide-y">
          {entriesLoading ? (
            Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="p-3">
                <Skeleton className="h-12 w-full" />
              </div>
            ))
          ) : !entries || entries.length === 0 ? (
            <div className="text-muted-foreground flex flex-col items-center gap-2 p-12 text-sm">
              <Wallet className="size-8 opacity-40" />
              {t("لا توجد حركات", "No transactions")}
            </div>
          ) : (
            entries.map((group) => (
              <div key={group.transaction_group_id} className="p-3">
                <div className="mb-1.5 flex items-center justify-between">
                  <span className="text-muted-foreground text-xs">
                    {group.reference_type} #{group.reference_id}
                  </span>
                  <span className="text-muted-foreground text-xs">
                    {formatDate(group.created_at)}
                  </span>
                </div>
                <div className="space-y-1">
                  {group.lines.map((line, i) => (
                    <div key={i} className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">
                        {locale === "ar" ? line.account_name_ar : line.account_name}
                      </span>
                      <span className="tabular-nums">
                        {line.debit > 0 ? (
                          <span className="font-medium">{formatMoney(line.debit)}</span>
                        ) : (
                          <span className="text-muted-foreground">
                            ({formatMoney(line.credit)})
                          </span>
                        )}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
