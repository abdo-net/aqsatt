"use client";

import { useState } from "react";
import { Wallet } from "lucide-react";

import { useLocale } from "@/components/providers/locale-provider";
import { usePayments, useCreatePayment } from "@/hooks/use-payments";
import { useSales } from "@/hooks/use-sales";
import { CustomerSearch } from "@/components/sales/customer-search";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDate, formatMoney } from "@/lib/format";
import { ApiError } from "@/lib/api-client";
import type { Customer } from "@/types/customer";

const PAYMENT_METHODS = ["cash", "qi", "transfer", "zaincash", "visa"] as const;

export default function PaymentsPage() {
  const { locale } = useLocale();
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [saleId, setSaleId] = useState<number | null>(null);
  const [amount, setAmount] = useState(0);
  const [method, setMethod] = useState<typeof PAYMENT_METHODS[number]>("cash");

  const { data: customerSales } = useSales({
    page: 1,
    pageSize: 20,
    customerId: customer?.id,
    status: "active",
  });
  const { data: payments, isLoading: paymentsLoading } = usePayments({ limit: 30 });
  const createPayment = useCreatePayment();

  const t = (ar: string, en: string) => (locale === "ar" ? ar : en);
  const toInt = (v: number) => Math.floor(v) || 0;

  const installmentSales = (customerSales?.data ?? []).filter(
    (s) => s.sale_type === "installment"
  );

  async function handleSubmit() {
    if (!saleId || toInt(amount) <= 0) return;
    try {
      await createPayment.mutateAsync({
        sale_id: saleId,
        amount: toInt(amount),
        payment_method: method,
      });
      setAmount(0);
      setSaleId(null);
      setCustomer(null);
    } catch {
      // surfaced via createPayment.error
    }
  }

  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <div className="bg-card space-y-4 rounded-lg border p-4 lg:col-span-1">
        <Label>{t("الزبون", "Customer")}</Label>
        <CustomerSearch
          selected={customer}
          onSelect={(c) => {
            setCustomer(c);
            setSaleId(null);
          }}
          locale={locale}
        />

        {customer && (
          <div className="space-y-1.5">
            <Label htmlFor="sale_select">{t("اختر البيع", "Select sale")}</Label>
            {installmentSales.length === 0 ? (
              <p className="text-muted-foreground text-xs">
                {t("لا توجد مبيعات تقسيط نشطة", "No active installment sales")}
              </p>
            ) : (
              <select
                id="sale_select"
                value={saleId ?? ""}
                onChange={(e) => setSaleId(Number(e.target.value))}
                className="border-input bg-card h-9 w-full rounded-md border px-3 text-sm shadow-xs outline-none"
              >
                <option value="">—</option>
                {installmentSales.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.sale_number} — {formatMoney(s.total_price)}
                  </option>
                ))}
              </select>
            )}
          </div>
        )}

        <div className="space-y-1.5">
          <Label htmlFor="amount">{t("المبلغ", "Amount")}</Label>
          <Input
            id="amount"
            type="number"
            min={1}
            value={amount || ""}
            onChange={(e) => setAmount(toInt(Number(e.target.value)))}
          />
        </div>

        <div className="space-y-1.5">
          <Label htmlFor="method">{t("طريقة الدفع", "Payment method")}</Label>
          <select
            id="method"
            value={method}
            onChange={(e) => setMethod(e.target.value as typeof method)}
            className="border-input bg-card h-9 w-full rounded-md border px-3 text-sm shadow-xs outline-none"
          >
            {PAYMENT_METHODS.map((m) => (
              <option key={m} value={m}>
                {m === "cash"
                  ? t("نقدي", "Cash")
                  : m === "qi"
                    ? "QI Card"
                    : m === "transfer"
                      ? t("تحويل", "Transfer")
                      : m === "zaincash"
                        ? "ZainCash"
                        : "Visa"}
              </option>
            ))}
          </select>
        </div>

        {createPayment.isError && (
          <p className="text-destructive text-sm">
            {createPayment.error instanceof ApiError
              ? createPayment.error.message
              : t("حدث خطأ", "Something went wrong")}
          </p>
        )}

        <Button
          className="w-full"
          disabled={!saleId || toInt(amount) <= 0 || createPayment.isPending}
          onClick={handleSubmit}
        >
          {createPayment.isPending ? t("جارٍ التسديد…", "Recording…") : t("تسديد", "Record payment")}
        </Button>
      </div>

      <div className="bg-card overflow-hidden rounded-lg border lg:col-span-2">
        <div className="border-b px-4 py-3 text-sm font-semibold">
          {t("آخر المدفوعات", "Recent payments")}
        </div>
        <div className="divide-y">
          {paymentsLoading ? (
            Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="p-3">
                <Skeleton className="h-10 w-full" />
              </div>
            ))
          ) : !payments || payments.length === 0 ? (
            <div className="text-muted-foreground flex flex-col items-center gap-2 p-12 text-sm">
              <Wallet className="size-8 opacity-40" />
              {t("لا توجد مدفوعات", "No payments")}
            </div>
          ) : (
            payments.map((p) => (
              <div key={p.id} className="flex items-center gap-3 p-3">
                <div className="bg-success/10 text-success flex size-9 shrink-0 items-center justify-center rounded-full">
                  <Wallet className="size-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-medium">{p.receipt_number}</div>
                  <div className="text-muted-foreground text-xs">
                    {formatDate(p.paid_at)} · <Badge variant="secondary">{p.payment_method}</Badge>
                  </div>
                </div>
                <span className="text-success font-semibold tabular-nums">
                  {formatMoney(p.amount)}
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
