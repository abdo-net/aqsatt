"use client";

import {
  AlertTriangle,
  Clock,
  ShoppingCart,
  TrendingUp,
  Users,
  Wallet,
} from "lucide-react";

import { useDashboardSummary } from "@/hooks/use-dashboard";
import { useLocale } from "@/components/providers/locale-provider";
import { Skeleton } from "@/components/ui/skeleton";
import { formatMoney, formatNumber } from "@/lib/format";

export default function DashboardPage() {
  const { locale } = useLocale();
  const { data, isLoading, isError } = useDashboardSummary();

  const t = (ar: string, en: string) => (locale === "ar" ? ar : en);

  if (isError) {
    return (
      <div className="bg-card text-destructive rounded-lg border p-12 text-center text-sm">
        {t("تعذّر تحميل البيانات", "Could not load data")}
      </div>
    );
  }

  const kpis = [
    {
      label: t("إجمالي الديون", "Outstanding debt"),
      value: data ? formatMoney(data.total_outstanding) : null,
      icon: Wallet,
      color: "text-destructive bg-destructive/10",
    },
    {
      label: t("محصّل اليوم", "Collected today"),
      value: data ? formatMoney(data.today_payments) : null,
      icon: TrendingUp,
      color: "text-success bg-success/10",
    },
    {
      label: t("إجمالي المحصّل", "Total collected"),
      value: data ? formatMoney(data.total_cash_collected) : null,
      icon: Wallet,
      color: "text-primary bg-primary/10",
    },
    {
      label: t("أقساط متأخرة", "Overdue installments"),
      value: data ? formatNumber(data.overdue_count) : null,
      icon: AlertTriangle,
      color: data && data.overdue_count > 0 ? "text-warning bg-warning/10" : "text-success bg-success/10",
    },
    {
      label: t("الزبائن", "Customers"),
      value: data ? formatNumber(data.customers_count) : null,
      icon: Users,
      color: "text-info bg-info/10",
    },
    {
      label: t("مبيعات نشطة", "Active sales"),
      value: data ? formatNumber(data.active_sales_count) : null,
      icon: ShoppingCart,
      color: "text-primary bg-primary/10",
    },
  ];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-3">
        {kpis.map((kpi) => {
          const Icon = kpi.icon;
          return (
            <div key={kpi.label} className="bg-card rounded-lg border p-4 shadow-xs">
              <div className="flex items-start justify-between">
                <div className={`flex size-8 items-center justify-center rounded-md ${kpi.color}`}>
                  <Icon className="size-4" />
                </div>
              </div>
              {isLoading ? (
                <Skeleton className="mt-3 h-7 w-24" />
              ) : (
                <div className="mt-2 text-2xl font-extrabold tabular-nums">{kpi.value}</div>
              )}
              <div className="text-muted-foreground mt-1 text-xs font-medium">{kpi.label}</div>
            </div>
          );
        })}
      </div>

      {!isLoading && data && data.overdue_count === 0 && (
        <div className="bg-success/10 text-success flex items-center gap-2 rounded-lg border border-success/20 p-4 text-sm font-medium">
          <Clock className="size-4" />
          {t("لا توجد أقساط متأخرة 🎉", "No overdue installments 🎉")}
        </div>
      )}
    </div>
  );
}
