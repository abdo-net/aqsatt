"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Plus, ShoppingCart, Trash2 } from "lucide-react";

import { useLocale } from "@/components/providers/locale-provider";
import { CustomerSearch } from "@/components/sales/customer-search";
import { ProductSearch } from "@/components/sales/product-search";
import { useCreateSale } from "@/hooks/use-sales";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { formatMoney } from "@/lib/format";
import { ApiError } from "@/lib/api-client";
import type { Customer } from "@/types/customer";
import type { ProductCard } from "@/types/product";

interface CartLine {
  productId: number;
  name: string;
  priceCash: number;
  quantity: number;
  stock: number;
}

/** Hard rule, enforced at every numeric boundary in this form: the Iraqi
 * dinar carries no fractional amounts. Every price/quantity/discount field
 * is floored before it's used in any calculation or sent to the API. */
const toInt = (v: number) => Math.floor(v) || 0;

export default function NewSalePage() {
  const { locale } = useLocale();
  const router = useRouter();
  const createSale = useCreateSale();

  const [customer, setCustomer] = useState<Customer | null>(null);
  const [cart, setCart] = useState<CartLine[]>([]);
  const [saleType, setSaleType] = useState<"cash" | "installment">("cash");
  const [discountAmount, setDiscountAmount] = useState(0);
  const [downPayment, setDownPayment] = useState(0);
  const [months, setMonths] = useState(6);
  const [frequency, setFrequency] = useState<"monthly" | "weekly">("monthly");
  const [startDate, setStartDate] = useState(
    new Date().toISOString().slice(0, 10)
  );

  const t = (ar: string, en: string) => (locale === "ar" ? ar : en);

  function addProduct(p: ProductCard) {
    setCart((prev) => {
      const existing = prev.find((l) => l.productId === p.id);
      if (existing) {
        return prev.map((l) =>
          l.productId === p.id ? { ...l, quantity: l.quantity + 1 } : l
        );
      }
      return [
        ...prev,
        {
          productId: p.id,
          name: locale === "ar" ? p.name_ar || p.name : p.name,
          priceCash: toInt(p.price_cash),
          quantity: 1,
          stock: p.stock_quantity,
        },
      ];
    });
  }

  function updateQuantity(productId: number, quantity: number) {
    setCart((prev) =>
      prev.map((l) =>
        l.productId === productId ? { ...l, quantity: Math.max(1, toInt(quantity)) } : l
      )
    );
  }

  function removeLine(productId: number) {
    setCart((prev) => prev.filter((l) => l.productId !== productId));
  }

  const subtotal = useMemo(
    () => cart.reduce((sum, l) => sum + l.priceCash * l.quantity, 0),
    [cart]
  );
  const total = Math.max(0, subtotal - toInt(discountAmount));
  const principal = saleType === "installment" ? Math.max(0, total - toInt(downPayment)) : 0;
  const monthlyAmount = saleType === "installment" && months > 0
    ? Math.floor(principal / months)
    : 0;

  const stockError = cart.find((l) => l.quantity > l.stock);
  const canSubmit =
    !!customer &&
    cart.length > 0 &&
    !stockError &&
    total > 0 &&
    (saleType === "cash" || (months > 0 && startDate));

  async function handleSubmit() {
    if (!customer || !canSubmit) return;
    try {
      const result = await createSale.mutateAsync({
        customer_id: customer.id,
        sale_type: saleType,
        items: cart.map((l) => ({ product_id: l.productId, quantity: l.quantity })),
        discount_amount: toInt(discountAmount),
        ...(saleType === "installment"
          ? {
              down_payment: toInt(downPayment),
              months,
              frequency,
              start_date: startDate,
            }
          : {}),
      });
      router.push(`/customers/${result.customer_id}`);
    } catch {
      // surfaced via createSale.error below
    }
  }

  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <div className="space-y-4 lg:col-span-2">
        <div className="bg-card space-y-3 rounded-lg border p-4">
          <Label>{t("الزبون", "Customer")}</Label>
          <CustomerSearch selected={customer} onSelect={setCustomer} locale={locale} />
          {customer && (
            <div className="bg-muted flex items-center gap-3 rounded-md p-3">
              <div className="bg-accent text-accent-foreground flex size-9 shrink-0 items-center justify-center rounded-full text-sm font-bold">
                {(customer.full_name || "?")[0]}
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-sm font-semibold">{customer.full_name}</div>
                <div className="text-muted-foreground text-xs">{customer.phone}</div>
              </div>
              {customer.receivable_balance > 0 && (
                <span className="text-destructive text-sm font-semibold tabular-nums">
                  {formatMoney(customer.receivable_balance)}
                </span>
              )}
            </div>
          )}
        </div>

        <div className="bg-card space-y-3 rounded-lg border p-4">
          <Label>{t("المنتجات", "Products")}</Label>
          <ProductSearch onSelect={addProduct} locale={locale} />

          {cart.length === 0 ? (
            <div className="text-muted-foreground flex flex-col items-center gap-2 py-8 text-sm">
              <ShoppingCart className="size-8 opacity-40" />
              {t("أضف منتجاً للبدء", "Add a product to start")}
            </div>
          ) : (
            <div className="space-y-2">
              {cart.map((line) => (
                <div
                  key={line.productId}
                  className="flex flex-wrap items-center gap-3 rounded-md border p-2.5"
                >
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-sm font-medium">{line.name}</div>
                    {line.quantity > line.stock && (
                      <div className="text-destructive text-xs">
                        {t("المخزون غير كافٍ", "Insufficient stock")} ({line.stock})
                      </div>
                    )}
                  </div>
                  <Input
                    type="number"
                    min={1}
                    value={line.quantity}
                    onChange={(e) => updateQuantity(line.productId, Number(e.target.value))}
                    className="h-8 w-16 text-center"
                  />
                  <span className="w-28 text-end text-sm font-semibold tabular-nums">
                    {formatMoney(line.priceCash * line.quantity)}
                  </span>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="size-8"
                    onClick={() => removeLine(line.productId)}
                  >
                    <Trash2 className="text-destructive size-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="bg-card space-y-4 rounded-lg border p-4">
          <Label>{t("طريقة الدفع", "Payment method")}</Label>
          <div className="flex gap-2">
            <Button
              type="button"
              variant={saleType === "cash" ? "default" : "outline"}
              className="flex-1"
              onClick={() => setSaleType("cash")}
            >
              {t("نقدي", "Cash")}
            </Button>
            <Button
              type="button"
              variant={saleType === "installment" ? "default" : "outline"}
              className="flex-1"
              onClick={() => setSaleType("installment")}
            >
              {t("تقسيط", "Installment")}
            </Button>
          </div>

          {saleType === "installment" && (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <div className="space-y-1.5">
                <Label htmlFor="down_payment">{t("الدفعة المقدمة", "Down payment")}</Label>
                <Input
                  id="down_payment"
                  type="number"
                  min={0}
                  value={downPayment}
                  onChange={(e) => setDownPayment(toInt(Number(e.target.value)))}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="months">{t("عدد الأشهر", "Months")}</Label>
                <Input
                  id="months"
                  type="number"
                  min={1}
                  value={months}
                  onChange={(e) => setMonths(Math.max(1, toInt(Number(e.target.value))))}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="frequency">{t("التكرار", "Frequency")}</Label>
                <select
                  id="frequency"
                  value={frequency}
                  onChange={(e) => setFrequency(e.target.value as "monthly" | "weekly")}
                  className="border-input bg-card h-9 w-full rounded-md border px-3 text-sm shadow-xs outline-none"
                >
                  <option value="monthly">{t("شهري", "Monthly")}</option>
                  <option value="weekly">{t("أسبوعي", "Weekly")}</option>
                </select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="start_date">{t("تاريخ البدء", "Start date")}</Label>
                <Input
                  id="start_date"
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                />
              </div>
            </div>
          )}

          <div className="space-y-1.5">
            <Label htmlFor="discount">{t("مبلغ الخصم", "Discount amount")}</Label>
            <Input
              id="discount"
              type="number"
              min={0}
              value={discountAmount}
              onChange={(e) => setDiscountAmount(toInt(Number(e.target.value)))}
            />
          </div>
        </div>
      </div>

      {/* Live summary panel */}
      <div className="lg:sticky lg:top-20 lg:self-start">
        <div className="from-foreground to-primary rounded-lg bg-gradient-to-br p-5 text-white">
          <div className="mb-4 text-xs font-medium opacity-70">
            {t("الملخص", "Summary")}
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="opacity-70">{t("المجموع الفرعي", "Subtotal")}</span>
              <span className="tabular-nums">{formatMoney(subtotal)}</span>
            </div>
            {discountAmount > 0 && (
              <div className="flex justify-between">
                <span className="opacity-70">{t("الخصم", "Discount")}</span>
                <span className="tabular-nums">- {formatMoney(discountAmount)}</span>
              </div>
            )}
            <div className="flex justify-between border-t border-white/15 pt-2 text-base font-bold">
              <span>{t("الإجمالي", "Total")}</span>
              <span className="tabular-nums">{formatMoney(total)}</span>
            </div>
            {saleType === "installment" && total > 0 && (
              <>
                {downPayment > 0 && (
                  <div className="flex justify-between">
                    <span className="opacity-70">{t("الدفعة المقدمة", "Down payment")}</span>
                    <span className="tabular-nums">{formatMoney(downPayment)}</span>
                  </div>
                )}
                <div className="flex justify-between font-semibold">
                  <span className="opacity-90">
                    {t("القسط الشهري", "Monthly")} × {months}
                  </span>
                  <span className="tabular-nums">{formatMoney(monthlyAmount)}</span>
                </div>
              </>
            )}
          </div>

          {createSale.isError && (
            <p className="mt-3 text-sm text-red-200">
              {createSale.error instanceof ApiError
                ? createSale.error.message
                : t("حدث خطأ", "Something went wrong")}
            </p>
          )}

          <Button
            type="button"
            className="mt-4 w-full bg-white text-black hover:bg-white/90"
            disabled={!canSubmit || createSale.isPending}
            onClick={handleSubmit}
          >
            <Plus className="size-4" />
            {createSale.isPending
              ? t("جارٍ التأكيد…", "Confirming…")
              : t("تأكيد البيع", "Confirm sale")}
          </Button>
        </div>
      </div>
    </div>
  );
}
