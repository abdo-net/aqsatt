"use client";

import { useState } from "react";
import Link from "next/link";
import { Plus } from "lucide-react";

import { useSales } from "@/hooks/use-sales";
import { useLocale } from "@/components/providers/locale-provider";
import { DataTable } from "@/components/data-table";
import { buildSaleColumns } from "@/components/sales/columns";
import { Button } from "@/components/ui/button";

const PAGE_SIZE = 20;

export default function SalesPage() {
  const { locale } = useLocale();
  const [page, setPage] = useState(1);

  const { data, isLoading, isFetching } = useSales({ page, pageSize: PAGE_SIZE });
  const columns = buildSaleColumns(locale);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-muted-foreground text-sm">
          {locale === "ar" ? "كل المبيعات" : "All sales"}
        </p>
        <Button asChild>
          <Link href="/sales/new">
            <Plus className="size-4" />
            {locale === "ar" ? "بيع جديد" : "New sale"}
          </Link>
        </Button>
      </div>

      <DataTable
        columns={columns}
        data={data?.data ?? []}
        isLoading={isLoading}
        isFetching={isFetching}
        page={data?.page ?? page}
        totalPages={data?.total_pages ?? 0}
        totalCount={data?.total_count ?? 0}
        onPageChange={setPage}
        emptyMessage={locale === "ar" ? "لا توجد مبيعات" : "No sales"}
      />
    </div>
  );
}
