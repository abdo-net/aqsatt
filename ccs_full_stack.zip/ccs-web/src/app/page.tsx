import { redirect } from "next/navigation";

/**
 * The root path is never a real page — it's purely a routing pivot.
 * - Unauthenticated requests never actually reach this component at all:
 *   proxy.ts (the route guard) already intercepts any request to "/"
 *   without the auth cookie and redirects to /login before Next.js even
 *   renders this file.
 * - Authenticated requests land here after login (or by navigating to the
 *   bare domain with a valid session) and are sent straight into the app
 *   shell. /dashboard is the canonical landing page once authenticated.
 *
 * This file previously contained a build-smoke-test placeholder
 * ("CCS — build smoke test") left over from verifying the initial Next.js
 * scaffold compiled correctly during the framework migration. It was never
 * replaced with real routing logic, which is the confirmed root cause of
 * the reported "non-functional entrypoint" — there was no redirect, no
 * auth check, nothing. This fixes that by making "/" a pure server-side
 * redirect, with zero client-rendered content of its own.
 */
export default function RootPage() {
  redirect("/dashboard");
}
