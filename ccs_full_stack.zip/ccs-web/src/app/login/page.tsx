"use client";

import { Suspense, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQueryClient } from "@tanstack/react-query";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const loginSchema = z.object({
  username: z.string().min(1, "اسم المستخدم مطلوب"),
  password: z.string().min(1, "كلمة المرور مطلوبة"),
});

type LoginValues = z.infer<typeof loginSchema>;

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const queryClient = useQueryClient();
  const [serverError, setServerError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<LoginValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: { username: "admin", password: "admin123" },
  });

  async function onSubmit(values: LoginValues) {
    setServerError(null);
    const res = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });

    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setServerError(
        typeof data?.detail === "string" ? data.detail : "بيانات الدخول غير صحيحة"
      );
      return;
    }

    await queryClient.invalidateQueries({ queryKey: ["me"] });
    const next = searchParams.get("next");
    router.push(next && next.startsWith("/") ? next : "/dashboard");
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4" noValidate>
      <div className="space-y-1.5">
        <Label htmlFor="username">اسم المستخدم</Label>
        <Input
          id="username"
          autoComplete="username"
          aria-invalid={!!errors.username}
          {...register("username")}
        />
        {errors.username && (
          <p className="text-destructive text-xs">{errors.username.message}</p>
        )}
      </div>

      <div className="space-y-1.5">
        <Label htmlFor="password">كلمة المرور</Label>
        <Input
          id="password"
          type="password"
          autoComplete="current-password"
          aria-invalid={!!errors.password}
          {...register("password")}
        />
        {errors.password && (
          <p className="text-destructive text-xs">{errors.password.message}</p>
        )}
      </div>

      {serverError && <p className="text-destructive text-sm">{serverError}</p>}

      <Button type="submit" className="w-full" disabled={isSubmitting}>
        {isSubmitting ? "جارٍ الدخول…" : "دخول"}
      </Button>
    </form>
  );
}

export default function LoginPage() {
  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      {/* Branded panel — hidden on mobile/tablet, shown from lg breakpoint up */}
      <div className="bg-sidebar relative hidden flex-col justify-between p-12 text-white lg:flex">
        <div className="flex items-center gap-3">
          <div className="bg-primary flex size-10 items-center justify-center rounded-xl text-lg font-extrabold">
            C
          </div>
          <span className="text-xl font-bold tracking-tight">CCS</span>
        </div>
        <div>
          <h2 className="mb-3 text-4xl font-extrabold leading-tight">
            نظام إدارة التقسيط
          </h2>
          <p className="text-sidebar-foreground/70 max-w-xs text-sm leading-relaxed">
            منصة إدارة البيع بالتقسيط · متعدد المستأجرين · آمنة بـ Row-Level
            Security
          </p>
        </div>
        <div className="text-sidebar-foreground/40 text-sm">© 2026 CCS Platform</div>
      </div>

      {/* Form panel — full width on mobile/tablet */}
      <div className="bg-background flex min-h-screen items-center justify-center p-6 lg:min-h-0">
        <div className="w-full max-w-sm">
          <div className="bg-primary mb-6 flex size-12 items-center justify-center rounded-xl text-xl font-extrabold text-white lg:hidden">
            C
          </div>
          <h1 className="mb-1 text-2xl font-extrabold">تسجيل الدخول</h1>
          <p className="text-muted-foreground mb-6 text-sm">مرحباً 👋</p>

          <Suspense fallback={<div className="h-48" />}>
            <LoginForm />
          </Suspense>
        </div>
      </div>
    </div>
  );
}
