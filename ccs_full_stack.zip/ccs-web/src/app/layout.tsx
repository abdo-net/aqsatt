import type { Metadata } from "next";
import "./globals.css";
import { QueryProvider } from "@/components/providers/query-provider";
import { ThemeProvider } from "@/components/providers/theme-provider";
import { LocaleProvider } from "@/components/providers/locale-provider";

export const metadata: Metadata = {
  title: "CCS — نظام إدارة التقسيط",
  description: "Credit Commerce System — installment retail management",
};

/**
 * Fonts are loaded via <link> tags, NOT next/font/google. next/font fetches
 * font files at BUILD time from fonts.googleapis.com, which fails in any
 * sandboxed/offline build environment (confirmed: this exact failure mode
 * blocked the first build attempt). A <link> tag is a runtime browser fetch
 * with normal fallback behavior — slightly slower first paint, but it does
 * not couple the production build to Google's network being reachable from
 * the build machine. This is the same approach the previous vanilla-JS
 * build used successfully.
 */
export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" className="h-full" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        {/* eslint-disable-next-line @next/next/no-page-custom-font -- false
            positive: this rule targets pages/_document.js in the Pages
            Router and only bails out when the filepath contains a "pages"
            segment, which an App Router project never has. Link-tag fonts
            here are intentional (see file-level comment above). */}
        <link
          href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&family=Noto+Sans+Arabic:wght@400;500;600;700;800&display=swap"
          rel="stylesheet"
        />
        {/* No-flash theme + locale: read localStorage before first paint so
            the page never flickers light->dark or RTL->LTR on load. */}
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function () {
                try {
                  var savedTheme = localStorage.getItem("ccs-theme");
                  var prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
                  if (savedTheme === "dark" || (!savedTheme && prefersDark)) {
                    document.documentElement.classList.add("dark");
                  }
                  var savedLocale = localStorage.getItem("ccs-locale");
                  if (savedLocale === "en") {
                    document.documentElement.lang = "en";
                    document.documentElement.dir = "ltr";
                  }
                } catch (e) {}
              })();
            `,
          }}
        />
      </head>
      <body className="min-h-full font-sans antialiased">
        <QueryProvider>
          <ThemeProvider>
            <LocaleProvider>{children}</LocaleProvider>
          </ThemeProvider>
        </QueryProvider>
      </body>
    </html>
  );
}
